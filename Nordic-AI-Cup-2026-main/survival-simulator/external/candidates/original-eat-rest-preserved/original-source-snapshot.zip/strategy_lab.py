"""Research policies; decisions use only the public observation payload."""
import math
from species_field_trial import SpeciesFields, unit, point, wrap, rotate
from src.utils.controllers.potential_field_policy import closest_point
from src.utils.DTOs import ActionRequest


PRESETS = {
    'economy': {},
    'ripen': {'ripen_seconds': 12.},
    'patch': {'ripen_seconds': 12., 'patch_wait': 12.},
    'gaze': {'ripen_seconds': 12., 'patch_wait': 12., 'escape': 'gaze'},
    'predict': {'ripen_seconds': 12., 'patch_wait': 12., 'escape': 'predict'},
    'mapped': {'ripen_seconds': 8., 'patch_wait': 8., 'escape': 'predict', 'search_speed': .8},
    'direct': {'escape': 'direct', 'gaze_turn': math.pi, 'escape_radius': 110.},
    'agile': {'escape': 'predict', 'gaze_turn': math.pi, 'search_speed': .7,
              'prediction_horizon': 6, 'prediction_angles': 12},
    'vigilant': {'escape': 'direct', 'gaze_turn': math.pi, 'scan': .65,
                 'threat_memory': .8, 'threat_cooldown': 3., 'rest_radius': 60.,
                 'face_predators': True, 'escape_radius': 120.},
    'roamer': {'escape': 'direct', 'gaze_turn': math.pi, 'boundary_bias': True,
               'search_reorient': 5., 'scan': .35},
    'guard': {'escape': 'direct', 'gaze_turn': math.pi, 'scan': .3,
              'threat_memory': .5, 'threat_cooldown': 1.5, 'rest_radius': 65.,
              'escape_radius': 130., 'sprint_radius': 80., 'emergency_fraction': .22},
}


class SurvivalPolicy(SpeciesFields):
    def __init__(self, preset='economy', **overrides):
        super().__init__('tangent')
        self.config = dict(search_speed=.4, scan=.2, birth_energy=220.,
                           population=12, population_floor=3, population_decay=900.,
                           retirement=105., ripen_seconds=0., patch_wait=0.,
                           escape='arc', escape_radius=100., sprint_radius=55.,
                           idle_energy=.87, young_age=65., reserve=80.)
        self.config.update(gaze_turn=1., prediction_horizon=4, prediction_angles=6)
        self.config.update(threat_memory=0.,threat_cooldown=0.,rest_radius=45.,face_predators=False,
                           selective_breeding=0.,weighted_allocation=False,boundary_bias=False,search_reorient=0.,emergency_fraction=.4,
                           fresh_ripen=0.,ripen_age_limit=65.,hard_idle_energy=1e9,birth_floor=135.,fertile_population=False,
                           quality_mode='basic',fitness_population=False)
        self.config.update(PRESETS.get(preset, {}))
        self.config.update(overrides)
        self.preset = preset
        self.clock = 0.
        self.first_seen = {}
        self.birth_times = {}
        self.spawn_ids = set()
        self.retired_ids = set()

    def observe(self, state):
        old_mem=self.memory.get(state['agent_id'])
        old_keys={key for key,p in old_mem.fruit_tracks} if old_mem is not None else set()
        had_previous=old_mem is not None and old_mem.last_age>=0.
        view = super().observe(state)
        mem=view['mem']
        if view['predators']:
            mem.enemy_cache=[dict(p) for p in view['predators']]
            mem.enemy_seen=self.clock
        elif self.config['threat_memory'] and hasattr(mem,'enemy_cache') and self.clock-mem.enemy_seen<self.config['threat_memory']:
            remembered=[]
            for enemy in mem.enemy_cache:
                q=rotate(enemy['p'],-mem.last_turn)
                v=rotate(enemy['velocity'],-mem.last_turn)
                q=(q[0]-view['translation'][0]+v[0]*.7,q[1]-view['translation'][1]+v[1]*.7)
                d=math.hypot(*q)
                remembered.append(dict(p=q,heading=wrap(enemy['heading']-mem.last_turn),velocity=v,measured=True,
                                       remembered=True,obs=dict(type='Predator',distance=d,angle=math.atan2(q[1],q[0]))))
            view['predators']=remembered
            mem.enemy_cache=remembered
        for fruit in view['fruits']:
            key = self.canonical(fruit['key'])
            self.first_seen.setdefault(key, self.clock)
            if had_previous and fruit['key'] not in old_keys and fruit['obs']['distance']+math.hypot(*view['translation'])+3.<state['hearing_radius']:
                # It was inside the previous hearing disk and absent then:
                # unlike a newly discovered distant fruit, this is a birth.
                self.birth_times.setdefault(key,self.clock)
        if self.config['escape'] != 'arc':
            threats = []
            for enemy in view['predators']:
                d = enemy['obs']['distance']
                v = enemy['velocity']
                closing = -(v[0]*enemy['p'][0]+v[1]*enemy['p'][1])/max(d,1.)
                radius = self.config['escape_radius']
                # Still predators may wake without advance notice.
                if enemy['measured'] and math.hypot(*v) < .5:
                    radius = min(radius, self.config['rest_radius'])
                if d < radius or (closing > 2 and d/closing < 7.):
                    threats.append(enemy)
            view['escaping'] = bool(threats)
            if threats:
                view['predators'].sort(key=lambda p: (p not in threats,p['obs']['distance']))
        mem = view['mem']
        if not hasattr(mem, 'patch_since'):
            mem.patch_since = None
        return view

    def merge(self, a, b):
        aa, bb = self.canonical(a), self.canonical(b)
        first = min(self.first_seen.get(aa,self.clock), self.first_seen.get(bb,self.clock))
        births=[self.birth_times[k] for k in (aa,bb) if k in self.birth_times]
        super().merge(a,b)
        self.first_seen[self.canonical(a)] = first
        if births:self.birth_times[self.canonical(a)]=min(births)

    def decide_all(self, states, sim_time=None):
        if any(s['agent_id'] in self.memory and s['age'] < self.memory[s['agent_id']].last_age for s in states):
            self.memory.clear()
            self.parents.clear()
            self.first_seen.clear()
            self.birth_times.clear()
            self.clock = 0.
        self.clock = float(sim_time) if sim_time is not None else self.clock + .1
        live = {s['agent_id'] for s in states}
        self.memory = {k:v for k,v in self.memory.items() if k in live}
        views = {s['agent_id']:self.observe(s) for s in sorted(states,key=lambda s:s['agent_id'])}
        c = self.config
        cap = max(c['population_floor'], round(c['population'] * .5**(self.clock/c['population_decay'])))
        young = sum(s['age'] < c['young_age'] and (not c['fertile_population'] or s['max_energy']>c['birth_floor']+5.) for s in states)
        def quality(s):
            if c['quality_mode']!='basic':
                walk=max(.1,min(s['speed'],s['sprint_speed']))/10.
                hearing=max(.1,s['hearing_radius'])/50.
                vision=max(.1,s['vision_range'])/200.
                cone=max(.01,s['vision_angle'])/(math.pi/3.)
                fertility=min(1.,max(.01,(s['max_energy']-100.)/100.))
                if c['quality_mode']=='endurance':return walk**1.4*hearing**.9*vision**.4*cone**.3*(max(100.,s['max_energy'])/500.)**.65*fertility
                if c['quality_mode']=='sensory':return walk**1.3*hearing**1.2*vision**.5*cone**.4*fertility
                return walk**1.7*hearing**.8*vision**.4*cone**.3*fertility
            return min(s['speed'],s['sprint_speed'])*math.sqrt(max(1.,s['hearing_radius']+.5*s['vision_range']))
        qualities=sorted(quality(s) for s in states)
        median_quality=qualities[len(qualities)//2] if qualities else 1.
        if c['fitness_population'] and qualities:
            young=round(sum(min(1.,quality(s)/max(qualities)) for s in states if s['age']<c['young_age']))
        elite_cutoff=c.get('elite_population',0.)
        if elite_cutoff and qualities:
            young=sum(s['age']<c['young_age'] and quality(s)>=elite_cutoff*max(qualities) for s in states)
        self.retired_ids = {s['agent_id'] for s in states if s['age']>c['retirement'] and young>=max(2,cap//2)}
        if elite_cutoff and qualities and sum(quality(s)>=elite_cutoff*max(qualities) for s in states)>=2:
            self.retired_ids.update(s['agent_id'] for s in states if quality(s)<.8*max(qualities) and s['age']>2.)
        candidates = []
        for aid, view in views.items():
            s = view['state']
            threshold = min(c['birth_energy'], .75*s['max_energy'])
            threshold = max(c['birth_floor'], threshold)
            if c['selective_breeding']:
                threshold=max(135.,threshold+c['selective_breeding']*(1.-quality(s)/median_quality))
            if s['age'] > 60 and young < max(2,cap//2):
                threshold = min(threshold,160.)
            safe = not view['predators'] or min(p['obs']['distance'] for p in view['predators']) > 130.
            safe = safe and self.clock-getattr(view['mem'],'enemy_seen',-10000.)>=c['threat_cooldown']
            if s['energy'] > threshold and safe and aid not in self.retired_ids:
                parent_quality = quality(s) if c['selective_breeding'] or c['quality_mode']!='basic' else min(s['speed'],s['sprint_speed']) + .015*s['hearing_radius'] + .003*s['vision_range']
                candidates.append((parent_quality, s['energy'], -aid, aid))
        self.spawn_ids = {x[-1] for x in sorted(candidates,reverse=True)[:max(0,cap-young)]}
        for aid,view in views.items():
            s=view['state']
            if aid in self.retired_ids or (s['energy']>min(c['hard_idle_energy'],c['idle_energy']*s['max_energy']) and aid not in self.spawn_ids):
                view['resting'] = True
            else:
                view['resting'] = False
            view['eligible'] = not view['resting']
        self.allocate(views)
        return [self.steer(views[s['agent_id']]) for s in states]

    def predictive_escape(self, view, walk, sprint):
        """Sample short trajectories against a bounded-turn pursuit model."""
        terrain = {'swamp':.5,'river':.3,'desert':.8}.get(view['state']['biome'],1.)
        nearest=view['predators'][0]
        away=math.atan2(-nearest['p'][1],-nearest['p'][0])
        previous=rotate(view['mem'].last_move,-view['mem'].last_turn)
        prev_angle=math.atan2(previous[1],previous[0])
        choices=[]
        speeds=[walk]
        if sprint>walk+.01 and view['state']['energy']>.21*view['state']['max_energy']+10:
            speeds.append(sprint)
        for speed in speeds:
            count=self.config['prediction_angles']
            offsets=[(i-count/2)*math.pi/count for i in range(count+1)]
            if count>=12:
                offsets.extend([-2*math.pi/3,2*math.pi/3])
            for offset in offsets:
                direction,slid=self.slide((math.cos(away+offset),math.sin(away+offset)),view,speed)
                vx,vy=direction[0]*speed*terrain,direction[1]*speed*terrain
                minimum=math.inf
                end=math.inf
                for enemy in view['predators'][:4]:
                    px,py=enemy['p']; heading=enemy['heading']
                    ex,ey=enemy['velocity']
                    moving=not enemy['measured'] or math.hypot(ex,ey)>.5
                    if moving:
                        # Observations precede the predator's last move.
                        px+=ex; py+=ey
                    for horizon in range(1,self.config['prediction_horizon']+1):
                        ax,ay=vx*horizon,vy*horizon
                        if moving or horizon>=3:
                            target_angle=math.atan2(ay-py,ax-px)
                            heading=wrap(heading+max(-.3,min(.3,wrap(target_angle-heading)*.5)))
                            pspeed=15.*terrain
                            px+=pspeed*math.cos(heading); py+=pspeed*math.sin(heading)
                        d=math.hypot(ax-px,ay-py)
                        minimum=min(minimum,d)
                    end=min(end,d)
                cost=.05*min(speed,walk)+.5*max(0,speed-walk)
                angle=math.atan2(direction[1],direction[0])
                # Collision avoidance dominates, then useful clearance and cost.
                value=(-1000.*max(0,22.-minimum) + min(minimum,65.)
                       +.15*min(end,150.)-4.*cost+1.5*math.cos(angle-prev_angle))
                choices.append((value,speed,direction))
        _,speed,direction=max(choices,key=lambda x:x[0])
        return direction,speed

    def steer(self, view):
        s,mem,c=view['state'],view['mem'],self.config
        target=view['visible'].get(mem.target_id)
        terrain={'swamp':.5,'river':.3,'desert':.8}.get(s['biome'],1.)
        walk=max(0.,min(s['speed'],s['sprint_speed']))
        speed=walk
        turn=None
        mode='SEARCH'
        if view['escaping']:
            mode='ESCAPE'
            if c['escape']=='predict':
                desired,speed=self.predictive_escape(view,walk,s['sprint_speed'])
            else:
                if s['energy']>max(c['emergency_fraction']*s['max_energy'],.2*s['max_energy']+5.) and view['predators'][0]['obs']['distance']<c['sprint_radius']:
                    speed=s['sprint_speed']
                desired=(unit((-view['predators'][0]['p'][0],-view['predators'][0]['p'][1]))
                         if c['escape']=='direct' else self.arc_escape(view,speed))
            if c['escape']!='arc':
                pred=view['predators'][0]
                turn=max(-c['gaze_turn'],min(c['gaze_turn'],pred['obs']['angle']))
            mem.patch_since=None
        elif view.get('resting'):
            mode='REST'
            desired=(1.,0.); speed=0.; turn=c['scan']
        elif target is not None:
            mode='EAT'
            desired=unit(target['p'])
            d=target['obs']['distance']
            seen=self.clock-self.first_seen.get(self.canonical(target['key']),self.clock)
            wait=c['ripen_seconds']
            born=self.birth_times.get(self.canonical(target['key']))
            if c['fresh_ripen'] and born is not None:
                wait=c['fresh_ripen'];seen=self.clock-born
            ripening=(seen<wait and s['energy']>c['reserve']+2*(wait-seen) and s['age']<c['ripen_age_limit'])
            stop=17. if ripening else 6.
            speed=min(walk,max(0.,d-stop)/terrain)
            if ripening and d<19.:
                mode='RIPEN'; turn=c['scan']
            mem.patch_since=None
        else:
            trees=[o for o in s['observations'] if o['type']=='Tree']
            nearby=min(trees,key=lambda o:o['distance']) if trees else None
            if c['patch_wait'] and nearby and nearby['distance']<55. and s['energy']>c['reserve'] and s['age']<65.:
                if mem.patch_since is None:
                    mem.patch_since=self.clock
                if self.clock-mem.patch_since<c['patch_wait']:
                    mode='PATCH'; desired=unit(point(nearby))
                    speed=min(walk,max(0.,nearby['distance']-35.)/terrain)
                    turn=c['scan']
                else:
                    nearby=None
            else:
                mem.patch_since=None
                nearby=None
            if mode=='SEARCH':
                if c['search_reorient'] and self.clock>=getattr(mem,'next_reorient',0.):
                    mem.search_heading=wrap(mem.search_heading+mem.rng.choice((-1,1))*mem.rng.uniform(.6,1.6))
                    mem.next_reorient=self.clock+c['search_reorient']
                if view['fruits'] and view['agents']:
                    a=view['agents'][0]
                    mem.search_heading=wrap(mem.heading+a['angle']+math.pi)
                mem.search_heading=wrap(mem.search_heading+mem.rng.uniform(-.015,.015))
                angle=wrap(mem.search_heading-mem.heading)
                desired=(math.cos(angle),math.sin(angle))
                if c['boundary_bias']:
                    dx,dy=desired
                    for edge in view['edges']:
                        length=math.hypot(edge[1][0]-edge[0][0],edge[1][1]-edge[0][1])
                        p=closest_point(edge);d=math.hypot(*p)
                        if length>800. and d<120.:
                            normal=unit((-p[0],-p[1]))
                            weight=3.*max(0.,1.-d/120.)
                            dx+=weight*normal[0];dy+=weight*normal[1]
                    desired=unit((dx,dy))
                speed=walk*c['search_speed']
                turn=c['scan']
        desired,slid=self.slide(desired,view,speed)
        direction=math.atan2(desired[1],desired[0])
        if turn is None:
            turn=max(-.6,min(.6,direction))
        if c['face_predators'] and view['predators'] and (target is None or target['obs']['distance']<s['hearing_radius']):
            enemy=view['predators'][0]
            if enemy['obs']['distance']<180.:
                turn=max(-c['gaze_turn'],min(c['gaze_turn'],enemy['obs']['angle']))
        self.metrics[mode.lower()+'_ticks']+=1
        mem.last_mode=mode
        self.metrics['sprint_ticks']+=int(speed>walk+.01)
        self.metrics['wall_slide_ticks']+=int(slid)
        mem.last_move=(speed*terrain*math.cos(direction),speed*terrain*math.sin(direction))
        mem.last_turn=turn
        if speed>0:
            mem.search_heading=wrap(mem.heading+direction)
        return ActionRequest(agent_id=s['agent_id'],move_distance=speed,move_direction=direction,
                             turn_angle=turn,spawn_agent=s['agent_id'] in self.spawn_ids)


class MappedPolicy(SurvivalPolicy):
    """Short-lived resource map and exploration visits from visual odometry."""
    def observe(self,state):
        view=super().observe(state)
        mem=view['mem']
        if not hasattr(mem,'position'):
            mem.position=(0.,0.)
            mem.visits={}
            mem.terrain={}
            mem.tree_map={}
            mem.next_scout=0.
            mem.scout_target=None
        delta=rotate(view['translation'],mem.heading)
        mem.position=(mem.position[0]+delta[0],mem.position[1]+delta[1])
        x,y=mem.position
        cell=(round(x/75.),round(y/75.))
        mem.visits[cell]=self.clock
        mem.terrain[cell]=state['biome']
        for obs in state['observations']:
            if obs['type']=='Tree':
                q=rotate(point(obs),mem.heading)
                p=(x+q[0],y+q[1])
                key=(round(p[0]/10.),round(p[1]/10.))
                mem.tree_map[key]=(p,self.clock)
        mem.tree_map={k:v for k,v in mem.tree_map.items() if self.clock-v[1]<20.}
        return view

    def steer(self,view):
        mem,s=view['mem'],view['state']
        target=view['visible'].get(mem.target_id)
        if not view['escaping'] and not view.get('resting') and target is None:
            x,y=mem.position
            if self.clock>=mem.next_scout or mem.scout_target is None or math.hypot(mem.scout_target[0]-x,mem.scout_target[1]-y)<30.:
                choices=[]
                prior=mem.search_heading
                for i in range(16):
                    angle=prior+i*math.pi/8.
                    dx,dy=math.cos(angle),math.sin(angle)
                    px,py=x+150.*dx,y+150.*dy
                    score=5.*math.cos(angle-prior)
                    for r in (60.,120.,180.):
                        cell=(round((x+r*dx)/75.),round((y+r*dy)/75.))
                        last=mem.visits.get(cell,-10000.)
                        score+=min(30.,(self.clock-last)*.4)
                        biome=mem.terrain.get(cell)
                        score+= {'forest':8.,'grassland':3.,'desert':-15.,'river':-30.,'swamp':-4.}.get(biome,0.)
                    for tree,seen in mem.tree_map.values():
                        distance=math.hypot(tree[0]-px,tree[1]-py)
                        score+=10.*math.exp(-distance/100.)*max(0.,1.-(self.clock-seen)/20.)
                    for pred in view['predators']:
                        q=rotate(pred['p'],mem.heading)
                        separation=math.hypot(150.*dx-q[0],150.*dy-q[1])
                        score-=max(0.,180.-separation)*.3
                    local=rotate((dx,dy),-mem.heading)
                    slid,used=self.slide(local,view,30.)
                    if used:score-=30.
                    choices.append((score,(px,py)))
                _,mem.scout_target=max(choices,key=lambda p:p[0])
                mem.next_scout=self.clock+2.
            dx,dy=mem.scout_target[0]-x,mem.scout_target[1]-y
            mem.search_heading=math.atan2(dy,dx)
        return super().steer(view)
