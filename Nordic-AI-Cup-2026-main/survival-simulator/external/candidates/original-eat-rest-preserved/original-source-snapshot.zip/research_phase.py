import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('safety',{'label':'rest_credit','enemy_speed':'maximum','filter_horizon':2,'optimistic_rest':2.}),
 ('safety',{'label':'inferred_terrain','enemy_speed':'inferred','filter_horizon':2,'stale_correction':True}),
 ('refuge',{'label':'refuge_generations','quality_mode':'ecological','fitness_population':True,'population':10,'population_floor':3,'retirement':75.,'young_age':50.}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_phase_{seed}.jsonl')
