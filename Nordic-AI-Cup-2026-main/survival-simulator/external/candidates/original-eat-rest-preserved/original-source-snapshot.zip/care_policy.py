"""Controlled offspring-care and food-allocation experiments."""
import math
from dispersal_policy import DispersalPolicy
from species_field_trial import wrap
from nursery_policy import segment_clear


class CarePolicy(DispersalPolicy):
    def __init__(self,preset='care',**overrides):
        config=dict(dispersal_distance=100.,migration_slide=False,migration_food=0.,
                    hunger_allocation=False,retarget_ratio=0.,birth_food_gate=False,
                    ghost_filter=False,food_retirement=False)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem'];c=self.config
        previous=getattr(mem,'care_energy',state['energy'])
        gain=state['energy']-previous+getattr(mem,'care_cost',0.)
        mem.care_energy=state['energy'];mem.care_gain=max(0.,gain)
        if gain>5.:mem.care_last_meal=self.clock
        if c['migration_food'] and mem.colonist and view['fruits']:
            foods=[f for f in view['fruits'] if f['obs']['distance']<c['migration_food']
                   and segment_clear((0.,0.),f['p'],view['edges'],0.)]
            if foods:
                mem.colonist=False;self.metrics['migration_food_interrupts']+=1
        if c['ghost_filter'] and gain>5.:
            view['fruits']=[f for f in view['fruits'] if f['obs']['distance']>14.]
        return view

    def allocate(self,views):
        super().allocate(views)
        c=self.config
        if not c['hunger_allocation'] and not c['retarget_ratio']:return
        if c['hunger_allocation']:
            candidates=[]
            for aid,v in views.items():
                mem,s=v['mem'],v['state'];old=mem.target_id
                mem.target_id=None
                if v['escaping'] or not v.get('eligible',True):continue
                terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
                speed=max(.1,min(s['speed'],s['sprint_speed']))
                for key,f in v['visible'].items():
                    distance=max(0.,f['obs']['distance']-10.)
                    cost=distance/terrain*(.05+.1/speed)+1.
                    if s['energy']<cost:cost+=100.
                    urgency=max(.2,min(1.5,s['energy']/100.))
                    score=cost*urgency
                    if key==old:score*=.7
                    candidates.append((score,aid,key))
            owners=set();assigned=set()
            for score,aid,key in sorted(candidates):
                if key not in owners and aid not in assigned:
                    views[aid]['mem'].target_id=key;owners.add(key);assigned.add(aid)
        elif c['retarget_ratio']:
            reserved={v['mem'].target_id for v in views.values() if v['mem'].target_id is not None}
            for aid,v in views.items():
                mem=v['mem'];old=v['visible'].get(mem.target_id)
                if old is None:continue
                options=[f for key,f in v['visible'].items() if key not in reserved and
                         f['obs']['distance']<old['obs']['distance']*c['retarget_ratio'] and
                         segment_clear((0.,0.),f['p'],v['edges'],0.)]
                if not options:continue
                target=min(options,key=lambda f:f['obs']['distance'])
                reserved.discard(mem.target_id);mem.target_id=target['id'];reserved.add(mem.target_id)
                self.metrics['closer_target_switches']+=1

    def steer(self,view):
        action=super().steer(view);mem=view['mem']
        if self.config['migration_slide'] and mem.last_mode=='COLONIZE':
            mem.migration_heading=wrap(mem.heading+action.move_direction)
        return action

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time);byid={s['agent_id']:s for s in states}
        for action in actions:
            s=byid[action.agent_id];mem=self.memory[action.agent_id]
            if action.spawn_agent and self.config['birth_food_gate']:
                near_food=any(o['type']=='Fruit' and o['distance']<150. for o in s['observations'])
                if not near_food and s['age']<80. and len(states)>2 and s['energy']<250.:
                    action.spawn_agent=False;self.metrics['unfunded_births_deferred']+=1
            mem.care_cost=.1+min(math.pi,abs(action.turn_angle))/(2*math.pi)
            mem.care_cost+=.05*min(action.move_distance,s['speed'])+.5*max(0.,action.move_distance-s['speed'])
            mem.care_cost+=100.*action.spawn_agent
        return actions
