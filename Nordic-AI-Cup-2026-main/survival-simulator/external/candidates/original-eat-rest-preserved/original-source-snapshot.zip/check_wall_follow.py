import math
from sticky_policy import StickyPolicy
from species_field_trial import Memory,unit

policy=StickyPolicy(stuck_recovery=False)
mem=Memory();mem.target_id=1
corners=[(20.,-40.),(60.,-40.),(60.,40.),(20.,40.)]
edges=list(zip(corners,corners[1:]+corners[:1]))
x=y=0.
for tick in range(100):
 goal=(100.-x,-y)
 view=dict(mem=mem,state=dict(biome='forest',agent_id=1),escaping=False,
           visible={1:dict(p=goal)},edges=[((a[0]-x,a[1]-y),(b[0]-x,b[1]-y)) for a,b in edges])
 direction,used=policy.slide(unit(goal),view,10.)
 speed=min(10.,math.hypot(*goal))
 x+=direction[0]*speed;y+=direction[1]*speed
 assert not (15.<x<65. and -45.<y<45.),(tick,x,y)
 mem.last_move=(direction[0]*speed,direction[1]*speed)
 if math.hypot(100.-x,y)<6.:break
else:raise AssertionError(('failed to navigate around rectangle',x,y))
print('Committed wall following reached obstructed fruit in',tick+1,'ticks')
