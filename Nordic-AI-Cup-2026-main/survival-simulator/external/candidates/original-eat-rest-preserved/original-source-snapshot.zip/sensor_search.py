"""Match search travel per full gaze sweep to each mutant's sensing range."""
import math
from dispersal_policy import DispersalPolicy
from species_field_trial import unit,wrap


class SensorSearch(DispersalPolicy):
    def __init__(self,preset='sensor_search',**overrides):
        config=dict(dispersal_distance=100.,sensor_mode='distance',sensor_terrain=False,
                    sensor_ratio=.02,sensor_start=0.)
        config.update(overrides);super().__init__(preset,**config)

    def steer(self,view):
        a=super().steer(view);s,mem=view['state'],view['mem'];c=self.config
        if mem.last_mode!='SEARCH' or self.clock<c['sensor_start']:return a
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        walk=min(s['speed'],s['sprint_speed'])
        if c['sensor_mode']=='distance':
            travel=max(c['sensor_ratio']*s['vision_range'],s['hearing_radius']*c['scan']/math.pi)
            if c['sensor_terrain']:travel/=terrain
            a.move_distance=min(walk,max(.5,travel))
            direction,_=self.slide((math.cos(a.move_direction),math.sin(a.move_direction)),view,a.move_distance)
            a.move_direction=math.atan2(direction[1],direction[0])
        elif c['sensor_mode']=='scan':
            turn=2*math.pi*a.move_distance*terrain/max(10.,.65*s['vision_range'])
            a.turn_angle=min(.8,max(c['scan'],turn))
        mem.last_move=(a.move_distance*terrain*math.cos(a.move_direction),a.move_distance*terrain*math.sin(a.move_direction))
        mem.last_turn=a.turn_angle
        if a.move_distance:mem.search_heading=wrap(mem.heading+a.move_direction)
        self.metrics['sensor_search_ticks']+=1
        return a
