import sys
from campaign_runner import run
CASES=[
 ('merit_floors',{}),
 ('merit_sprint',{'sprint_merit':.4}),
 ('merit_intake',{'merit_mode':'intake'}),
 ('merit_mixed',{'merit_mode':'mixed'}),
 ('merit_capacity',{'merit_mode':'capacity'}),
]
if __name__=='__main__':
    for label,config in CASES:run(int(sys.argv[1]),'merit_policy:MeritPolicy',config,label)
