"""Short food-route planning; all movement and threat handling are inherited."""
import math
from generation_policy import GenerationPolicy
from nursery_policy import segment_clear


class HarvestPolicy(GenerationPolicy):
    def __init__(self, preset='harvest', **overrides):
        config = dict(maximum_birth_gap=20., harvest_depth=2,
                      harvest_discount=.7, harvest_switch=7., harvest_start=0.,
                      harvest_range=180., harvest_food_value=42.)
        config.update(overrides)
        super().__init__(preset, **config)

    def allocate(self, views):
        super().allocate(views)
        c = self.config
        if self.clock < c['harvest_start']:
            return
        owners = {v['mem'].target_id: aid for aid,v in views.items() if v['mem'].target_id is not None}
        for aid,v in sorted(views.items(), key=lambda kv: kv[1]['state']['energy']):
            if v['escaping'] or not v.get('eligible', True):
                continue
            s,m = v['state'],v['mem']
            terrain = {'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
            speed = max(.1,min(s['speed'],s['sprint_speed']))
            # Age is public; the exact random aging onset is deliberately
            # not read. Expected late metabolic cost rises gradually.
            aging = max(0.,min(1.,(s['age']-60.)/60.)) * .1*s['age']
            unit_cost = (.05 + (1.32+aging)*.1/speed)/terrain
            foods = [f for key,f in v['visible'].items()
                     if owners.get(key,aid)==aid and f['obs']['distance']>10.]
            foods = sorted(foods,key=lambda f:f['obs']['distance'])[:12]
            values = []
            for f in foods:
                d = max(0.,f['obs']['distance']-10.)
                if d*unit_cost+1. >= s['energy']:
                    continue
                if not segment_clear((0.,0.),f['p'],v['edges'],0.):
                    continue
                def value(item):
                    born = self.birth_times.get(self.canonical(item['key']))
                    return min(60.,20.+2.*(self.clock-born)) if born is not None else c['harvest_food_value']
                score = value(f)-d*unit_cost
                remaining = [g for g in foods if g['id']!=f['id']]
                previous = f
                for depth in range(1,c['harvest_depth']):
                    options = []
                    for g in remaining:
                        gap = math.hypot(g['p'][0]-previous['p'][0],g['p'][1]-previous['p'][1])
                        if gap < c['harvest_range'] and segment_clear(previous['p'],g['p'],v['edges'],0.):
                            options.append((value(g)-max(0.,gap-10.)*unit_cost,g))
                    if not options:
                        break
                    extra,next_food = max(options,key=lambda row:row[0])
                    score += c['harvest_discount']**depth * max(0.,extra)
                    remaining = [g for g in remaining if g['id']!=next_food['id']]
                    previous = next_food
                if f['id']==m.target_id:
                    score += c['harvest_switch']
                values.append((score,-d,f['id']))
            if not values:
                continue
            key = max(values)[-1]
            if key == m.target_id:
                continue
            if m.target_id is not None:
                owners.pop(m.target_id,None)
            m.target_id = key
            owners[key] = aid
            self.metrics['harvest_target_switches'] += 1
