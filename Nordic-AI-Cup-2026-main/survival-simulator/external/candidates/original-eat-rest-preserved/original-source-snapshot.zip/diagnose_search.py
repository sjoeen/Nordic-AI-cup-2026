"""Read-only world diagnostics, isolated from observation-only controller."""
import os
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT','1')
os.environ.setdefault('SDL_VIDEODRIVER','dummy')
os.environ.setdefault('SDL_AUDIODRIVER','dummy')
from collections import defaultdict,deque
import json
import pygame
from src.core import SimulationCore
from strategy_lab import SurvivalPolicy

pygame.font.init()
sim=SimulationCore(seed=1)
policy=SurvivalPolicy('direct')
paths=defaultdict(lambda:deque(maxlen=200))
actions=[]
for tick in range(30000):
 state=sim.step(actions)
 if tick%10==0:
  for a in sim.env.agents:paths[a.agent_id].append((a.x,a.y))
 if tick+1 in (10000,13000,15000) or not state['num_agents']:
  surface=sim.env.biome_surface.copy()
  for o in sim.env.obstacles:pygame.draw.rect(surface,(30,30,30),(o.x,o.y,o.width,o.height))
  for a in sim.env.agents:
   if len(paths[a.agent_id])>1:pygame.draw.lines(surface,(80,150,255),False,list(paths[a.agent_id]),2)
  for tree in sim.env.trees:pygame.draw.circle(surface,(200,180,20),(tree.x,tree.y),12,2)
  for fruit in sim.env.fruits:pygame.draw.circle(surface,(30,255,80),(fruit.x,fruit.y),6)
  for predator in sim.env.predators:pygame.draw.circle(surface,(255,30,30),(predator.x,predator.y),10)
  font=pygame.font.Font(None,24)
  for a in sim.env.agents:
   pygame.draw.circle(surface,(50,80,255),(a.x,a.y),8)
   label=f'{a.agent_id}: {int(a.energy)}E {int(a.age)}y'
   surface.blit(font.render(label,True,(255,255,255)),(a.x+9,a.y-12))
  filename=f'diagnostic_{tick+1}.png'
  pygame.image.save(surface,filename)
  print(json.dumps(dict(time=round(state['sim_time'],1),snapshot=filename,alive=state['num_agents'],
   agents=[dict(id=a.agent_id,x=a.x,y=a.y,energy=a.energy,age=a.age,
                mode=getattr(policy.memory.get(a.agent_id),'last_mode',None)) for a in sim.env.agents])),flush=True)
 if not state['num_agents']:break
 decoded=policy.decide_all(state['observations'],state['sim_time'])
 actions=[(a.agent_id,a) for a in decoded]
