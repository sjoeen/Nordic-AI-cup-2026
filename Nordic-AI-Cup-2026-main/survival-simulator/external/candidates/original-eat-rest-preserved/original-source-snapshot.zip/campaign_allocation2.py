import sys
from campaign_runner import run
CASES=[
 ('allocation_lease50',{}),
 ('allocation_lease80',{'reservation_ratio':.8,'reservation_margin':10.}),
 ('allocation_nearest',{'reservation_ratio':0.,'nearest_each_tick':True}),
]
if __name__=='__main__':
    seed=int(sys.argv[1])
    for label,config in CASES:run(seed,'allocation2_policy:AllocationPolicy',config,label)
    run(seed,'dispersal_policy:DispersalPolicy',{'dispersal_distance':100.,'boundary_bias':True},'boundary_interior')
