"""Merge duplicate result streams; a stdout result also certifies completion."""
import json
from pathlib import Path
from collections import defaultdict
import statistics
import argparse

parser=argparse.ArgumentParser();parser.add_argument('--top',type=int,default=10);args=parser.parse_args()

groups=defaultdict(dict);progress={}
paths=list(Path('campaign').glob('*.jsonl'))+list(Path('.').glob('campaign_*.out'))
for p in paths:
    for line in p.read_text().splitlines():
        try:r=json.loads(line)
        except ValueError:continue
        if not isinstance(r,dict) or 'label' not in r or 'seed' not in r:continue
        key=(r['label'],r['seed'])
        if r.get('event')=='result':
            old=groups[r['label']].get(r['seed'])
            if old is not None:assert old['survival_seconds']==r['survival_seconds'],key
            groups[r['label']][r['seed']]=r
        elif r.get('event') in ('start','progress'):
            if r.get('time',0.)>=progress.get(key,{}).get('time',0.):progress[key]=r
print('Completed games',sum(map(len,groups.values())))
def required(label):
    return (4,5,6) if label.startswith('DEV2_') else (7,8,9) if label.startswith('DEV3_') else (20,21,22) if label.startswith('FINAL_') else (1,2,3)

for category in ('LEGAL_DEV1','LEGAL_DEV2','LEGAL_DEV3','LEGAL_FINAL','RESEARCH_ORACLE'):
    ranked=[]
    for label,runs in groups.items():
        own='RESEARCH_ORACLE' if label.startswith('ORACLE') else 'LEGAL_DEV2' if label.startswith('DEV2_') else 'LEGAL_DEV3' if label.startswith('DEV3_') else 'LEGAL_FINAL' if label.startswith('FINAL_') else 'LEGAL_DEV1'
        if own!=category:continue
        seeds=required(label)
        if set(seeds).issubset(runs):
            triplet=[runs[s]['survival_seconds'] for s in seeds]
            ranked.append((statistics.mean(triplet),label,triplet,sum(runs[s]['completed'] for s in seeds)))
    print(category)
    for mean,label,triplet,complete in sorted(ranked,reverse=True)[:args.top]:print(round(mean,1),label,triplet,'full',complete)
print('Running',[(label,seed,r.get('time',0.),r.get('alive')) for (label,seed),r in sorted(progress.items()) if seed not in groups[label]])
print('Partial',[(label,{s:r['survival_seconds'] for s,r in runs.items()}) for label,runs in groups.items() if runs and not set(required(label)).issubset(runs)])
