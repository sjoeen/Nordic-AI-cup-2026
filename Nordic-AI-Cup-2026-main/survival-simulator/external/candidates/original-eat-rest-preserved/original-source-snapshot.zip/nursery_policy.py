"""Resource-aware habitat protection and local obstacle detours."""
import math
from habitat_policy import HabitatPolicy,QUALITY
from lineage_policy import LineagePolicy
from species_field_trial import rotate,wrap,unit


def point_segment(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]
    t=max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/max(1e-9,dx*dx+dy*dy)))
    return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)


def segment_clear(a,b,edges,margin=6.):
    def cross(x,y,z):return (y[0]-x[0])*(z[1]-x[1])-(y[1]-x[1])*(z[0]-x[0])
    for c,d in edges:
        if cross(a,b,c)*cross(a,b,d)<0. and cross(c,d,a)*cross(c,d,b)<0.:return False
        if min(point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))<margin:return False
    return True


class NurseryMixin:
    def __init__(self,preset='nursery',**overrides):
        config=dict(planning=False,protect_habitat=True,nursery_birth=True,detours=True,
                    emergency_food=True,search_speed=.4,population=6,population_floor=2)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state)
        mem=view['mem'];c=self.config
        if c['protect_habitat'] and mem.home_quality>QUALITY.get(state['biome'],.4)+.1:
            view['max_fruit_distance']=40. if state['energy']>80. else 100.
        # Starvation is also an immediate threat: collect reachable food when
        # it increases separation from every nearby hunter.
        if c['emergency_food'] and state['energy']<60. and view['escaping']:
            terrain={'river':.3,'swamp':.5,'desert':.8}.get(state['biome'],1.)
            reachable=[]
            for f in view['fruits']:
                if f['obs']['distance']>min(state['speed'],state['sprint_speed'])*terrain+10.:continue
                if all(math.hypot(f['p'][0]-p['p'][0]-p['velocity'][0],f['p'][1]-p['p'][1]-p['velocity'][1])>35. for p in view['predators']):
                    reachable.append(f)
            if reachable:
                view['escaping']=False;view['fruits']=reachable
                self.metrics['emergency_food_ticks']+=1
        if c['detours']:
            old=[]
            for edge,seen in getattr(mem,'route_edges',[]):
                if self.clock-seen>15.:continue
                transformed=[]
                for p in edge:
                    q=rotate(p,-mem.last_turn)
                    transformed.append((q[0]-view['translation'][0],q[1]-view['translation'][1]))
                old.append((tuple(transformed),seen))
            for edge in view['edges']:
                old=[(e,t) for e,t in old if min(math.hypot(e[0][0]-edge[0][0],e[0][1]-edge[0][1])+math.hypot(e[1][0]-edge[1][0],e[1][1]-edge[1][1]),math.hypot(e[0][0]-edge[1][0],e[0][1]-edge[1][1])+math.hypot(e[1][0]-edge[0][0],e[1][1]-edge[0][1]))>2.]
                old.append((edge,self.clock))
            mem.route_edges=[(e,t) for e,t in old if point_segment((0.,0.),*e)<250.][-50:]
            if getattr(mem,'waypoint',None) is not None:
                q=rotate(mem.waypoint,-mem.last_turn)
                mem.waypoint=(q[0]-view['translation'][0],q[1]-view['translation'][1])
        return view

    def steer(self,view):
        s,mem,c=view['state'],view['mem'],self.config
        action=super().steer(view)
        if action.spawn_agent and c['nursery_birth']:
            quality=QUALITY.get(s['biome'],.4)
            if quality<max(.3,mem.home_quality-.1) and s['age']<90.:
                action.spawn_agent=False
        if not c['detours'] or view['escaping'] or action.move_distance<=0.:return action
        target=view['visible'].get(mem.target_id)
        if target is not None:goal=target['p']
        else:goal=(math.cos(action.move_direction)*100.,math.sin(action.move_direction)*100.)
        edges=[e for e,t in mem.route_edges]
        if segment_clear((0.,0.),goal,edges):
            mem.waypoint=None
            return action
        waypoint=getattr(mem,'waypoint',None)
        if waypoint is None or math.hypot(*waypoint)<10. or self.clock>=getattr(mem,'waypoint_until',0.) or not segment_clear((0.,0.),waypoint,edges,4.):
            candidates=[]
            for edge in edges:
                for endpoint in edge:
                    if math.hypot(*endpoint)>250.:continue
                    for i in range(8):
                        theta=i*math.pi/4
                        p=(endpoint[0]+10.*math.cos(theta),endpoint[1]+10.*math.sin(theta))
                        if math.hypot(*p)<10. or not segment_clear((0.,0.),p,edges):continue
                        distance=math.hypot(*p)+math.hypot(p[0]-goal[0],p[1]-goal[1])
                        if not segment_clear(p,goal,edges):distance+=35.
                        candidates.append((distance,p))
            if not candidates:return action
            _,waypoint=min(candidates)
            mem.waypoint=waypoint;mem.waypoint_until=self.clock+2.
        direction,slid=self.slide(unit(waypoint),view,action.move_distance)
        action.move_direction=math.atan2(direction[1],direction[0])
        if target is None or math.hypot(*waypoint)>s['hearing_radius']:
            action.turn_angle=max(-.6,min(.6,action.move_direction))
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        mem.last_move=tuple(v*action.move_distance*terrain for v in direction)
        mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction)
        self.metrics['detour_ticks']+=1
        return action


class NurseryPolicy(NurseryMixin,HabitatPolicy):pass
class NurseryLineage(NurseryMixin,LineagePolicy):pass
