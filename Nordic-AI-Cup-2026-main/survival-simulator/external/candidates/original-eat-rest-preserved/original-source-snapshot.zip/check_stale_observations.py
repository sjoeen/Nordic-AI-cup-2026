import math
from strategy_lab import SurvivalPolicy
from species_field_trial import Memory

policy=SurvivalPolicy('direct',stale_correction=True)
policy.memory[1]=Memory(last_age=1.,last_move=(10.,0.),last_turn=math.pi/2)
s=dict(agent_id=1,age=1.,energy=150.,speed=10.,sprint_speed=20.,max_energy=500.,biome='forest',
       hearing_radius=50.,vision_range=200.,vision_angle=math.pi/3,
       observations=[dict(type='Fruit',distance=100.,angle=0.)])
view=policy.observe(s)
fruit=view['fruits'][0]
assert abs(fruit['obs']['distance']-90.)<1e-7
assert abs(fruit['obs']['angle']+math.pi/2)<1e-7
assert policy.metrics['stale_observation_corrections']==1
print('Stale observation transform passed')
