import math
from dispersal_policy import DispersalPolicy
from memory_policy import MemoryPolicy
from path_policy import PathPolicy
from species_field_trial import rotate,wrap,unit
from src.utils.controllers.potential_field_policy import closest_point


class ColonizeMemory(DispersalPolicy,MemoryPolicy):
    def __init__(self,preset='colonize_memory',**overrides):
        config=dict(dispersal_distance=100.,wall_follow=False,stuck_recovery=False,fruit_memory_seconds=10.)
        config.update(overrides);super().__init__(preset,**config)


class ColonizePath(DispersalPolicy,PathPolicy):
    def __init__(self,preset='colonize_path',**overrides):
        config=dict(dispersal_distance=100.,wall_follow=False,stuck_recovery=False,fruit_memory_seconds=10.)
        config.update(overrides);super().__init__(preset,**config)


class RecoverPolicy(DispersalPolicy):
    def __init__(self,preset='recover',**overrides):
        config=dict(dispersal_distance=100.,recovery_window=2.,recovery_seconds=1.)
        config.update(overrides);super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        if not hasattr(mem,'motion_anchor'):
            mem.motion_anchor=(0.,0.);mem.motion_since=self.clock;mem.motion_distance=0.
            mem.recover_until=-1.
        anchor=rotate(mem.motion_anchor,-mem.last_turn)
        mem.motion_anchor=(anchor[0]-view['translation'][0],anchor[1]-view['translation'][1])
        mem.motion_distance+=math.hypot(*view['translation'])
        if self.clock-mem.motion_since>=self.config['recovery_window']:
            if mem.last_mode in ('EAT','SEARCH') and mem.motion_distance>40. and math.hypot(*mem.motion_anchor)<min(20.,mem.motion_distance*.2):
                if view['edges']:
                    edge=min(view['edges'],key=lambda e:math.hypot(*closest_point(e)))
                    theta=math.atan2(edge[1][1]-edge[0][1],edge[1][0]-edge[0][0])
                    if state['agent_id']%2:theta+=math.pi
                else:theta=mem.rng.uniform(-math.pi,math.pi)
                mem.recover_heading=wrap(mem.heading+theta)
                mem.recover_until=self.clock+self.config['recovery_seconds'];mem.target_id=None
                self.metrics['loop_recoveries']+=1
            mem.motion_anchor=(0.,0.);mem.motion_since=self.clock;mem.motion_distance=0.
        return view

    def allocate(self,views):
        for view in views.values():
            if self.clock<view['mem'].recover_until:view['eligible']=False
        super().allocate(views)

    def steer(self,view):
        action=super().steer(view);mem=view['mem'];s=view['state']
        if self.clock>=mem.recover_until or view['escaping']:return action
        theta=wrap(mem.recover_heading-mem.heading)
        speed=min(s['speed'],s['sprint_speed'])
        direction,_=self.slide((math.cos(theta),math.sin(theta)),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0]);action.turn_angle=action.move_direction
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        mem.last_move=tuple(v*speed*terrain for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.last_mode='RECOVER'
        return action
