import sys
from campaign_runner import run

CASES=[
 ('colony_local', 'colony2_policy:ColonyPolicy',{'local_colonization':True}),
 ('colony_late', 'colony2_policy:ColonyPolicy',{'late_colonization':True}),
 ('colony_outward', 'colony2_policy:ColonyPolicy',{'outward_colonization':True}),
 ('rest_hysteresis180', 'colony2_policy:ColonyPolicy',{'rest_hysteresis':180.}),
 ('rest_hysteresis_food', 'colony2_policy:ColonyPolicy',{'rest_hysteresis':180.,'rest_release_food':80.}),
 ('patch2_hold30', 'patch2_policy:PatchPolicy',{'tree_hold':30.}),
 ('patch2_hold4', 'patch2_policy:PatchPolicy',{'tree_hold':4.}),
 ('patch2_range80', 'patch2_policy:PatchPolicy',{'tree_range':80.}),
 ('ripen6', 'dispersal_policy:DispersalPolicy',{'dispersal_distance':100.,'ripen_seconds':6.}),
 ('ripen14', 'dispersal_policy:DispersalPolicy',{'dispersal_distance':100.,'ripen_seconds':14.}),
]
if __name__=='__main__':
    for label,name,config in CASES:run(int(sys.argv[1]),name,config,label)
