"""Original full-size block, permissive reproduction, mapped food only."""
import json
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from campaign_feeding_queue import complete, evaluate

if __name__ == '__main__':
    while not all(complete(label,seed) for label in ('loose_control','loose_route2','loose_route3','loose_late_route2','loose_children','loose_late_food') for seed in (1,2,3)):
        time.sleep(10.)
    groups = [
        ('food_map_policy:FoodMapPolicy', [
            ('loose_map_now', {'food_map_memory':0.}),
            ('loose_map_memory', {'food_map_memory':8.}),
            ('loose_map_late', {'food_map_memory':8.,'food_map_start':900.}),
        ]),
        ('food_map_policy:MappedHarvestPolicy', [
            ('loose_map_routes', {'food_map_memory':8.}),
        ]),
    ]
    for module,cases in groups:
        with ProcessPoolExecutor(max_workers=3) as pool:
            jobs = [pool.submit(evaluate,(module,label,config,seed))
                    for label,config in cases for seed in (1,2,3)]
            for future in as_completed(jobs):
                print(json.dumps(future.result()),flush=True)
