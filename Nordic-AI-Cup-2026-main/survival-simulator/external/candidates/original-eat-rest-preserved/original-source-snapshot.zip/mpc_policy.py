"""Short-horizon food/escape action selection with observed predator rest phases."""
import math
from strategy_lab import SurvivalPolicy
from species_field_trial import rotate,wrap,unit
from src.utils.DTOs import ActionRequest


class PredictiveForager(SurvivalPolicy):
    def __init__(self,preset='mpc',**overrides):
        config=dict(escape='direct',gaze_turn=math.pi,search_speed=.4,scan=.25,
                    phase_model=True,food_weight=.6,safety_margin=22.,horizon=5,planning=True)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state)
        mem=view['mem']
        previous=[]
        for old in getattr(mem,'phase_history',[]):
            q=rotate(old['p'],-mem.last_turn)
            q=(q[0]-view['translation'][0],q[1]-view['translation'][1])
            previous.append((q,old))
        for enemy in view['predators']:
            enemy['rest_start']=None
            enemy['moving']=math.hypot(*enemy['velocity'])>.5
            if previous:
                q,old=min(previous,key=lambda x:math.hypot(enemy['p'][0]-x[0][0],enemy['p'][1]-x[0][1]))
                if math.hypot(enemy['p'][0]-q[0],enemy['p'][1]-q[1])<18.:
                    if not enemy['moving']:
                        if old['moving']:
                            enemy['rest_start']=self.clock
                        else:
                            enemy['rest_start']=old.get('rest_start')
            if enemy['rest_start'] is not None:
                self.metrics['known_rest_ticks']+=1
        mem.phase_history=[dict(p) for p in view['predators']]
        # Allocation is independent of danger; safety is checked on candidate
        # trajectories, so safe fruit remains usable while a predator rests.
        if self.config['planning']:view['escaping']=False
        return view

    def steer(self,view):
        s,mem,c=view['state'],view['mem'],self.config
        previous_move=rotate(mem.last_move,-mem.last_turn)
        base=super().steer(view)
        enemies=view['predators']
        if not c['planning'] or not enemies or enemies[0]['obs']['distance']>190.:
            return base
        walk=min(s['speed'],s['sprint_speed'])
        terrain={'swamp':.5,'river':.3,'desert':.8}.get(s['biome'],1.)
        target=view['visible'].get(mem.target_id)
        goal=target['p'] if target is not None else None
        away=math.atan2(-enemies[0]['p'][1],-enemies[0]['p'][0])
        directions=[base.move_direction]
        if goal is not None:directions.append(math.atan2(goal[1],goal[0]))
        directions += [away+i*math.pi/6 for i in range(-4,5)]
        if math.hypot(*previous_move)>.1:directions.append(math.atan2(previous_move[1],previous_move[0]))
        speeds=[walk]
        if base.move_distance<walk-.01:speeds.append(base.move_distance)
        if s['energy']>.2*s['max_energy']+8 and s['sprint_speed']>walk+.01:
            speeds.append(s['sprint_speed'])
        if enemies[0]['obs']['distance']>50.:speeds.append(0.)
        choices=[]
        horizon=c['horizon']
        for speed in speeds:
            for angle in directions:
                desired,slid=self.slide((math.cos(angle),math.sin(angle)),view,speed)
                vx,vy=desired[0]*speed*terrain,desired[1]*speed*terrain
                minimum=math.inf
                ending=math.inf
                for enemy in enemies[:4]:
                    px,py=enemy['p'];ph=enemy['heading']
                    if enemy['moving']:
                        px+=enemy['velocity'][0];py+=enemy['velocity'][1]
                    rest=enemy.get('rest_start')
                    remaining=(2.6-(self.clock-rest))*10. if c['phase_model'] and rest is not None else 0.
                    for h in range(1,horizon+1):
                        ax,ay=vx*h,vy*h
                        if h>=remaining:
                            bearing=math.atan2(ay-py,ax-px)
                            dist=math.hypot(ax-px,ay-py)
                            # Facing the nearest threat invokes its flank
                            # behavior at >=90; otherwise bounded-turn chase.
                            if enemy is enemies[0] and dist>=90.:
                                move_angle=bearing+math.pi/4
                                px+=15.*terrain*math.cos(move_angle)
                                py+=15.*terrain*math.sin(move_angle)
                                ph=math.atan2(ay-py,ax-px)
                            else:
                                ph=wrap(ph+max(-.3,min(.3,wrap(bearing-ph)*.5)))
                                px+=15.*terrain*math.cos(ph)
                                py+=15.*terrain*math.sin(ph)
                        minimum=min(minimum,math.hypot(ax-px,ay-py))
                    ending=min(ending,math.hypot(ax-px,ay-py))
                movement_cost=(.05*min(speed,walk)+.5*max(0.,speed-walk))*horizon
                progress=0.
                bonus=0.
                if goal is not None:
                    d0=math.hypot(*goal)
                    distances=[math.hypot(goal[0]-vx*h,goal[1]-vy*h) for h in range(1,horizon+1)]
                    progress=d0-min(distances)
                    if min(distances)<11.:
                        bonus=30.
                else:
                    progress=(vx*math.cos(base.move_direction)+vy*math.sin(base.move_direction))*horizon*.25
                risk=1000.*max(0.,c['safety_margin']-minimum)+.02*max(0.,65.-minimum)**2
                score=c['food_weight']*progress+bonus-movement_cost*1.2-risk+.025*min(ending,180.)
                choices.append((score,speed,desired,minimum))
        _,speed,desired,clearance=max(choices,key=lambda x:x[0])
        direction=math.atan2(desired[1],desired[0])
        turn=wrap(enemies[0]['obs']['angle'])
        mem.last_move=(desired[0]*speed*terrain,desired[1]*speed*terrain)
        mem.last_turn=turn
        if speed>0:mem.search_heading=wrap(mem.heading+direction)
        mem.last_mode='PLAN'
        self.metrics['plan_ticks']+=1
        self.metrics['plan_fruit_ticks']+=int(target is not None)
        self.metrics['plan_sprint_ticks']+=int(speed>walk+.01)
        return ActionRequest(agent_id=s['agent_id'],move_distance=speed,move_direction=direction,
                             turn_angle=turn,spawn_agent=base.spawn_agent and enemies[0]['obs']['distance']>140.)
