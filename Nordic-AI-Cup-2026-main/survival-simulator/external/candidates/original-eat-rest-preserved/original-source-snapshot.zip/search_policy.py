"""Search both the original controller and optional generation safeguards."""
from state_policy import StatePolicy
from gap_policy import GapPolicy


class SearchPolicy(StatePolicy,GapPolicy):
    def __init__(self,preset='search_policy',state_weights=None,**overrides):
        weights=[0.]*15 if state_weights is None else list(state_weights)
        assert len(weights)==15
        self.gap_gene=float(weights[14])
        overrides['maximum_birth_gap']=20. if self.gap_gene>0. else 1e9
        super().__init__(preset,state_weights=weights[:14],**overrides)
