"""Run headless comparisons against the original simulator, without patches.

Example: python benchmark.py --seeds 1 2 3 4 5 --policies dummy greedy field
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import time

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

from src.core import SimulationCore
from src.utils.controllers.dummy_agent_policy import action_decision as dummy
from src.utils.controllers.potential_field_policy import PotentialFieldPolicy


def run(seed, policy_name, limit=3000, progress=100):
    started = time.perf_counter()
    sim = SimulationCore(seed=seed)
    setup_seconds = time.perf_counter() - started
    rng = random.Random(seed)
    policy = PotentialFieldPolicy(fields=policy_name == "field")
    actions = []
    policy_seconds = 0.0
    policy_calls = 0
    peak_agents = len(sim.env.agents)
    trace = []
    next_progress = progress
    initial = hashlib.sha256(json.dumps({
        "agents": [(a.x, a.y, a.direction) for a in sim.env.agents],
        "fruits": [(a.x, a.y) for a in sim.env.fruits],
        "trees": [(a.x, a.y, a.age) for a in sim.env.trees],
        "obstacles": [(a.x, a.y, a.width, a.height) for a in sim.env.obstacles],
        "rng": repr(sim.rng.getstate()),
    }, sort_keys=True).encode()).hexdigest()
    for tick in range(round(limit / sim.dt)):
        state = sim.step(actions)
        peak_agents = max(peak_agents, state["num_agents"])
        if tick % 100 == 0 or not state["num_agents"] or tick == round(limit / sim.dt) - 1:
            trace.append({"time": round(state["sim_time"], 2), "score": state["score"],
                          "agents": state["num_agents"], "predators": len(sim.env.predators),
                          "fruits": len(sim.env.fruits), "trees": len(sim.env.trees)})
        if state["sim_time"] >= next_progress:
            print(json.dumps({"event": "progress", "seed": seed, "policy": policy_name,
                              "time": round(state["sim_time"], 1), "agents": state["num_agents"],
                              "score": round(state["score"], 2)}), flush=True)
            next_progress += progress
        if state["num_agents"] == 0:
            break
        start = time.perf_counter()
        actions = []
        for observation in state["observations"]:
            action = dummy(observation, rng) if policy_name == "dummy" else policy.decide(observation)
            actions.append((action.agent_id, action))
        policy_seconds += time.perf_counter() - start
        policy_calls += len(actions)
    result = {
        "seed": seed, "policy": policy_name, "survival_seconds": round(state["sim_time"], 3),
        "score": state["score"], "completed": bool(state["num_agents"] > 0 and tick + 1 >= round(limit / sim.dt)),
        "limit_seconds": limit, "agents_remaining": state["num_agents"], "peak_agents": peak_agents,
        "total_agents_born": sim.env._next_agent_id, "initial_state_sha256": initial,
        "controller_seconds": policy_seconds, "controller_calls": policy_calls,
        "controller_microseconds_per_agent": policy_seconds * 1e6 / max(1, policy_calls),
        "setup_seconds": setup_seconds, "wall_seconds": time.perf_counter() - started,
        "trace": trace,
    }
    print(json.dumps({"event": "result", **{k: v for k, v in result.items() if k != "trace"}}), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", nargs="+", type=int, default=[1, 2, 3, 4, 5])
    parser.add_argument("--policies", nargs="+", choices=["dummy", "greedy", "field"], default=["dummy", "greedy", "field"])
    parser.add_argument("--limit", type=float, default=3000)
    parser.add_argument("--output", default="benchmark_results.json")
    args = parser.parse_args()
    results = []
    for seed in args.seeds:
        for name in args.policies:
            results.append(run(seed, name, args.limit))
            Path(args.output).write_text(json.dumps(results, indent=2) + "\n")
