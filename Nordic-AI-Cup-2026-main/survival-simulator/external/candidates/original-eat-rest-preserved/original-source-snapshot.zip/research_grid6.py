import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('islands',{'label':'local_lineages'}),
 ('islands',{'label':'local_lineages_no_dispersion','dispersal_seconds':0.}),
 ('islands',{'label':'independent_families','local_population':3,'population':16,'population_floor':6,'crowd_escape':True,'territory_radius':180.}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid6_{seed}.jsonl')
