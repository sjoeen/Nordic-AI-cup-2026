"""Small, observable-state controller searched by black-box optimization.

Fourteen coefficients adjust existing choices. Zero coefficients exactly recover
the tested dispersal controller; no simulator internals enter decisions.
"""
import math
from dispersal_policy import DispersalPolicy


def bounded(value,low,high):return min(high,max(low,value))


class StatePolicy(DispersalPolicy):
    def __init__(self,preset='state_policy',**overrides):
        config=dict(dispersal_distance=100.,state_weights=[0.]*14)
        config.update(overrides);super().__init__(preset,**config)
        self.weights=tuple(float(x) for x in self.config['state_weights'])
        assert len(self.weights)==14
        self.base=dict(self.config);self.stage=0.

    def decide_all(self,states,sim_time=None):
        t=float(sim_time) if sim_time is not None else self.clock+.1
        self.stage=bounded(t/1200.,0.,1.)
        w=self.weights;c=self.config;b=self.base
        c['birth_energy']=bounded(b['birth_energy']*math.exp(w[5]+w[6]*self.stage),140.,260.)
        c['population']=bounded(b['population']*math.exp(w[9]),4.,12.)
        c['population_floor']=round(bounded(b['population_floor']*math.exp(w[10]),2.,6.))
        c['young_age']=bounded(b['young_age']*math.exp(w[11]),40.,85.)
        c['dispersal_distance']=bounded(b['dispersal_distance']*math.exp(w[12]+w[13]*self.stage),20.,200.)
        return super().decide_all(states,sim_time)

    def allocate(self,views):
        for aid,v in views.items():
            s=v['state'];age=bounded((s['age']-60.)/60.,0.,1.)
            reserve=bounded(self.base['hard_idle_energy']*math.exp(self.weights[7]+self.weights[8]*age),180.,400.)
            v['resting']=aid in self.retired_ids or (s['energy']>min(reserve,self.config['idle_energy']*s['max_energy']) and aid not in self.spawn_ids)
            v['eligible']=not v['resting']
        super().allocate(views)

    def steer(self,view):
        c=self.config;w=self.weights;b=self.base
        hunger=bounded((150.-view['state']['energy'])/150.,-1.,1.)
        previous=(c['search_speed'],c['scan'])
        c['search_speed']=bounded(b['search_speed']*math.exp(w[0]+w[1]*hunger+w[2]*self.stage),.1,1.)
        c['scan']=bounded(b['scan']*math.exp(w[3]+w[4]*self.stage),.05,.6)
        try:return super().steer(view)
        finally:c['search_speed'],c['scan']=previous
