"""Minimal-intervention pursuit filter on the unchanged colony controller."""
import math
from dispersal_policy import DispersalPolicy
from species_field_trial import wrap,rotate
from safety_policy import chase_step,resolve_motion
from nursery_policy import segment_clear


class GuardColony(DispersalPolicy):
    def __init__(self,preset='guard_colony',**overrides):
        config=dict(dispersal_distance=100.,guard_horizon=3,guard_margin=25.,
                    guard_food=.8,guard_cost=1.3,guard_speed='inferred',
                    guard_collisions=False,guard_rest=True,guard_vision=False,
                    guard_radius=0.,guard_phase=True)
        config.update(overrides);super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem'];c=self.config
        history=[]
        for old in getattr(mem,'guard_history',[]):
            p=rotate(old['p'],-mem.last_turn)
            history.append(((p[0]-view['translation'][0],p[1]-view['translation'][1]),old))
        for enemy in view['predators']:
            enemy['rest_start']=None
            enemy['moving']=not enemy['measured'] or math.hypot(*enemy['velocity'])>.5
            if history and enemy['measured']:
                p,old=min(history,key=lambda item:math.hypot(item[0][0]-enemy['p'][0],item[0][1]-enemy['p'][1]))
                if math.hypot(p[0]-enemy['p'][0],p[1]-enemy['p'][1])<18. and not enemy['moving']:
                    enemy['rest_start']=self.clock if old['moving'] else old.get('rest_start')
        mem.guard_history=[dict(p) for p in view['predators']]
        view['guard_needed']=view['escaping'] or (c['guard_radius'] and any(p['obs']['distance']<c['guard_radius'] for p in view['predators']))
        # Critical threats still invoke the filter, but safe fruit can be allocated.
        view['escaping']=False
        return view

    def steer(self,view):
        s,mem,c=view['state'],view['mem'],self.config
        previous=rotate(mem.last_move,-mem.last_turn)
        base=super().steer(view)
        if not view['guard_needed'] or not view['predators']:return base
        enemies=[p for p in view['predators'] if p['obs']['distance']<190.][:4]
        if not enemies:return base
        terrain={'swamp':.5,'river':.3,'desert':.8}.get(s['biome'],1.)
        walk=min(s['speed'],s['sprint_speed']);h=c['guard_horizon']
        target=view['visible'].get(mem.target_id);goal=target['p'] if target else None
        gaze=enemies[0]['obs']['angle']+.02
        gaze=wrap(gaze)
        models=[]
        for enemy in enemies:
            rest=enemy.get('rest_start')
            sleeping=max(0.,(3.0-(self.clock-rest))*10.) if c['guard_phase'] and rest is not None else 0.
            measured=math.hypot(*enemy['velocity']);speed=15.
            if c['guard_speed']=='measured':speed=max(15.*terrain,measured)
            elif c['guard_speed']=='inferred' and enemy['measured'] and measured>.5:
                factor=min((.3,.5,.8,1.),key=lambda f:min(abs(measured-11.*f),abs(measured-15.*f)))
                speed=15.*factor
            p,heading=enemy['p'],enemy['heading']
            if sleeping<1.:
                old=p;p,heading=chase_step(p,heading,(0.,0.),0.,speed,c['guard_vision'])
                if c['guard_collisions']:p=resolve_motion(old,p,view['edges'],10.)
            models.append((p,heading,speed,sleeping))
        speeds={.5*walk,walk,base.move_distance}
        if c['guard_rest']:speeds.add(0.)
        if s['energy']>.2*s['max_energy']+3.:
            speeds.update(((walk+s['sprint_speed'])/2.,s['sprint_speed']))
        away=math.atan2(-enemies[0]['p'][1],-enemies[0]['p'][0])
        angles=[base.move_direction,math.atan2(previous[1],previous[0])]
        angles.extend(away+i*math.pi/8 for i in range(-8,8))
        if goal:angles.append(math.atan2(goal[1],goal[0]))
        options=[]
        base_v=(base.move_distance*terrain*math.cos(base.move_direction),base.move_distance*terrain*math.sin(base.move_direction))
        for speed in sorted(speeds):
            for angle in angles if speed else [0.]:
                direction,_=self.slide((math.cos(angle),math.sin(angle)),view,speed)
                v=(direction[0]*speed*terrain,direction[1]*speed*terrain)
                positions=[];a=(0.,0.)
                for tick in range(1,h+1):
                    desired=(a[0]+v[0],a[1]+v[1])
                    a=resolve_motion(a,desired,view['edges'],5.) if c['guard_collisions'] else desired
                    positions.append(a)
                clearance=math.inf;end=math.inf
                for p,heading,pspeed,sleeping in models:
                    for tick,a in enumerate(positions,1):
                        if tick+1>=sleeping:
                            old=p;p,heading=chase_step(p,heading,a,gaze,pspeed,c['guard_vision'])
                            if c['guard_collisions']:p=resolve_motion(old,p,view['edges'],10.)
                        clearance=min(clearance,math.hypot(a[0]-p[0],a[1]-p[1]))
                    end=min(end,math.hypot(a[0]-p[0],a[1]-p[1]))
                cost=(.05*min(speed,s['speed'])+.5*max(0.,speed-s['speed']))*h
                progress=eat=0.
                if goal:
                    remaining=min(math.hypot(goal[0]-p[0],goal[1]-p[1]) for p in positions)
                    progress=math.hypot(*goal)-remaining
                    if remaining<10.:eat=25.*min(2.,100./max(s['energy'],50.))
                danger=1000.*max(0.,c['guard_margin']-clearance)+.015*max(0.,60.-clearance)**2
                wall=50. if not segment_clear((0.,0.),(v[0]*h,v[1]*h),view['edges'],4.) else 0.
                score=c['guard_food']*progress+eat-c['guard_cost']*cost-.15*math.hypot(v[0]-base_v[0],v[1]-base_v[1])-danger-wall+.02*min(160.,end)
                options.append((score,speed,direction))
        _,speed,direction=max(options,key=lambda x:x[0]);angle=math.atan2(direction[1],direction[0])
        base.move_distance=speed;base.move_direction=angle;base.turn_angle=gaze
        mem.last_move=(direction[0]*speed*terrain,direction[1]*speed*terrain);mem.last_turn=gaze
        if speed:mem.search_heading=wrap(mem.heading+angle)
        mem.last_mode='GUARD';self.metrics['guard_ticks']+=1
        self.metrics['guard_sprint_ticks']+=int(speed>walk+.01)
        self.metrics['guard_stationary_ticks']+=int(speed==0.)
        return base
