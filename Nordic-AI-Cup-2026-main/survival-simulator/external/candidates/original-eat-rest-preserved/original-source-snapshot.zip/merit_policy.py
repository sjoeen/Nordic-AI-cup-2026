"""Select parents using trait floors or measured food intake, all observable."""
import math
from breeding2_policy import BreedingPolicy


class MeritPolicy(BreedingPolicy):
    def __init__(self,preset='merit',**overrides):
        config=dict(merit_mode='floors',vision_floor=150.,hearing_floor=35.,sprint_merit=0.)
        config.update(overrides);super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        old=getattr(mem,'merit_previous',None)
        if old:
            energy,cost=old;gain=state['energy']-energy+cost
            if gain>5.:mem.merit_intake=getattr(mem,'merit_intake',0.)+gain
        return view

    def fitness(self,s):
        c=self.config;walk=max(.1,min(s['speed'],s['sprint_speed']))
        base=walk+.015*s['hearing_radius']+.003*s['vision_range']
        if c['merit_mode'] in ('intake','mixed'):
            food=getattr(self.memory[s['agent_id']],'merit_intake',0.)
            rate=(food+100.)/(s['age']+15.)
            return rate if c['merit_mode']=='intake' else base*math.sqrt(max(.1,rate))
        if c['merit_mode']=='capacity':
            fertility=min(1.,max(.01,(s['max_energy']-110.)/90.))
            return base*fertility*(500./max(150.,s['max_energy']))**.3
        floor=min(1.,s['vision_range']/c['vision_floor'])*min(1.,s['hearing_radius']/c['hearing_floor'])
        floor*=min(1.,s['vision_angle']/.8)
        return (base+c['sprint_merit']*min(20.,s['sprint_speed']))*floor

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time);byid={s['agent_id']:s for s in states}
        for a in actions:
            s=byid[a.agent_id]
            cost=.1+.05*min(a.move_distance,s['speed'])+.5*max(0.,a.move_distance-s['speed'])+min(math.pi,abs(a.turn_angle))/(2*math.pi)+100.*a.spawn_agent
            self.memory[a.agent_id].merit_previous=(s['energy'],cost)
        return actions
