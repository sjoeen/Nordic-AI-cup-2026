"""Public-observation feeding and reproduction experiments.

Navigation, predator recognition, and escape steering are inherited unchanged.
"""
import math
from collections import deque
from dispersal_policy import DispersalPolicy


class SustenancePolicy(DispersalPolicy):
    def __init__(self, preset='sustenance', **overrides):
        config = dict(dispersal_distance=100., feeding='baseline', breeding='baseline',
                      feeding_fraction=.85, generation_spacing=35.,
                      parent_reserve=100., birth_target_age=60.,
                      feeding_distance=180., food_surplus=2., late_colony=2.)
        config.update(overrides)
        if config['breeding'] != 'baseline':
            config['emergency_birth'] = False
        super().__init__(preset, **config)
        self.meals = deque()

    def observe(self, state):
        old = self.memory.get(state['agent_id'])
        residual = state['energy'] - getattr(old, 'sustain_energy', state['energy']) + getattr(old, 'sustain_cost', 0.)
        v = super().observe(state)
        m = v['mem']
        m.sustain_energy = state['energy']
        if residual > 5.:
            self.meals.append((self.clock, residual))
            m.last_meal_time = self.clock
            self.metrics['public_food_gain'] += residual
        if state['age'] > 60. and -.015*state['age'] < residual < -.005*state['age']:
            m.sustain_aging = getattr(m, 'sustain_aging', 0) + 1
        return v

    def allocate(self, views):
        c = self.config
        while self.meals and self.meals[0][0] < self.clock-30.:
            self.meals.popleft()
        if c['breeding'] != 'baseline':
            self.spawn_ids = set()
            viable = [v for v in views.values() if v['state']['energy'] > 40.
                      and v['state']['age'] < c['birth_target_age']]
            cap = max(c['late_colony'], round(c['population'] * .5**(self.clock/c['population_decay'])))
            budget = max(0, int(cap-len(viable)))
            candidates = []
            for aid, v in views.items():
                s, m = v['state'], v['mem']
                if v['escaping']:
                    continue
                if v['predators'] and min(p['obs']['distance'] for p in v['predators']) < 130.:
                    continue
                if self.clock-getattr(m, 'sustain_last_birth', -1000.) < c['generation_spacing']:
                    continue
                walk = max(.1, min(s['speed'], s['sprint_speed']))
                terrain = {'river':.3, 'swamp':.5, 'desert':.8}.get(s['biome'], 1.)
                foods = [f for f in v['fruits'] if 10. < f['obs']['distance'] < c['feeding_distance']]
                food_cost = min((max(0., f['obs']['distance']-10.)/terrain * (.05+.1/walk)
                                 for f in foods), default=math.inf)
                child_supported = food_cost < 40. or any(o['type']=='Tree' and o['distance'] < 75.
                                                       for o in s['observations'])
                aging = getattr(m, 'sustain_aging', 0) >= 2
                replacing = (s['age'] >= c['birth_target_age'] or aging) and len(viable) < cap
                threshold = 100. + c['parent_reserve']
                if replacing:
                    threshold = max(135., 100. + min(c['parent_reserve'], 40.+food_cost))
                if len(views) <= 2 and s['age'] > 75.:
                    threshold = 135.
                    child_supported = True
                if s['energy'] <= threshold or not child_supported:
                    continue
                if s['age'] < 20. and s['energy'] < 300.:
                    continue
                quality = min(s['speed'],s['sprint_speed'])+.015*s['hearing_radius']+.003*s['vision_range']
                candidates.append((replacing, quality, s['energy'], -aid, aid))
            self.spawn_ids = {x[-1] for x in sorted(candidates, reverse=True)[:budget]}
            # Retirement is released if replacements are not yet viable.
            if len(viable) < 2:
                self.retired_ids = set()
        if c['feeding'] != 'baseline':
            for aid, v in views.items():
                s = v['state']
                if aid in self.retired_ids:
                    continue
                walk = max(.1,min(s['speed'],s['sprint_speed']))
                terrain = {'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
                profitable = any(10. < f['obs']['distance'] and
                                 (f['obs']['distance']-10.)/terrain*(.05+.1/walk) < 20.-c['food_surplus']
                                 for f in v['fruits'])
                reserve = min(s['max_energy']*c['feeding_fraction'], 450.)
                if c['feeding'] == 'opportunity':
                    reserve = reserve if profitable else min(250., reserve)
                v['resting'] = s['energy'] >= reserve and aid not in self.spawn_ids
                v['eligible'] = not v['resting']
        super().allocate(views)

    def decide_all(self, states, sim_time=None):
        if sim_time is not None and sim_time < self.clock:
            self.meals.clear()
        actions = super().decide_all(states, sim_time)
        by_id = {s['agent_id']:s for s in states}
        for a in actions:
            s, m = by_id[a.agent_id], self.memory[a.agent_id]
            cost = .1 + min(math.pi,abs(a.turn_angle))/(2*math.pi)
            cost += .05*min(a.move_distance,s['speed']) + .5*max(0.,a.move_distance-s['speed'])
            if c_breeding := self.config['breeding'] != 'baseline':
                # The final movement cost is known only after steering.
                if a.spawn_agent and (m.last_mode in ('ESCAPE','CROWD_ESCAPE') or s['energy'] < 112.+cost):
                    a.spawn_agent = False
            if a.spawn_agent:
                m.sustain_last_birth = self.clock
                cost += 100.
            m.sustain_cost = cost
        return actions
