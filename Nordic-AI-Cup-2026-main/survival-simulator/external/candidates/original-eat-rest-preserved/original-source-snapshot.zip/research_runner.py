"""Unchanged simulator, public-observation policies, same seeds and time limit."""
import argparse
from collections import Counter,deque
import inspect
import hashlib
import json
import os
from pathlib import Path
import statistics
import time
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT','1')
os.environ.setdefault('SDL_VIDEODRIVER','dummy')
os.environ.setdefault('SDL_AUDIODRIVER','dummy')
from src.core import SimulationCore
from src.elements.environment import Environment
from hierarchical_field_trial import initial_hash
from species_field_trial import SpeciesFields
from strategy_lab import SurvivalPolicy, MappedPolicy
from atlas_policy import AtlasPolicy
from mpc_policy import PredictiveForager
from habitat_policy import HabitatPolicy
from lineage_policy import LineagePolicy
from nursery_policy import NurseryPolicy, NurseryLineage
from safety_policy import SafetyPolicy
from adaptive_policy import AdaptivePolicy
from alarm_policy import AlarmPolicy
from camp_policy import CampPolicy
from refuge_policy import RefugePolicy
from island_policy import IslandPolicy
from sticky_policy import StickyPolicy
from memory_policy import MemoryPolicy
from path_policy import PathPolicy
from refuge_memory_policy import RefugeMemory,RefugePath
from dispersal_policy import DispersalPolicy
from foraging_policy import ForagingPolicy
from colonize_navigation import ColonizeMemory,ColonizePath,RecoverPolicy
from river_policy import RiverPolicy
from hybrid_policy import HybridPolicy
from accessible_policy import AccessiblePolicy
from mapped_colony import MappedColony,LearningColony
from decoy_policy import DecoyPolicy
from portfolio_policy import PortfolioPolicy
SOURCE_SHA256=hashlib.sha256(b''.join(Path(p).read_bytes() for p in ('research_runner.py','strategy_lab.py','atlas_policy.py','species_field_trial.py','mpc_policy.py','habitat_policy.py','lineage_policy.py','nursery_policy.py','safety_policy.py','adaptive_policy.py','alarm_policy.py','camp_policy.py','refuge_policy.py','island_policy.py','sticky_policy.py','memory_policy.py','path_policy.py','refuge_memory_policy.py','dispersal_policy.py','foraging_policy.py','colonize_navigation.py','river_policy.py','hybrid_policy.py','accessible_policy.py','mapped_colony.py','decoy_policy.py','portfolio_policy.py'))).hexdigest()


def run(seed,preset,overrides,limit=3000.,log=None,parity_candidate=None):
    started=time.perf_counter()
    factories={'portfolio':PortfolioPolicy,'decoy':DecoyPolicy,'mapped_colony':MappedColony,'learning_colony':LearningColony,'accessible':AccessiblePolicy,'hybrid':HybridPolicy,'river':RiverPolicy,'colonize_memory':ColonizeMemory,'colonize_path':ColonizePath,'recover':RecoverPolicy,'foraging':ForagingPolicy,'dispersal':DispersalPolicy,'refuge_memory':RefugeMemory,'refuge_path':RefugePath,'path':PathPolicy,'memory':MemoryPolicy,'sticky':StickyPolicy,'islands':IslandPolicy,'refuge':RefugePolicy,'camp':CampPolicy,'alarm':AlarmPolicy,'adaptive':AdaptivePolicy,'safety':SafetyPolicy,'nursery_lineage':NurseryLineage,'nursery':NurseryPolicy,'lineage':LineagePolicy,'habitat':HabitatPolicy,'mpc':PredictiveForager,'atlas':AtlasPolicy,'mapped':MappedPolicy}
    policy=SpeciesFields('tangent') if preset=='tangent' else factories.get(preset,SurvivalPolicy)(preset,**overrides)
    mirror=None
    if parity_candidate:
        import importlib.util
        import sys
        spec=importlib.util.spec_from_file_location('_candidate_parity',parity_candidate)
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
        spec.loader.exec_module(module);mirror=module.make_policy()
    sim=SimulationCore(seed=seed)
    reference=json.loads(Path('benchmark_results.json').read_text())
    matches=[r for r in reference if r['seed']==seed]
    digest=initial_hash(sim)
    if matches:
        assert digest==matches[0]['initial_state_sha256']
    deaths=[]; harvest=[]; rotten=[]; detailed_deaths=[]; recent_paths={}
    lines,start=inspect.getsourcelines(Environment.non_agent_step)
    eaten_line=next(start+i for i,line in enumerate(lines) if 'self.remove_fruit(fruit) # Remove fruit' in line)
    old_remove=sim.env.remove_fruit
    def record_remove(fruit):
        (harvest if inspect.currentframe().f_back.f_lineno==eaten_line else rotten).append(float(fruit.energy))
        old_remove(fruit)
    sim.env.remove_fruit=record_remove
    old_kill=sim.env.kill_agent
    def record_kill(agent):
        deaths.append((float(agent.age),float(agent.energy)))
        observed=sim.env.agent_observations.get(agent.agent_id,[])
        mem=policy.memory.get(agent.agent_id)
        nearest_food=min(sim.env.fruits,key=lambda f:(f.x-agent.x)**2+(f.y-agent.y)**2) if sim.env.fruits else None
        recent=list(recent_paths.get(agent.agent_id,[]))[-30:]+[(agent.x,agent.y)]
        traveled=sum(((a[0]-b[0])**2+(a[1]-b[1])**2)**.5 for a,b in zip(recent,recent[1:]))
        displacement=((recent[0][0]-agent.x)**2+(recent[0][1]-agent.y)**2)**.5
        detailed_deaths.append(dict(id=agent.agent_id,time=round(sim.env.time,1),age=round(float(agent.age),1),
            energy=round(float(agent.energy),2),speed=float(agent.speed),sprint_speed=float(agent.sprint_speed),vision=float(agent.vision_radius),
            hearing=float(agent.hearing_radius),vision_angle=float(agent.cone_angle),capacity=float(agent.max_energy),
            biome=sim.env.biome_map[min(max(int(agent.x),0),sim.env.width-1),min(max(int(agent.y),0),sim.env.height-1)].type,
            nearest_food=round(((nearest_food.x-agent.x)**2+(nearest_food.y-agent.y)**2)**.5,1) if nearest_food else None,
            nearest_food_energy=round(nearest_food.energy,1) if nearest_food else None,
            recent_travel=round(traveled,1),recent_displacement=round(displacement,1),
            mode=getattr(mem,'last_mode',None),fruits=sum(o['type']=='Fruit' for o in observed),
            predators=sum(o['type']=='Predator' for o in observed)))
        old_kill(agent)
    sim.env.kill_agent=record_kill
    actions=[]; peak=5; calls=0; controller_time=0.; trace=[]
    def emit(data):
        line=json.dumps(data)
        print(line,flush=True)
        if log:
            with open(log,'a') as f:
                f.write(line+'\n');f.flush();os.fsync(f.fileno())
    emit(dict(event='start',preset=preset,seed=seed,overrides=overrides,config=getattr(policy,'config',None),source_sha256=SOURCE_SHA256))
    for tick in range(round(limit/sim.dt)):
        state=sim.step(actions)
        for agent in sim.env.agents:
            recent_paths.setdefault(agent.agent_id,deque(maxlen=30)).append((agent.x,agent.y))
        if tick%100==0:recent_paths={a.agent_id:recent_paths[a.agent_id] for a in sim.env.agents}
        peak=max(peak,state['num_agents'])
        if (tick+1)%2000==0:
            p=dict(event='progress',preset=preset,seed=seed,time=round(state['sim_time'],1),alive=state['num_agents'],
                   score=round(state['score'],2),food=len(sim.env.fruits),trees=len(sim.env.trees),predators=len(sim.env.predators),
                   mean_energy=round(statistics.mean(a.energy for a in sim.env.agents),1) if sim.env.agents else 0.)
            p['biomes']=dict(Counter(s['biome'] for s in state['observations']))
            trace.append(p);emit(p)
        if not state['num_agents']:break
        t=time.perf_counter()
        if preset=='tangent':decoded=policy.decide_all(state['observations'])
        else:decoded=policy.decide_all(state['observations'],state['sim_time'])
        if mirror is not None:
            exported=mirror.decide_all(state['observations'],state['sim_time'])
            assert [a.model_dump() for a in decoded]==[a.model_dump() for a in exported],('candidate parity',seed,tick)
        controller_time+=time.perf_counter()-t
        calls+=len(decoded)
        actions=[(a.agent_id,a) for a in decoded]
    result=dict(event='result',preset=preset,seed=seed,overrides=overrides,survival_seconds=round(state['sim_time'],1),
                score=state['score'],completed=bool(state['num_agents'] and tick+1==round(limit/sim.dt)),
                alive=state['num_agents'],peak_agents=peak,agents_born=sim.env._next_agent_id,
                energy_deaths=sum(e<=0 for a,e in deaths),predator_deaths=sum(e>0 for a,e in deaths),
                mean_death_age=statistics.mean(a for a,e in deaths) if deaths else None,
                fruits_eaten=len(harvest),mean_fruit_energy=statistics.mean(harvest) if harvest else 0.,
                fruits_rotted=len(rotten),controller_seconds=controller_time,controller_us=controller_time*1e6/max(calls,1),
                wall_seconds=time.perf_counter()-started,initial_state_sha256=digest,metrics=dict(policy.metrics),trace=trace,
                last_deaths=detailed_deaths[-12:],source_sha256=SOURCE_SHA256,config=getattr(policy,'config',None))
    result['standalone_parity_checked']=mirror is not None
    emit(result)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--presets',nargs='+',default=['economy'])
    p.add_argument('--seeds',nargs='+',type=int,default=[1,2,3])
    p.add_argument('--overrides',default='{}')
    p.add_argument('--limit',type=float,default=3000.)
    p.add_argument('--log')
    p.add_argument('--parity-candidate')
    a=p.parse_args()
    for preset in a.presets:
        for seed in a.seeds:run(seed,preset,json.loads(a.overrides),a.limit,a.log,a.parity_candidate)
