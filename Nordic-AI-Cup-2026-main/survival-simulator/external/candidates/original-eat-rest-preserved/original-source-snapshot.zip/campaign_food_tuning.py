"""Feed/rest decisions and known-new-fruit maturation; loose births fixed."""
import json
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from campaign_feeding_queue import complete, evaluate

if __name__ == '__main__':
    while not all(complete(label,seed) for label in ('loose_map_now','loose_map_memory','loose_map_late','loose_map_routes') for seed in (1,2,3)):
        time.sleep(10.)
    loose = dict(birth_energy=135.,birth_floor=112.,maximum_birth_gap=20.)
    groups = [
        ('efficient_breeding:EfficientBreedingPolicy', [
            ('loose_parent_capacity', {}),
            ('loose_parent_sprint', {'offspring_selection':'newborn_sprint'}),
            ('loose_parent_balanced', {'offspring_selection':'balanced'}),
        ]),
        ('orchard_policy:OrchardPolicy', [
            ('loose_orchard10', {}),
            ('loose_orchard20', {'orchard_wait':20.}),
            ('loose_orchard_newborn', {'orchard_newborn':True}),
        ]),
        ('appetite_policy:AppetitePolicy', [
            ('loose_appetite200', {'appetite_level':200.,'appetite_release':40.,'appetite_near':80.}),
            ('loose_appetite250', {'appetite_release':70.,'appetite_near':80.}),
            ('loose_appetite300', {'appetite_level':300.,'appetite_release':80.,'appetite_near':100.}),
        ]),
        ('harvest_policy:HarvestPolicy', [
            ('loose_fresh5', dict(loose,fresh_ripen=5.)),
            ('loose_fresh10', dict(loose,fresh_ripen=10.)),
            ('loose_fresh15', dict(loose,fresh_ripen=15.)),
        ]),
    ]
    for module,cases in groups:
        with ProcessPoolExecutor(max_workers=3) as pool:
            jobs = [pool.submit(evaluate,(module,label,config,seed))
                    for label,config in cases for seed in (1,2,3)]
            for future in as_completed(jobs):
                print(json.dumps(future.result()),flush=True)
