"""Sampled, minimum-intervention safety filter over observed enemy motion.

Inspired by velocity-obstacle safety filters; this approximate, partially
observed model does not provide a formal collision-avoidance guarantee.
"""
import math
from nursery_policy import NurseryPolicy,segment_clear,point_segment
from species_field_trial import wrap,rotate
from src.utils.DTOs import ActionRequest


def chase_step(p,heading,target,gaze,speed,respect_vision=False):
    dx,dy=target[0]-p[0],target[1]-p[1]
    bearing=math.atan2(dy,dx);distance=math.hypot(dx,dy)
    if respect_vision and distance>60. and (distance>250. or abs(wrap(bearing-heading))>math.pi/6):
        return (p[0]+speed*11./15.*math.cos(heading),p[1]+speed*11./15.*math.sin(heading)),heading
    looking=wrap(bearing+math.pi-gaze)
    if abs(looking)>math.pi/2 or distance<90.:
        error=wrap(bearing-heading)
        turn=max(-.3,min(.3,error*.5)) if abs(error)>.05 else 0.
        move=heading+turn if abs(error)>.05 else bearing
        heading=wrap(heading+turn)
        speed=min(speed,distance)
    else:
        move=bearing-math.copysign(math.pi/4,looking) if abs(looking)>1e-8 else bearing
        heading=math.atan2(target[1]-p[1]-speed*math.sin(move),target[0]-p[0]-speed*math.cos(move))
    return (p[0]+speed*math.cos(move),p[1]+speed*math.sin(move)),heading


def resolve_motion(start,desired,edges,radius):
    dx,dy=desired[0]-start[0],desired[1]-start[1]
    distance=math.hypot(dx,dy)
    if distance<1e-8:return start
    angle=math.atan2(dy,dx)
    for i in range(37):
        offset=0. if i==0 else math.pi/18.*((i+1)//2)*(-1)**i
        p=(start[0]+distance*math.cos(angle+offset),start[1]+distance*math.sin(angle+offset))
        if all(point_segment(p,*e)>=radius for e in edges) and segment_clear(start,p,edges,0.):return p
    return start


class SafetyPolicy(NurseryPolicy):
    def __init__(self,preset='safety',**overrides):
        config=dict(detours=False,protect_habitat=False,nursery_birth=False,population=6,population_floor=2,
                    filter_horizon=3,filter_margin=28.,filter_food=.8,enemy_speed='measured',rest_certainty=True,
                    respect_enemy_vision=False,concealment_bonus=0.,collision_model=False,optimistic_rest=0.)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state)
        view['escaping']=False
        return view

    def steer(self,view):
        s,mem,c=view['state'],view['mem'],self.config
        previous=rotate(mem.last_move,-mem.last_turn)
        base=super().steer(view)
        enemies=[p for p in view['predators'] if p['obs']['distance']<170.]
        if not enemies:return base
        terrain={'swamp':.5,'river':.3,'desert':.8}.get(s['biome'],1.)
        walk=min(s['speed'],s['sprint_speed'])
        h=c['filter_horizon']
        target=view['visible'].get(mem.target_id)
        goal=target['p'] if target else None
        nearest=enemies[0]
        gaze=nearest['obs']['angle']+.05
        # Observations are produced before the predator moves. Advance that
        # unobserved step before evaluating our next action.
        models=[]
        for enemy in enemies[:4]:
            rest=enemy.get('rest_start')
            sleeping=(3.1-(self.clock-rest))*10. if rest is not None and c['rest_certainty'] else 0.
            measured=math.hypot(*enemy['velocity'])
            if rest is None and enemy['measured'] and measured<.5:sleeping=c['optimistic_rest']
            speed=15. if c['enemy_speed']=='maximum' else max(15.*terrain,measured)
            if c['enemy_speed']=='inferred':
                speed=15.
                if enemy['measured'] and measured>.5:
                    factor=min((.3,.5,.8,1.),key=lambda f:min(abs(measured-11.*f),abs(measured-15.*f)))
                    speed=15.*factor
            p,heading=enemy['p'],enemy['heading']
            if sleeping<1.:
                old=p;p,heading=chase_step(p,heading,(0.,0.),0.,speed,c['respect_enemy_vision'])
                if c['collision_model']:p=resolve_motion(old,p,view['edges'],10.)
            models.append((p,heading,speed,sleeping))
        # Keep full-speed and stationary choices, plus partial movements so
        # a small safety correction need not pay a full sprint penalty.
        speeds={0.,.5*walk,walk,base.move_distance}
        if s['energy']>.2*s['max_energy']+3.:
            speeds.update(((walk+s['sprint_speed'])/2.,s['sprint_speed']))
        away=math.atan2(-nearest['p'][1],-nearest['p'][0])
        angles=[base.move_direction,math.atan2(previous[1],previous[0])]
        angles.extend(away+i*math.pi/8 for i in range(-8,8))
        if goal:angles.append(math.atan2(goal[1],goal[0]))
        options=[]
        base_v=(base.move_distance*terrain*math.cos(base.move_direction),base.move_distance*terrain*math.sin(base.move_direction))
        for speed in sorted(speeds):
            for angle in angles if speed else [0.]:
                direction,_=self.slide((math.cos(angle),math.sin(angle)),view,speed)
                v=(direction[0]*speed*terrain,direction[1]*speed*terrain)
                positions=[];a=(0.,0.)
                for tick in range(1,h+1):
                    desired=(a[0]+v[0],a[1]+v[1])
                    a=resolve_motion(a,desired,view['edges'],5.) if c['collision_model'] else desired
                    positions.append(a)
                clearance=math.inf;end=math.inf;concealed=True
                for p,heading,pspeed,sleeping in models:
                    for tick in range(1,h+1):
                        a=positions[tick-1]
                        if tick+1>=sleeping:
                            old=p;p,heading=chase_step(p,heading,a,gaze,pspeed,c['respect_enemy_vision'])
                            if c['collision_model']:p=resolve_motion(old,p,view['edges'],10.)
                        clearance=min(clearance,math.hypot(a[0]-p[0],a[1]-p[1]))
                    end=min(end,math.hypot(a[0]-p[0],a[1]-p[1]))
                    concealed=concealed and math.hypot(a[0]-p[0],a[1]-p[1])>65. and abs(wrap(math.atan2(a[1]-p[1],a[0]-p[0])-heading))>math.pi/5
                movement_cost=(.05*min(speed,s['speed'])+.5*max(0.,speed-s['speed']))*h
                deviation=math.hypot(v[0]-base_v[0],v[1]-base_v[1])
                progress=0.;eat=0.
                if goal:
                    remaining=min(math.hypot(goal[0]-p[0],goal[1]-p[1]) for p in positions)
                    progress=math.hypot(*goal)-remaining
                    if remaining<10.:eat=25.*min(2.,100./max(s['energy'],50.))
                danger=1000.*max(0.,c['filter_margin']-clearance)+.015*max(0.,60.-clearance)**2
                wall=50. if not segment_clear((0.,0.),(v[0]*h,v[1]*h),view['edges'],4.) else 0.
                score=c['filter_food']*progress+eat-1.3*movement_cost-.15*deviation-danger-wall+.02*min(160.,end)+c['concealment_bonus']*concealed
                options.append((score,speed,direction,clearance))
        _,speed,direction,clearance=max(options,key=lambda x:x[0])
        angle=math.atan2(direction[1],direction[0])
        mem.last_move=(direction[0]*speed*terrain,direction[1]*speed*terrain)
        mem.last_turn=gaze
        if speed:mem.search_heading=wrap(mem.heading+angle)
        mem.last_mode='FILTER'
        self.metrics['filter_ticks']+=1
        self.metrics['filter_sprint_ticks']+=int(speed>walk+.01)
        return ActionRequest(agent_id=s['agent_id'],move_distance=speed,move_direction=angle,
                             turn_angle=gaze,spawn_agent=base.spawn_agent and clearance>70.)
