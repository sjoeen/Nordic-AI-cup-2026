"""Full-length original seed block; feeding/reproduction changes only."""
import argparse
import contextlib
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

CASES = [
    ('sustain_food', {'feeding':'opportunity'}),
    ('sustain_birth', {'breeding':'funded'}),
    ('sustain_combined', {'feeding':'opportunity','breeding':'funded'}),
]

def evaluate(job):
    from campaign_runner import run
    label, config, seed = job
    path = Path('campaign')/f'{label}_s{seed}.jsonl'
    if path.exists():
        for line in path.read_text().splitlines():
            r = json.loads(line)
            if r.get('event') == 'result':
                return label, seed, r['survival_seconds']
    with open(f'campaign_{label}_s{seed}.out','a',buffering=1) as f, contextlib.redirect_stdout(f):
        r = run(seed,'sustenance_policy:SustenancePolicy',config,label)
    return label, seed, r['survival_seconds']

if __name__ == '__main__':
    with ProcessPoolExecutor(max_workers=3) as pool:
        jobs = [pool.submit(evaluate,(label,config,seed)) for label,config in CASES for seed in (1,2,3)]
        for future in as_completed(jobs):
            print(json.dumps(future.result()),flush=True)
