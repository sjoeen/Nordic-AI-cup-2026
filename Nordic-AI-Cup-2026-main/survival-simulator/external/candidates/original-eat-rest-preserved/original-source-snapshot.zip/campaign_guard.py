import sys
from campaign_runner import run
CASES=[
 ('guard3',{}),
 ('guard2',{'guard_horizon':2}),
 ('guard4',{'guard_horizon':4}),
 ('guard3_tight',{'guard_margin':20.}),
 ('guard3_measured',{'guard_speed':'measured'}),
 ('guard3_collision',{'guard_collisions':True}),
 ('guard3_no_phase',{'guard_phase':False}),
]
if __name__=='__main__':
    for label,config in CASES:run(int(sys.argv[1]),'guard_colony:GuardColony',config,label)
