"""Second development block: unchanged batch size, fresh seeds 4,5,6.

These results can guide discovery. Final validation remains seeds 20,21,22.
"""
import sys
from campaign_runner import run
CASES=[
 ('DEV2_baseline','dispersal_policy:DispersalPolicy',{'dispersal_distance':100.}),
 ('DEV2_gap20','generation_policy:GenerationPolicy',{'maximum_birth_gap':20.}),
 ('DEV2_birth160','dispersal_policy:DispersalPolicy',{'dispersal_distance':100.,'birth_energy':160.}),
 ('DEV2_decoy','decoy_policy:DecoyPolicy',{'dispersal_distance':100.}),
 ('DEV2_refuge','refuge_policy:RefugePolicy',{}),
 ('DEV2_renewal','dispersal_policy:DispersalPolicy',{'dispersal_distance':100.,'young_age':45.,'retirement':75.,'renewal_age':60.}),
]
if __name__=='__main__':
    for label,name,config in CASES:run(int(sys.argv[1]),name,config,label)
