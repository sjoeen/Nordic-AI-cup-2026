import sys
from research_runner import run
seed=int(sys.argv[1])
for config in [{'label':'elder_decoys'},{'label':'escape_separation','decoys':False}]:
 run(seed,'decoy',config,log=f'research_decoys_{seed}.jsonl')
