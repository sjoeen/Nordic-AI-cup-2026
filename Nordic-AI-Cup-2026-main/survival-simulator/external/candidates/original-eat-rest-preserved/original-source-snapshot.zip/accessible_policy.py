"""Avoid spending food reserves chasing fruit through observed walls."""
from dispersal_policy import DispersalPolicy
from nursery_policy import segment_clear


class AccessiblePolicy(DispersalPolicy):
    def __init__(self,preset='accessible',**overrides):
        config=dict(dispersal_distance=100.,accessible_mode='prefer',individual_targets=False)
        config.update(overrides)
        super().__init__(preset,**config)
        if self.config['individual_targets']:self.allocated=False

    def filter_food(self,view):
        if self.config['accessible_mode']=='none':return
        edges=[e for e,t in getattr(view['mem'],'shelter_edges',[])]
        clear=[f for f in view['fruits'] if segment_clear((0.,0.),f['p'],edges,0.)]
        if clear or self.config['accessible_mode']=='strict':
            self.metrics['blocked_fruit_rejections']+=len(view['fruits'])-len(clear)
            view['fruits']=clear

    def observe(self,state):
        view=super().observe(state)
        if not self.allocated:self.filter_food(view)
        return view

    def shared_frames(self,views):
        super().shared_frames(views)
        for view in views.values():self.filter_food(view)
