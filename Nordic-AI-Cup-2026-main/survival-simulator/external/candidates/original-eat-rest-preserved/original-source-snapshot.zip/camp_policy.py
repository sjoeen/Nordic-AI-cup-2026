"""Patch residence near observed fruit-producing trees, with giving-up time."""
import math
from alarm_policy import AlarmPolicy
from species_field_trial import rotate,wrap,point,unit


class CampPolicy(AlarmPolicy):
    def __init__(self,preset='camp',**overrides):
        config=dict(population=8,population_floor=3,camp_timeout=15.,camp_range=250.,camp_min_energy=50.,
                    fresh_ripen=15.,ripen_age_limit=65.,hard_idle_energy=260.,birth_energy=180.,
                    emergency_birth=True,search_speed=.8,food_triage=True,alarm_sharing=True)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state)
        mem=view['mem'];translated=[]
        for p,seen in getattr(mem,'tree_sites',[]):
            if self.clock-seen>20.:continue
            q=rotate(p,-mem.last_turn)
            translated.append(((q[0]-view['translation'][0],q[1]-view['translation'][1]),seen))
        for obs in state['observations']:
            if obs['type']!='Tree':continue
            p=point(obs)
            translated=[(q,t) for q,t in translated if math.hypot(p[0]-q[0],p[1]-q[1])>5.]
            translated.append((p,self.clock))
        mem.tree_sites=translated
        if state['energy']>getattr(mem,'energy_before',state['energy'])+4.:
            mem.last_harvest=self.clock
            mem.camp_giveup=self.clock+self.config['camp_timeout']
        mem.energy_before=state['energy']
        return view

    def steer(self,view):
        s,mem,c=view['state'],view['mem'],self.config
        action=super().steer(view)
        if view['escaping'] or view.get('resting') or mem.target_id is not None:return action
        if s['energy']<c['camp_min_energy'] or s['age']>85.:return action
        if self.clock<getattr(mem,'camp_cooldown',-1.):return action
        sites=[p for p,t in mem.tree_sites if math.hypot(*p)<c['camp_range']]
        if not sites:return action
        candidates=[]
        for p in sites:
            count=sum(math.exp(-math.hypot(q[0]-p[0],q[1]-p[1])/80.) for q in sites)
            danger=sum(max(0.,1.-math.hypot(e['p'][0]-p[0],e['p'][1]-p[1])/180.) for e in view['predators'])
            crowd=sum(math.exp(-math.hypot(point(a)[0]-p[0],point(a)[1]-p[1])/60.) for a in view['agents'])
            score=count*35.-math.hypot(*p)*.12-danger*100.-crowd*12.
            candidates.append((score,p))
        score,goal=max(candidates,key=lambda x:x[0])
        if score<0.:return action
        if not hasattr(mem,'camp_giveup'):mem.camp_giveup=self.clock+c['camp_timeout']
        if self.clock>=mem.camp_giveup:
            mem.camp_cooldown=self.clock+8.;mem.camp_giveup=mem.camp_cooldown+c['camp_timeout']
            return action
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        speed=min(s['speed'],s['sprint_speed'],max(0.,math.hypot(*goal)-8.)/terrain)
        direction,_=self.slide(unit(goal),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=c['scan'] if math.hypot(*goal)<s['hearing_radius'] else max(-.6,min(.6,action.move_direction))
        mem.last_move=(speed*terrain*direction[0],speed*terrain*direction[1]);mem.last_turn=action.turn_angle
        mem.last_mode='CAMP';self.metrics['camp_ticks']+=1
        if speed:mem.search_heading=wrap(mem.heading+action.move_direction)
        return action
