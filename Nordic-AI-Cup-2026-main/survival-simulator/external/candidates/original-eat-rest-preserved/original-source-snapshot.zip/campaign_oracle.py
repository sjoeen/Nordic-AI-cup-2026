"""RESEARCH ONLY: extra food observations from ground truth, NEVER export.

This tests the value of food information for the existing controller. It is
not an optimal-performance bound and is ineligible for candidate rankings.
"""
import argparse
import math
import campaign_runner as runner
from dispersal_policy import DispersalPolicy


def main():
    p=argparse.ArgumentParser();p.add_argument('seed',type=int);args=p.parse_args()
    current={}
    original=runner.SimulationCore
    class DiagnosticCore(original):
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw);current['sim']=self
    class OracleFood(DispersalPolicy):
        def observe(self,state):
            a=current['sim'].env.agents_dict[state['agent_id']]
            observations=[o for o in state['observations'] if o['type']!='Fruit']
            for f in current['sim'].env.fruits:
                distance=math.hypot(f.x-a.x,f.y-a.y)
                if distance<self.config['oracle_food_radius']:
                    observations.append(dict(type='Fruit',distance=distance,
                        angle=(math.atan2(f.y-a.y,f.x-a.x)-a.direction+math.pi)%(2*math.pi)-math.pi))
            return super().observe({**state,'observations':observations})
    runner.SimulationCore=DiagnosticCore
    runner.policy_factory=lambda name,config:OracleFood(**config)
    for radius in (400.,800.):
        runner.run(args.seed,'RESEARCH_ONLY:OracleFood',dict(dispersal_distance=100.,oracle_food_radius=radius),
                   'ORACLE_food_'+str(int(radius)))


if __name__=='__main__':main()
