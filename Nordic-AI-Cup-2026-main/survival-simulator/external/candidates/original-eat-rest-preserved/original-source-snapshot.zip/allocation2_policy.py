"""Release fruit reservations only when another agent has a clear advantage."""
from dispersal_policy import DispersalPolicy


class AllocationPolicy(DispersalPolicy):
    def __init__(self,preset='allocation2',**overrides):
        config=dict(dispersal_distance=100.,reservation_ratio=.5,reservation_margin=15.,nearest_each_tick=False)
        config.update(overrides);super().__init__(preset,**config)
        if self.config['nearest_each_tick']:self.persistent=False

    def allocate(self,views):
        super().allocate(views)
        c=self.config
        if not c['reservation_ratio']:return
        owners={v['mem'].target_id:aid for aid,v in views.items() if v['mem'].target_id is not None}
        offers=[]
        for aid,v in views.items():
            if v['escaping'] or not v.get('eligible',True):continue
            current=v['visible'].get(v['mem'].target_id)
            current_distance=current['obs']['distance'] if current else float('inf')
            for key,f in v['visible'].items():
                owner=owners.get(key)
                if owner is None or owner==aid:continue
                distance=f['obs']['distance'];other=views[owner]['visible'].get(key)
                if other is None:continue
                old_distance=other['obs']['distance']
                if distance+c['reservation_margin']<min(old_distance,current_distance)*c['reservation_ratio']:
                    offers.append((distance-old_distance,aid,owner,key))
        used=set()
        for gain,aid,owner,key in sorted(offers):
            if aid in used or owner in used or views[owner]['mem'].target_id!=key:continue
            views[owner]['mem'].target_id=None;views[aid]['mem'].target_id=key
            used.update((aid,owner));self.metrics['reservation_transfers']+=1
