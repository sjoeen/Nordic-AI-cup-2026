import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 {'label':'colony_storage','dispersal_distance':100.,'hard_idle_energy':450.,'idle_energy':.95},
 {'label':'colony_endurance','dispersal_distance':100.,'quality_mode':'endurance'},
 {'label':'colony_endurance_storage','dispersal_distance':100.,'quality_mode':'endurance','hard_idle_energy':450.,'idle_energy':.95},
]
for config in cases:run(seed,'dispersal',config,log=f'research_reserves_{seed}.jsonl')
