"""Local A* routes to food around observed obstacle segments."""
import heapq
import math
from memory_policy import MemoryPolicy
from nursery_policy import segment_clear,point_segment
from species_field_trial import rotate,wrap,unit


class PathPolicy(MemoryPolicy):
    def __init__(self,preset='path',**overrides):
        config=dict(route_grid=12.,route_nodes=700,fruit_memory_seconds=15.,stall_timeout=8.)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        transformed=[]
        for p in getattr(mem,'route',[]):
            q=rotate(p,-mem.last_turn)
            transformed.append((q[0]-view['translation'][0],q[1]-view['translation'][1]))
        mem.route=transformed
        old=[]
        for e,seen in getattr(mem,'navigation_edges',[]):
            if self.clock-seen>10.:continue
            transformed=[]
            for p in e:
                q=rotate(p,-mem.last_turn)
                transformed.append((q[0]-view['translation'][0],q[1]-view['translation'][1]))
            old.append((tuple(transformed),seen))
        for e in view['edges']:
            old=[(o,t) for o,t in old if not (math.hypot(o[0][0]-e[0][0],o[0][1]-e[0][1])<2. and math.hypot(o[1][0]-e[1][0],o[1][1]-e[1][1])<2.)]
            old.append((e,self.clock))
        mem.navigation_edges=[(e,t) for e,t in old if point_segment((0.,0.),*e)<450.][-70:]
        return view

    def route_to(self,goal,edges):
        scale=self.config['route_grid'];limit=self.config['route_nodes']
        radius=min(500.,max(180.,math.hypot(*goal)+100.))
        start=(0,0);queue=[(math.hypot(*goal),0.,start)];cost={start:0.};previous={};free={start:True}
        def position(cell):return cell[0]*scale,cell[1]*scale
        def valid(cell):
            if cell not in free:
                p=position(cell)
                free[cell]=math.hypot(*p)<radius and all(point_segment(p,*e)>6. for e in edges)
            return free[cell]
        end=None
        for _ in range(limit):
            if not queue:break
            _,distance,node=heapq.heappop(queue)
            if distance>cost[node]+1e-6:continue
            p=position(node)
            if math.hypot(p[0]-goal[0],p[1]-goal[1])<scale*1.5 and segment_clear(p,goal,edges,4.):
                end=node;break
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
                nxt=(node[0]+dx,node[1]+dy)
                if not valid(nxt):continue
                q=position(nxt)
                if not segment_clear(p,q,edges,4.):continue
                new=distance+scale*(1.41421356 if dx and dy else 1.)
                if new>=cost.get(nxt,math.inf):continue
                cost[nxt]=new;previous[nxt]=node
                heapq.heappush(queue,(new+math.hypot(q[0]-goal[0],q[1]-goal[1]),new,nxt))
        if end is None:return []
        path=[goal]
        while end!=start:
            path.append(position(end));end=previous[end]
        path.reverse()
        return path

    def steer(self,view):
        action=super().steer(view)
        s,mem=view['state'],view['mem']
        target=view['visible'].get(mem.target_id)
        if target is None or view['escaping'] or view.get('resting'):return action
        goal=target['p'];edges=[e for e,t in mem.navigation_edges]
        if segment_clear((0.,0.),goal,edges,5.):
            mem.route=[];return action
        if getattr(mem,'route_target',None)!=mem.target_id:mem.route=[]
        if not mem.route and self.clock>=getattr(mem,'next_route',0.):
            mem.route=self.route_to(goal,edges);mem.route_target=mem.target_id
            mem.next_route=self.clock+.5
            self.metrics['route_plans']+=1
            self.metrics['route_failures']+=int(not mem.route)
        if not mem.route:return action
        visible=[i for i,p in enumerate(mem.route) if segment_clear((0.,0.),p,edges,4.)]
        if not visible:
            mem.route=[];return action
        index=max(visible);waypoint=mem.route[index];mem.route=mem.route[index:]
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        speed=min(s['speed'],s['sprint_speed'],math.hypot(*waypoint)/terrain)
        direction=unit(waypoint)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=max(-.6,min(.6,action.move_direction))
        mem.last_move=tuple(v*speed*terrain for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.last_mode='ROUTE'
        self.metrics['route_ticks']+=1
        return action
