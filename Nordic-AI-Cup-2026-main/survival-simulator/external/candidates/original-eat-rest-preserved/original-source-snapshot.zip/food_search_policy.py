"""Small continuous food-policy search; reproduction remains permissive."""
import math
from appetite_policy import AppetitePolicy
from efficient_breeding import EfficientBreedingPolicy


class FoodSearchPolicy(EfficientBreedingPolicy, AppetitePolicy):
    DEFAULT = [250.,0.,80.,.7,7.,0.,0.,0.,0.,0.]

    def __init__(self, preset='food_search', parameters=None, **overrides):
        self.parameters = list(self.DEFAULT if parameters is None else parameters)
        p = self.parameters
        config = dict(birth_energy=135.,birth_floor=112.,maximum_birth_gap=20.,
                      appetite_level=p[0],appetite_release=p[1],appetite_near=p[2],
                      harvest_discount=p[3],harvest_switch=p[4],fresh_ripen=p[9])
        config.update(overrides)
        super().__init__(preset,**config)

    def parent_value(self, s):
        p = self.parameters
        walk = max(.1,min(s['speed'],s['sprint_speed']))
        capacity = max(100.,s['max_energy'])
        base = walk+.015*s['hearing_radius']+.003*s['vision_range']
        value = base*(375./max(160.,capacity))**p[5]
        value *= max(.1,s['vision_range']/200.)**p[6]
        value *= max(.1,s['hearing_radius']/50.)**p[7]
        value *= 1.+p[8]/(1.+math.exp(max(-20.,min(20.,(capacity-350.)/40.))))
        fertility = min(1.,max(.01,(capacity-110.)/80.))
        value *= fertility**min(1.,abs(p[5])+p[8])
        return value
