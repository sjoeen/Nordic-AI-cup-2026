"""Send offspring to separate feeding areas while preserving parental traits."""
import math
from refuge_policy import RefugePolicy
from species_field_trial import rotate,wrap


class DispersalPolicy(RefugePolicy):
    def __init__(self,preset='dispersal',**overrides):
        config=dict(dispersal_distance=200.,dispersal_time=6.,stale_correction=True)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        if not hasattr(mem,'birth_origin'):
            mem.birth_origin=(0.,0.)
            mem.colonist=state['age']<.5 and state['energy']<100.
            mem.migration_heading=mem.rng.uniform(-math.pi,math.pi)
        q=rotate(mem.birth_origin,-mem.last_turn)
        mem.birth_origin=(q[0]-view['translation'][0],q[1]-view['translation'][1])
        if state['age']>self.config['dispersal_time'] or state['energy']<40. or math.hypot(*mem.birth_origin)>self.config['dispersal_distance']:
            mem.colonist=False
        return view

    def allocate(self,views):
        for view in views.values():
            if view['mem'].colonist:
                view['eligible']=False;view['resting']=False
        super().allocate(views)

    def steer(self,view):
        action=super().steer(view)
        s,mem=view['state'],view['mem']
        if not mem.colonist or view['escaping']:return action
        angle=wrap(mem.migration_heading-mem.heading)
        if view['predators']:
            enemy=view['predators'][0]
            if enemy['obs']['distance']<160. and math.cos(angle-enemy['obs']['angle'])>.2:
                mem.migration_heading=wrap(mem.heading+enemy['obs']['angle']+math.pi)
                angle=wrap(mem.migration_heading-mem.heading)
        speed=min(s['speed'],s['sprint_speed'])
        direction,_=self.slide((math.cos(angle),math.sin(angle)),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=max(-.6,min(.6,action.move_direction))
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        mem.last_move=tuple(v*speed*terrain for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.last_mode='COLONIZE'
        self.metrics['colonization_ticks']+=1
        return action
