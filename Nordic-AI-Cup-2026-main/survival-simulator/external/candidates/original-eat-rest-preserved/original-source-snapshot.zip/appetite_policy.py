"""Change when to eat and rest; retain permissive births and existing steering."""
from harvest_policy import HarvestPolicy


class AppetitePolicy(HarvestPolicy):
    def __init__(self, preset='appetite', **overrides):
        config = dict(birth_energy=135., birth_floor=112., maximum_birth_gap=20.,
                      appetite_level=250., appetite_release=0., appetite_near=0.,
                      appetite_age_slope=0., appetite_start=0.)
        config.update(overrides)
        super().__init__(preset, **config)

    def shared_frames(self, views):
        super().shared_frames(views)
        c = self.config
        if self.clock < c['appetite_start']:
            return
        for aid,v in views.items():
            s,m = v['state'],v['mem']
            if aid in self.retired_ids or m.colonist:
                continue
            level = c['appetite_level']+c['appetite_age_slope']*max(0.,s['age']-50.)
            level = min(max(130.,level),c['idle_energy']*s['max_energy'])
            near = c['appetite_near'] and any(10.<f['obs']['distance']<c['appetite_near'] for f in v['fruits'])
            if getattr(m,'appetite_resting',False) and not near:
                threshold = level-c['appetite_release']
            else:
                threshold = level
            resting = s['energy']>threshold and aid not in self.spawn_ids
            m.appetite_resting = resting
            v['resting'] = resting
            v['eligible'] = not resting
