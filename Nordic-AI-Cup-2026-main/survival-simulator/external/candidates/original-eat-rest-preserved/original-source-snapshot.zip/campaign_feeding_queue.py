"""Serial batch queue capped at three simulation workers."""
import contextlib
import json
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

def complete(label, seed):
    p = Path('campaign')/f'{label}_s{seed}.jsonl'
    if p.exists():
        for line in p.read_text().splitlines():
            r = json.loads(line)
            if r.get('event') == 'result':
                return r
    return None

def evaluate(job):
    from campaign_runner import run
    module, label, config, seed = job
    done = complete(label, seed)
    if done is not None:
        return label, seed, done['survival_seconds']
    with open(f'campaign_{label}_s{seed}.out', 'a', buffering=1) as f, contextlib.redirect_stdout(f):
        r = run(seed, module, config, label)
    return label, seed, r['survival_seconds']

if __name__ == '__main__':
    while not all(complete(label, seed) for label in ('nurture_children','nurture_late_food','nurture_combined') for seed in (1,2,3)):
        time.sleep(10.)
    loose = dict(birth_energy=135., birth_floor=112., maximum_birth_gap=20.)
    groups = [
        ('generation_policy:GenerationPolicy', [('loose_control', loose)]),
        ('harvest_policy:HarvestPolicy', [
            ('loose_route2', dict(loose)),
            ('loose_route3', dict(loose,harvest_depth=3)),
            ('loose_late_route2', dict(loose,harvest_start=900.)),
        ]),
        ('nurture_policy:NurturePolicy', [
            ('loose_children', dict(loose,newborn_priority=True)),
            ('loose_late_food', dict(loose,late_feeding=True)),
        ]),
    ]
    for module,cases in groups:
        with ProcessPoolExecutor(max_workers=3) as pool:
            jobs = [pool.submit(evaluate,(module,label,config,seed))
                    for label,config in cases for seed in (1,2,3)]
            for future in as_completed(jobs):
                print(json.dumps(future.result()),flush=True)
