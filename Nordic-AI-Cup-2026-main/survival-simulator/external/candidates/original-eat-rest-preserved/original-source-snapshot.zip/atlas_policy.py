"""Observation-derived species atlas; never reads simulation world objects."""
import math
from collections import defaultdict
from strategy_lab import SurvivalPolicy
from species_field_trial import point, rotate, wrap


class AtlasPolicy(SurvivalPolicy):
    def __init__(self,preset='atlas',**overrides):
        config=dict(search_speed=.8,escape='predict',gaze_turn=math.pi)
        config.update(overrides)
        super().__init__(preset,**config)
        self.poses={}
        self.tree_atlas=defaultdict(dict)
        self.terrain_atlas=defaultdict(dict)
        self.visited=defaultdict(dict)
        self.atlas_time=-1.

    def allocate(self,views):
        if self.clock<self.atlas_time:
            self.poses.clear();self.tree_atlas.clear();self.terrain_atlas.clear();self.visited.clear()
        self.atlas_time=self.clock
        self.poses={k:v for k,v in self.poses.items() if k in views}
        for aid,view in views.items():
            if aid not in self.poses:
                self.poses[aid]=(aid,(0.,0.),0.)
            else:
                component,origin,heading=self.poses[aid]
                heading=wrap(heading+view['mem'].last_turn)
                delta=rotate(view['translation'],heading)
                self.poses[aid]=(component,(origin[0]+delta[0],origin[1]+delta[1]),heading)
        for aid,view in sorted(views.items()):
            for other in view['agents']:
                bid=other.get('id')
                if bid not in self.poses:continue
                ac,ap,ah=self.poses[aid];bc,bp,bh=self.poses[bid]
                if ac==bc:continue
                relative=point(other)
                offset=rotate(relative,ah)
                new_bp=(ap[0]+offset[0],ap[1]+offset[1])
                new_bh=wrap(ah+other['angle']+math.pi-other['rel_dir'])
                rotation=wrap(new_bh-bh)
                old=rotate(bp,rotation)
                translation=(new_bp[0]-old[0],new_bp[1]-old[1])
                def transform(p):
                    q=rotate(p,rotation)
                    return q[0]+translation[0],q[1]+translation[1]
                for cid,(cc,cp,ch) in list(self.poses.items()):
                    if cc==bc:self.poses[cid]=(ac,transform(cp),wrap(ch+rotation))
                for p,seen in self.tree_atlas.pop(bc,{}).values():
                    p=transform(p)
                    self.tree_atlas[ac][(round(p[0]/10),round(p[1]/10))]=(p,seen)
                for cell,biome in self.terrain_atlas.pop(bc,{}).items():
                    p=transform((cell[0]*75.,cell[1]*75.))
                    self.terrain_atlas[ac][(round(p[0]/75),round(p[1]/75))]=biome
                for cell,seen in self.visited.pop(bc,{}).items():
                    p=transform((cell[0]*75.,cell[1]*75.))
                    key=(round(p[0]/75),round(p[1]/75))
                    self.visited[ac][key]=max(seen,self.visited[ac].get(key,-1.))
                self.metrics['atlas_frame_merges']+=1
        for aid,view in views.items():
            component,origin,heading=self.poses[aid]
            cell=(round(origin[0]/75),round(origin[1]/75))
            self.visited[component][cell]=self.clock
            self.terrain_atlas[component][cell]=view['state']['biome']
            for obs in view['state']['observations']:
                if obs['type']!='Tree':continue
                p=rotate(point(obs),heading)
                p=(origin[0]+p[0],origin[1]+p[1])
                self.tree_atlas[component][(round(p[0]/10),round(p[1]/10))]=(p,self.clock)
            self.tree_atlas[component]={k:v for k,v in self.tree_atlas[component].items() if self.clock-v[1]<25.}
        super().allocate(views)

    def shared_frames(self,views):
        """Keep previously established frame alignments after teammates separate."""
        located=[]
        cells=defaultdict(list)
        for aid,view in sorted(views.items()):
            component,origin,heading=self.poses[aid]
            for fruit in view['fruits']:
                p=rotate(fruit['p'],heading)
                p=(p[0]+origin[0],p[1]+origin[1])
                cx,cy=math.floor(p[0]/4),math.floor(p[1]/4)
                candidates=[item for dx in (-1,0,1) for dy in (-1,0,1)
                            for item in cells[(component,cx+dx,cy+dy)]
                            if item[0]!=aid and math.hypot(item[2][0]-p[0],item[2][1]-p[1])<3.]
                if candidates:
                    match=min(candidates,key=lambda item:math.hypot(item[2][0]-p[0],item[2][1]-p[1]))
                    self.merge(fruit['key'],match[1])
                cells[(component,cx,cy)].append((aid,fruit['key'],p))
                located.append((component,fruit['key'],p))
        pooled={}
        for component,key,p in located:pooled.setdefault((component,self.canonical(key)),p)
        for aid,view in views.items():
            if view.get('resting'):continue
            component,origin,heading=self.poses[aid]
            own={self.canonical(f['key']) for f in view['fruits']}
            for (comp,key),p in pooled.items():
                if comp!=component or key in own:continue
                local=rotate((p[0]-origin[0],p[1]-origin[1]),-heading)
                d=math.hypot(*local)
                if d<=6 or d>600:continue
                view['fruits'].append(dict(key=key,p=local,shared=True,
                                          obs=dict(type='Fruit',distance=d,angle=math.atan2(local[1],local[0]))))
                self.metrics['shared_fruit_observations']+=1
        self.metrics['component_ticks']+=len({p[0] for p in self.poses.values()})
        self.metrics['hivemind_ticks']+=1

    def steer(self,view):
        s,mem=view['state'],view['mem']
        component,origin,heading=self.poses[s['agent_id']]
        if not hasattr(mem,'atlas_next'):
            mem.atlas_next=0.
            mem.atlas_goal=None
        if not view['escaping'] and not view.get('resting') and mem.target_id is None:
            if self.clock>=mem.atlas_next or mem.atlas_goal is None or math.hypot(mem.atlas_goal[0]-origin[0],mem.atlas_goal[1]-origin[1])<25.:
                prior=wrap(mem.search_heading-mem.heading+heading)
                candidates=[]
                trees=list(self.tree_atlas[component].values())
                teammates=[p for aid,(comp,p,h) in self.poses.items() if comp==component and aid!=s['agent_id']]
                for i in range(16):
                    angle=prior+i*math.pi/8
                    dx,dy=math.cos(angle),math.sin(angle)
                    px,py=origin[0]+150.*dx,origin[1]+150.*dy
                    score=5.*math.cos(angle-prior)
                    for radius in (60.,120.,180.):
                        cell=(round((origin[0]+radius*dx)/75),round((origin[1]+radius*dy)/75))
                        elapsed=self.clock-self.visited[component].get(cell,-10000.)
                        score+=min(30.,elapsed*.4)
                        biome=self.terrain_atlas[component].get(cell)
                        score+={'forest':12.,'grassland':4.,'swamp':-4.,'desert':-20.,'river':-35.}.get(biome,0.)
                    for p,seen in trees:
                        distance=math.hypot(p[0]-px,p[1]-py)
                        score+=12.*math.exp(-distance/150.)*max(0.,1.-(self.clock-seen)/25.)
                    for p in teammates:
                        score-=15.*math.exp(-math.hypot(p[0]-px,p[1]-py)/100.)
                    local=rotate((dx,dy),-heading)
                    _,used=self.slide(local,view,30.)
                    if used:score-=30.
                    candidates.append((score,(px,py)))
                _,mem.atlas_goal=max(candidates,key=lambda x:x[0])
                mem.atlas_next=self.clock+2.
            direction=math.atan2(mem.atlas_goal[1]-origin[1],mem.atlas_goal[0]-origin[0])
            mem.search_heading=wrap(mem.heading+direction-heading)
        return super().steer(view)
