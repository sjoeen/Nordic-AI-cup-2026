"""Maintain behavioral diversity while retaining one shared food allocator."""
from dispersal_policy import DispersalPolicy


class PortfolioPolicy(DispersalPolicy):
    def __init__(self,preset='portfolio',**overrides):
        config=dict(dispersal_distance=100.,migration_fraction=.5,mixed_search=False)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        if not hasattr(mem,'migration_allowed'):
            mem.migration_allowed=mem.rng.random()<self.config['migration_fraction']
            mem.search_role=mem.rng.random()<.5
        if not mem.migration_allowed:mem.colonist=False
        return view

    def steer(self,view):
        original=self.config['search_speed']
        if self.config['mixed_search']:
            self.config['search_speed']=.2 if view['mem'].search_role else .8
        try:return super().steer(view)
        finally:self.config['search_speed']=original
