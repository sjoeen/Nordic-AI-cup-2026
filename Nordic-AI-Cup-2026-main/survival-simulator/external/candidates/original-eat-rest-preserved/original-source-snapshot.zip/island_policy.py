"""Maintain several local lineages instead of one global breeding cluster."""
import math
from alarm_policy import AlarmPolicy
from species_field_trial import wrap,unit,point


class IslandPolicy(AlarmPolicy):
    def __init__(self,preset='islands',**overrides):
        config=dict(population=12,population_floor=4,population_decay=1000.,young_age=55.,
                    local_population=2,territory_radius=220.,dispersal_seconds=2.,
                    birth_energy=180.,hard_idle_energy=250.,retirement=1e9,
                    emergency_birth=False,food_triage=True,alarm_sharing=True,scan=.3)
        config.update(overrides)
        super().__init__(preset,**config)

    def allocate(self,views):
        super().allocate(views)
        self.latest_views=views

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time)
        views=self.latest_views;c=self.config
        cap=max(c['population_floor'],round(c['population']*.5**(self.clock/c['population_decay'])))
        young={s['agent_id'] for s in states if s['age']<c['young_age'] and s['max_energy']>120.}
        nearby={}
        for aid,view in views.items():
            comp,p,h=view['shared_pose']
            nearby[aid]={bid for bid,v in views.items() if v['shared_pose'][0]==comp and math.hypot(v['shared_pose'][1][0]-p[0],v['shared_pose'][1][1]-p[1])<c['territory_radius']}
        byid={a.agent_id:a for a in actions}
        for a in actions:a.spawn_agent=False
        candidates=[]
        for aid,view in views.items():
            s=view['state'];n=len(nearby[aid]&young)
            local_emergency=(n==0 and s['age']>65.) or len(states)<3
            threshold=115. if local_emergency else max(135.,min(c['birth_energy'],.7*s['max_energy']))
            safe=not view['predators'] or min(p['obs']['distance'] for p in view['predators'])>(60. if local_emergency else 120.)
            if safe and s['energy']>threshold and n<c['local_population']:
                quality=min(s['speed'],s['sprint_speed'])+.03*s['hearing_radius']+.002*s['vision_range']
                candidates.append((n,-quality,-s['energy'],aid))
        births=[]
        for n,q,e,aid in sorted(candidates):
            if len(young)+len(births)>=cap:break
            local_count=len(nearby[aid]&young)+sum(b in nearby[aid] for b in births)
            if local_count>=c['local_population']:continue
            byid[aid].spawn_agent=True;births.append(aid)
        return actions

    def steer(self,view):
        action=super().steer(view)
        s,mem=view['state'],view['mem']
        if s['age']>=self.config['dispersal_seconds'] or view['escaping'] or not view['agents']:return action
        target=view['visible'].get(mem.target_id)
        if target and target['obs']['distance']<25.:return action
        close=[o for o in view['agents'] if o['distance']<70.]
        if not close:return action
        dx=dy=0.
        for other in close:
            p=point(other);d=max(10.,other['distance']);dx-=p[0]/d**2;dy-=p[1]/d**2
        speed=min(s['speed'],s['sprint_speed'])*.7
        direction,_=self.slide(unit((dx,dy)),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=max(-.6,min(.6,action.move_direction))
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        mem.last_move=tuple(v*speed*terrain for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.last_mode='DISPERSE'
        self.metrics['dispersal_ticks']+=1
        return action
