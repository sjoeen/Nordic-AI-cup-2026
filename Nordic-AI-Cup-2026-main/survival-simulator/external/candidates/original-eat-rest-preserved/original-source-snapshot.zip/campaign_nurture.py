"""Full-size original block; no fresh-seed selection."""
import contextlib
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

CASES = [
    ('nurture_children', {'newborn_priority': True}),
    ('nurture_late_food', {'late_feeding': True}),
    ('nurture_combined', {'newborn_priority': True, 'late_feeding': True}),
]

def evaluate(job):
    from campaign_runner import run
    label, config, seed = job
    path = Path('campaign')/f'{label}_s{seed}.jsonl'
    if path.exists():
        for line in path.read_text().splitlines():
            r = json.loads(line)
            if r.get('event') == 'result':
                return label, seed, r['survival_seconds']
    with open(f'campaign_{label}_s{seed}.out', 'a', buffering=1) as f, contextlib.redirect_stdout(f):
        r = run(seed, 'nurture_policy:NurturePolicy', config, label)
    return label, seed, r['survival_seconds']

if __name__ == '__main__':
    with ProcessPoolExecutor(max_workers=3) as pool:
        jobs = [pool.submit(evaluate, (label, config, seed)) for label, config in CASES for seed in (1,2,3)]
        for future in as_completed(jobs):
            print(json.dumps(future.result()), flush=True)
