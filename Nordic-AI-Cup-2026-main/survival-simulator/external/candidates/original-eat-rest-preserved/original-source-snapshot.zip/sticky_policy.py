"""Committed wall following avoids reversing at a blocked fruit's projection."""
import math
from adaptive_policy import AdaptivePolicy
from nursery_policy import segment_clear
from species_field_trial import unit,rotate
from src.utils.controllers.potential_field_policy import closest_point


class StickyPolicy(AdaptivePolicy):
    def __init__(self,preset='sticky',**overrides):
        config=dict(crowd_escape=False,sprint_ceiling=16.,wall_follow=True,
                    stall_timeout=2.,stall_blacklist=8.,stuck_recovery=True)
        config.update(overrides)
        super().__init__(preset,**config)

    def allocate(self,views):
        for aid,view in views.items():
            mem=view['mem']
            mem.blocked_fruit={k:t for k,t in getattr(mem,'blocked_fruit',{}).items() if t>self.clock}
            previous=self.canonical(mem.target_id) if mem.target_id is not None else None
            old=next((f for f in view['fruits'] if self.canonical(f['key'])==previous),None)
            if old is not None and self.config['stuck_recovery']:
                d=old['obs']['distance']
                if previous!=getattr(mem,'progress_target',None) or d<getattr(mem,'progress_distance',math.inf)-3.:
                    mem.progress_target=previous;mem.progress_distance=d;mem.progress_time=self.clock
                elif self.clock-mem.progress_time>self.config['stall_timeout'] and d>20.:
                    mem.blocked_fruit[previous]=self.clock+self.config['stall_blacklist']
                    mem.target_id=None;mem.follow_side=None
                    self.metrics['stalled_targets_released']+=1
        super().allocate(views)

    def shared_frames(self,views):
        super().shared_frames(views)
        for view in views.values():
            blocked=getattr(view['mem'],'blocked_fruit',{})
            view['fruits']=[f for f in view['fruits'] if self.canonical(f['key']) not in blocked]

    def slide(self,desired,view,distance):
        if not self.config['wall_follow']:return super().slide(desired,view,distance)
        desired=unit(desired);mem=view['mem']
        target=view.get('visible',{}).get(mem.target_id)
        goal=target['p'] if target is not None and not view['escaping'] else (desired[0]*120.,desired[1]*120.)
        sides=sorted((math.hypot(*closest_point(e)),e) for e in view['edges'])
        if not sides:return desired,False
        clearance,edge=sides[0]
        p=closest_point(edge);normal=unit((-p[0],-p[1]))
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(view['state']['biome'],1.)
        inward=-(desired[0]*normal[0]+desired[1]*normal[1])
        blocked=not segment_clear((0.,0.),goal,view['edges'],5.5)
        following=getattr(mem,'follow_side',None)
        if following is not None and (not blocked or clearance>32.):
            mem.follow_side=None;following=None
        if following is None:
            if inward<=0. or clearance>8.+inward*distance*terrain:return desired,False
            tangent=(-normal[1],normal[0])
            projection=desired[0]*tangent[0]+desired[1]*tangent[1]
            if abs(projection)<.05:
                previous=rotate(mem.last_move,-mem.last_turn)
                projection=previous[0]*tangent[0]+previous[1]*tangent[1]
            following=1 if projection>=0. else -1
            mem.follow_side=following
        tangent=(-normal[1]*following,normal[0]*following)
        offset=max(-.5,min(.5,(9.-clearance)*.25))
        result=unit((tangent[0]+offset*normal[0],tangent[1]+offset*normal[1]))
        self.metrics['committed_wall_ticks']+=1
        return result,True
