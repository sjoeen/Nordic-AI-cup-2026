"""Replace aging foragers; keep retired parents as energy-funded reserves."""
import math
from habitat_policy import HabitatPolicy


class LineagePolicy(HabitatPolicy):
    def __init__(self,preset='lineage',**overrides):
        config=dict(population=8,population_floor=2,population_decay=1200.,search_speed=.3,
                    planning=False,scan=.25,retire_after_birth=True,replacement_age=50.,
                    replacement_energy=140.,birth_energy=220.,idle_energy=.8)
        config.update(overrides)
        super().__init__(preset,**config)
        self.passive=set()

    def decide_all(self,states,sim_time=None):
        if any(s['agent_id'] in self.memory and s['age']<self.memory[s['agent_id']].last_age for s in states):
            self.memory.clear();self.parents.clear();self.first_seen.clear();self.birth_times.clear();self.passive.clear();self.clock=0.
        self.clock=float(sim_time) if sim_time is not None else self.clock+.1
        live={s['agent_id'] for s in states}
        self.memory={k:v for k,v in self.memory.items() if k in live}
        self.passive &= live
        views={s['agent_id']:self.observe(s) for s in sorted(states,key=lambda s:s['agent_id'])}
        c=self.config
        cap=max(c['population_floor'],round(c['population']*.5**(self.clock/c['population_decay'])))
        active=[s for s in states if s['agent_id'] not in self.passive]
        # Resume the healthiest reserve if no forager remains.
        if not active and states:
            revived=max(states,key=lambda s:s['energy']/(1.+max(0.,s['age']-60.)))
            self.passive.discard(revived['agent_id']);active=[revived]
        if len(active)>cap:
            excess=sorted(active,key=lambda s:(s['age'], -min(s['speed'],s['sprint_speed'])),reverse=True)[:len(active)-cap]
            self.passive.update(s['agent_id'] for s in excess if s['age']>c['replacement_age'])
            active=[s for s in active if s['agent_id'] not in self.passive]
        vacancy=max(0,cap-len(active))
        self.spawn_ids=set();replace=set()
        ordered=sorted(states,key=lambda s:(min(s['speed'],s['sprint_speed'])*math.sqrt(s['hearing_radius']+.5*s['vision_range']),s['energy']),reverse=True)
        for s in ordered:
            aid=s['agent_id'];view=views[aid]
            safe=not view['predators'] or min(p['obs']['distance'] for p in view['predators'])>150.
            if not safe:continue
            if vacancy>0 and s['energy']>max(125.,min(c['birth_energy'],.7*s['max_energy'])):
                self.spawn_ids.add(aid);vacancy-=1
                if aid in self.passive:replace.add(aid)
            elif aid not in self.passive and s['age']>=c['replacement_age'] and s['energy']>c['replacement_energy']:
                self.spawn_ids.add(aid);replace.add(aid)
        for aid,view in views.items():
            s=view['state']
            view['resting']=aid in self.passive or (s['energy']>c['idle_energy']*s['max_energy'] and aid not in self.spawn_ids)
            view['eligible']=not view['resting']
        self.retired_ids=set(self.passive)
        self.allocate(views)
        actions=[self.steer(views[s['agent_id']]) for s in states]
        for action in actions:
            if action.spawn_agent and action.agent_id in replace:self.passive.add(action.agent_id)
        return actions
