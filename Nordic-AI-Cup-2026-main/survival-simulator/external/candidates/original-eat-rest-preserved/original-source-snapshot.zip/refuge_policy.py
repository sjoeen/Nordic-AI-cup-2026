"""Estimate threat travel distance around observed obstacle edges."""
import math
from adaptive_policy import AdaptivePolicy
from nursery_policy import segment_clear
from species_field_trial import rotate


class RefugePolicy(AdaptivePolicy):
    def __init__(self,preset='refuge',**overrides):
        config=dict(face_predators=True,blocked_threat_distance=65.,crowd_escape=True,
                    hard_idle_energy=250.,birth_energy=180.)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state)
        mem=view['mem']
        previous=[]
        for edge,seen in getattr(mem,'shelter_edges',[]):
            if self.clock-seen>2.:continue
            transformed=[]
            for p in edge:
                q=rotate(p,-mem.last_turn)
                transformed.append((q[0]-view['translation'][0],q[1]-view['translation'][1]))
            previous.append((tuple(transformed),seen))
        current=[(edge,self.clock) for edge in view['edges']]
        mem.shelter_edges=(previous+current)[-60:]
        threats=[]
        for enemy in view['predators']:
            blocked=[edge for edge,t in mem.shelter_edges if not segment_clear((0.,0.),enemy['p'],[edge],0.)]
            if blocked:
                length=max(min(math.hypot(*q)+math.hypot(q[0]-enemy['p'][0],q[1]-enemy['p'][1]) for q in edge) for edge in blocked)
                if length>self.config['blocked_threat_distance'] and enemy['obs']['distance']>22.:
                    self.metrics['sheltered_threat_ticks']+=1
                    continue
            d=enemy['obs']['distance'];v=enemy['velocity']
            closing=-(v[0]*enemy['p'][0]+v[1]*enemy['p'][1])/max(1.,d)
            radius=self.config['rest_radius'] if enemy['measured'] and math.hypot(*v)<.5 else self.config['escape_radius']
            if d<radius or (closing>2. and d/closing<7.):threats.append(enemy)
        view['escaping']=bool(threats)
        if threats:view['predators'].sort(key=lambda e:(e not in threats,e['obs']['distance']))
        return view
