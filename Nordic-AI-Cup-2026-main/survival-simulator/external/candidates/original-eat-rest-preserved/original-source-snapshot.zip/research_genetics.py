import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('refuge',{'label':'balanced_genetics','quality_mode':'ecological','fitness_population':True,'population':10,'population_floor':3}),
 ('refuge',{'label':'sensory_genetics','quality_mode':'sensory','fitness_population':True,'population':10,'population_floor':3}),
 ('refuge',{'label':'sensory_selection','quality_mode':'sensory','selective_breeding':250.,'population':10,'population_floor':3}),
 ('safety',{'label':'sensory_safety','enemy_speed':'maximum','filter_horizon':2,'quality_mode':'sensory','fitness_population':True,'population':10,'population_floor':3}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_genetics_{seed}.jsonl')
