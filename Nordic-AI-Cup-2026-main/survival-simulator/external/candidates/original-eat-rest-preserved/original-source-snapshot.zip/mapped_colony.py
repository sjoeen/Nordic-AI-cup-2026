"""Combine observation-derived exploration maps with tested colony steering."""
from atlas_policy import AtlasPolicy
from dispersal_policy import DispersalPolicy
from foraging_policy import ForagingPolicy
from species_field_trial import SpeciesFields


class MappedColony(AtlasPolicy,DispersalPolicy):
    def __init__(self,preset='mapped_colony',**overrides):
        config=dict(dispersal_distance=100.,escape='direct',search_speed=.4,persistent_sharing=False)
        config.update(overrides)
        super().__init__(preset,**config)

    def shared_frames(self,views):
        if self.config['persistent_sharing']:return super().shared_frames(views)
        return SpeciesFields.shared_frames(self,views)


class LearningColony(ForagingPolicy,DispersalPolicy):
    def __init__(self,preset='learning_colony',**overrides):
        config=dict(dispersal_distance=100.,forage_style='bandit')
        config.update(overrides)
        super().__init__(preset,**config)
