"""When no fruit is available, use remembered feeding patches as destinations."""
import math
from food_map_policy import FoodMapPolicy
from species_field_trial import rotate, unit, wrap


class OrchardPolicy(FoodMapPolicy):
    def __init__(self, preset='orchard', **overrides):
        config = dict(food_map_memory=8., orchard_range=600., orchard_wait=10.,
                      orchard_memory=25., orchard_start=0., orchard_capacity=2,
                      orchard_newborn=False)
        config.update(overrides)
        super().__init__(preset, **config)
        self.orchards = {}

    def shared_frames(self, views):
        if self.clock < self.map_clock:
            self.orchards.clear()
        super().shared_frames(views)
        c = self.config
        self.orchards = {key:item for key,item in self.orchards.items()
                         if self.clock-item[1]<c['orchard_memory']}
        for aid,v in views.items():
            pose = self.food_poses.get(aid)
            if pose is None or pose[2]>.01 or v['map_stale']:
                continue
            origin,heading,_ = pose
            actual = []
            for o in v['state']['observations']:
                if o['type']!='Tree':
                    continue
                local = (o['distance']*math.cos(o['angle']),o['distance']*math.sin(o['angle']))
                q = rotate(local,heading)
                p = (origin[0]+q[0],origin[1]+q[1])
                actual.append(p)
                key = (round(p[0]/4.),round(p[1]/4.))
                old = self.orchards.get(key)
                self.orchards[key] = (p,self.clock,old[2] if old else self.clock)
            for key,(p,seen,first) in list(self.orchards.items()):
                if math.hypot(p[0]-origin[0],p[1]-origin[1]) < v['state']['hearing_radius']-5.:
                    if not any(math.hypot(q[0]-p[0],q[1]-p[1])<5. for q in actual):
                        self.orchards.pop(key,None)

    def allocate(self, views):
        super().allocate(views)
        c = self.config
        if self.clock < c['orchard_start']:
            return
        reserved = {}
        occupied_food = {v['mem'].target_id for v in views.values() if v['mem'].target_id is not None}
        for aid,v in sorted(views.items(),key=lambda row:row[1]['state']['energy']):
            s,m = v['state'],v['mem']
            v['orchard_goal'] = None
            if c['orchard_newborn'] and m.colonist and not v['escaping']:
                terrain = {'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
                speed = max(.1,min(s['speed'],s['sprint_speed']))
                available = [f for key,f in v['visible'].items() if key not in occupied_food
                             and max(0.,f['obs']['distance']-10.)/terrain*(.05+.1/speed)+15. < s['energy']]
                if available:
                    food = min(available,key=lambda f:f['obs']['distance'])
                    m.colonist = False
                    m.target_id = food['id']
                    v['resting'] = False
                    v['eligible'] = True
                    occupied_food.add(m.target_id)
                    self.metrics['orchard_newborn_food'] += 1
            if v['escaping'] or v.get('resting') or (m.colonist and not c['orchard_newborn']) or m.target_id is not None:
                if m.target_id is not None:
                    m.orchard_wait_since = None
                continue
            pose = self.food_poses.get(aid)
            if pose is None or pose[2]>.01 or v['map_stale']:
                continue
            origin,heading,_ = pose
            blacklist = getattr(m,'orchard_blacklist',{})
            m.orchard_blacklist = {key:t for key,t in blacklist.items() if self.clock-t<35.}
            options = []
            for key,(p,seen,first) in self.orchards.items():
                if key in m.orchard_blacklist:
                    continue
                distance = math.hypot(p[0]-origin[0],p[1]-origin[1])
                if distance > c['orchard_range']:
                    continue
                occupants = {bid for bid,bp in self.food_poses.items() if bid!=aid and bp[2]<=.01
                             and math.hypot(bp[0][0]-p[0],bp[0][1]-p[1])<85.}
                crowd = len(occupants | (reserved.get(key,set())-{aid}))
                if crowd >= c['orchard_capacity']:
                    continue
                terrain = {'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
                speed = max(.1,min(s['speed'],s['sprint_speed']))
                aging = max(0.,min(1.,(s['age']-60.)/60.))*.1*s['age']
                cost = max(0.,distance-35.)/terrain*(.05+.1*(1.32+aging)/speed)
                if cost+15. > s['energy']:
                    continue
                old_key = getattr(m,'orchard_key',None)
                score = distance+80.*crowd+4.*(self.clock-seen)-(35. if key==old_key else 0.)
                options.append((score,key,p,distance))
            if not options:
                continue
            _,key,p,distance = min(options)
            if getattr(m,'orchard_key',None)!=key:
                m.orchard_wait_since = None
                m.orchard_progress = (distance,self.clock)
            m.orchard_key = key
            best,progress_time = getattr(m,'orchard_progress',(distance,self.clock))
            if distance<best-10.:
                m.orchard_progress = (distance,self.clock)
            elif distance>45. and self.clock-progress_time>4.:
                m.orchard_blacklist[key] = self.clock
                continue
            if distance < 40.:
                if getattr(m,'orchard_wait_since',None) is None:
                    m.orchard_wait_since = self.clock
                if self.clock-m.orchard_wait_since >= c['orchard_wait']:
                    m.orchard_blacklist[key] = self.clock
                    continue
            local = rotate((p[0]-origin[0],p[1]-origin[1]),-heading)
            v['orchard_goal'] = local
            if c['orchard_newborn']:
                m.colonist = False
                v['resting'] = False
            reserved.setdefault(key,set()).add(aid)

    def steer(self, view):
        action = super().steer(view)
        s,m = view['state'],view['mem']
        goal = view.get('orchard_goal')
        if goal is None or m.last_mode!='SEARCH':
            return action
        terrain = {'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        speed = min(s['speed'],s['sprint_speed'],max(0.,math.hypot(*goal)-35.)/terrain)
        direction,_ = self.slide(unit(goal),view,speed)
        action.move_distance = speed
        action.move_direction = math.atan2(direction[1],direction[0])
        action.turn_angle = self.config['scan']
        m.last_move = (speed*terrain*direction[0],speed*terrain*direction[1])
        m.last_turn = action.turn_angle
        m.search_heading = wrap(m.heading+action.move_direction)
        m.last_mode = 'ORCHARD'
        self.metrics['orchard_ticks'] += 1
        return action
