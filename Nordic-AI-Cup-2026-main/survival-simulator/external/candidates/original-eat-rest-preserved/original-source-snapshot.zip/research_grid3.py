import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('safety',{'label':'blind_spot','respect_enemy_vision':True,'concealment_bonus':20.,'filter_horizon':5}),
 ('direct',{'label':'fast_scout','population':6,'search_speed':1.}),
 ('atlas',{'label':'atlas_direct','escape':'direct','gaze_turn':3.141592653589793,'search_speed':.7,'population':6,'population_floor':2}),
 ('safety',{'label':'food_first','respect_enemy_vision':True,'filter_horizon':2,'filter_margin':22.,'filter_food':2.}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid3_{seed}.jsonl')
