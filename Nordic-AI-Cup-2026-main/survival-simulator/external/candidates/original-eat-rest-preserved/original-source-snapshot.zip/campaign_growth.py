import sys
from campaign_runner import run
CASES=[
 ('growth12',{'population':12,'phase_start':600.,'late_settings':{'population':6}}),
 ('growth20',{'population':20,'phase_start':600.,'late_settings':{'population':6}}),
 ('growth20_long',{'population':20,'phase_start':900.,'late_settings':{'population':6}}),
 ('growth12_early_birth',{'population':12,'birth_energy':160.,'phase_start':600.,'late_settings':{'population':6}}),
 ('growth12_sensory',{'population':12,'quality_mode':'sensory','fitness_population':True,'phase_start':600.,'late_settings':{'population':6,'quality_mode':'basic','fitness_population':False}}),
]
if __name__=='__main__':
    for label,config in CASES:run(int(sys.argv[1]),'growth_policy:GrowthPolicy',config,label)
