import sys
from research_runner import run
seed=int(sys.argv[1])
for config in [
 {'label':'colony_population8','dispersal_distance':100.,'population':8,'population_floor':3},
 {'label':'colony_population4','dispersal_distance':100.,'population':4,'population_floor':2},
]:run(seed,'dispersal',config,log=f'research_colony_population_{seed}.jsonl')
