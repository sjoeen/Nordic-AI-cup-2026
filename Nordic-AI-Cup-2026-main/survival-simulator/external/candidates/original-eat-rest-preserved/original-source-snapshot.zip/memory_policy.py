"""Remember unseen food briefly; invalidate it when its location is observed empty."""
import math
from sticky_policy import StickyPolicy
from nursery_policy import segment_clear
from species_field_trial import rotate,wrap


class MemoryPolicy(StickyPolicy):
    def __init__(self,preset='memory',**overrides):
        config=dict(stale_correction=True,fruit_memory_seconds=15.,stall_timeout=5.,
                    coverage=False,search_speed=.6)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        old_mem=self.memory.get(state['agent_id'])
        old_known=list(getattr(old_mem,'known_food',{}).items()) if old_mem else []
        if old_mem is not None:old_mem.fruit_tracks=[(key,item['p']) for key,item in old_known]
        view=super().observe(state)
        mem=view['mem'];state=view['state']
        known={self.canonical(f['key']):dict(p=f['p'],seen=self.clock,fruit=f) for f in view['fruits']}
        for key,item in old_known:
            key=self.canonical(key)
            if key in known or self.clock-item['seen']>self.config['fruit_memory_seconds']:continue
            q=rotate(item['p'],-mem.last_turn)
            p=(q[0]-view['translation'][0],q[1]-view['translation'][1])
            d=math.hypot(*p);angle=math.atan2(p[1],p[0])
            should_see=(d<state['hearing_radius']-2. or
                        (d<state['vision_range']-5. and abs(angle)<state['vision_angle']/2.-.04 and segment_clear((0.,0.),p,view['edges'],0.)))
            if d<12. or should_see:continue
            fruit=dict(key=key,p=p,remembered=True,obs=dict(type='Fruit',distance=d,angle=angle))
            known[key]=dict(p=p,seen=item['seen'],fruit=fruit)
            view['fruits'].append(fruit)
            self.metrics['remembered_food_ticks']+=1
        mem.known_food=known
        mem.fruit_tracks=[(key,item['p']) for key,item in known.items()]
        if self.config['coverage']:
            delta=rotate(view['translation'],mem.heading)
            position=getattr(mem,'map_position',(0.,0.))
            mem.map_position=(position[0]+delta[0],position[1]+delta[1])
            if not hasattr(mem,'visits'):mem.visits={};mem.terrain_map={}
            cell=(round(mem.map_position[0]/80.),round(mem.map_position[1]/80.))
            mem.visits[cell]=self.clock;mem.terrain_map[cell]=state['biome']
        return view

    def steer(self,view):
        s,mem=view['state'],view['mem']
        if self.config['coverage'] and not view['escaping'] and not view.get('resting') and mem.target_id is None:
            if self.clock>=getattr(mem,'next_coverage',0.):
                x,y=mem.map_position;choices=[]
                for i in range(16):
                    angle=mem.search_heading+i*math.pi/8
                    dx,dy=math.cos(angle),math.sin(angle)
                    score=3.*math.cos(angle-mem.search_heading)
                    for r in (80.,160.,240.):
                        cell=(round((x+r*dx)/80.),round((y+r*dy)/80.))
                        elapsed=self.clock-mem.visits.get(cell,-1000.)
                        score+=min(40.,elapsed)
                        score+={'forest':8.,'grassland':4.,'swamp':-2.,'desert':-8.,'river':-25.}.get(mem.terrain_map.get(cell),0.)
                    local=rotate((dx*100.,dy*100.),-mem.heading)
                    if not segment_clear((0.,0.),local,view['edges'],5.):score-=20.
                    choices.append((score,angle))
                _,mem.search_heading=max(choices)
                mem.next_coverage=self.clock+2.
        return super().steer(view)
