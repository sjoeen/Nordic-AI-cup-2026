import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('dispersal',{'label':'colonize_100','dispersal_distance':100.}),
 ('dispersal',{'label':'colonize_200'}),
 ('dispersal',{'label':'colonize_350','dispersal_distance':350.}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid11_{seed}.jsonl')
