import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('adaptive',{'label':'economical_sprint','crowd_escape':False,'sprint_ceiling':16.}),
 ('adaptive',{'label':'walk_only','crowd_escape':False,'sprint_ceiling':0.}),
 ('adaptive',{'label':'economical_arc','escape':'gaze','gaze_turn':1.,'crowd_escape':False,'sprint_ceiling':16.,'ripen_seconds':12.,'patch_wait':12.}),
 ('adaptive',{'label':'economical_crowd','sprint_ceiling':16.,'hard_idle_energy':250.,'birth_energy':180.}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid7_{seed}.jsonl')
