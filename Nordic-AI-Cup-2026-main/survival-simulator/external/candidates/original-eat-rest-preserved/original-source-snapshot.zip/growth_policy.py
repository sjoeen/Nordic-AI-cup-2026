"""Early population expansion followed by the tested low-population controller."""
from phase2_policy import PhasePolicy


class GrowthPolicy(PhasePolicy):
    def observe(self,state):
        v=super().observe(state)
        prefix='traits_'+str(int(self.clock)//300)+'_'
        for key,value in [('ticks',1),('walk',min(state['speed'],state['sprint_speed'])),
                          ('vision',state['vision_range']),('hearing',state['hearing_radius']),
                          ('sprint',state['sprint_speed']),('capacity',state['max_energy'])]:
            self.metrics[prefix+key]+=value
        return v
