import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 {'label':'mixed_migration'},
 {'label':'mixed_search','migration_fraction':1.,'mixed_search':True},
 {'label':'mixed_migration_search','mixed_search':True},
]
for config in cases:run(seed,'portfolio',config,log=f'research_portfolio_{seed}.jsonl')
