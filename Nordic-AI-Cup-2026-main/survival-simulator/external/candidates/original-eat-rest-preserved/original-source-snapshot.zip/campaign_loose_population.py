"""Remove reproduction quotas while retaining the same full test block."""
import json
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from campaign_feeding_queue import complete, evaluate
from campaign_food_search import COARSE

if __name__=='__main__':
    prerequisites = [label for label in COARSE if not label.startswith('loose_population')]
    while not all(complete(label,s) for label in prerequisites for s in (1,2,3)):
        time.sleep(10.)
    cases = [('loose_population24',24),('loose_population_free',10000)]
    for label,population in cases:
        config = dict(birth_energy=135.,birth_floor=112.,maximum_birth_gap=20.,population=population)
        with ProcessPoolExecutor(max_workers=3) as pool:
            jobs = [pool.submit(evaluate,('harvest_policy:HarvestPolicy',label,config,s)) for s in (1,2,3)]
            for future in as_completed(jobs):
                print(json.dumps(future.result()),flush=True)
