"""Temporary experiment for hierarchical, trait-aware field steering."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import time

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

from src.core import SimulationCore
from src.utils.DTOs import ActionRequest
from src.utils.controllers.potential_field_policy import closest_point, wrap


class HierarchicalFields:
    def __init__(self, birth_fraction=0.8):
        self.birth_fraction = birth_fraction

    def decide(self, state):
        energy = state["energy"]
        capacity = max(state["max_energy"], 1e-9)
        fraction = energy / capacity
        walk = max(0., min(state["speed"], state["sprint_speed"]))
        sprint = max(0., state["sprint_speed"])
        observations = state["observations"]
        fruits = sorted((o for o in observations if o["type"] == "Fruit" and o["distance"] > 6),
                        key=lambda o: (o["distance"], o["angle"]))
        predators = sorted((o for o in observations if o["type"] == "Predator"),
                           key=lambda o: (o["distance"], o["angle"]))
        neighbors = sorted((o for o in observations if o["type"] == "Agent"),
                           key=lambda o: (o["distance"], o["angle"], o.get("id", 0)))
        nearest_threat = predators[0]["distance"] if predators else math.inf
        target = fruits[0] if fruits else None
        wander = 0.035 * math.sin(state["age"] * .13 + state["agent_id"] * 2.399963)

        # Hierarchy: all detected predators suppress fruit/exploration forces.
        if predators:
            fx = fy = 0.
            for predator in predators:
                weight = 1. / max(predator["distance"], 5.) ** 2
                fx -= weight * math.cos(predator["angle"])
                fy -= weight * math.sin(predator["angle"])
            norm = math.hypot(fx, fy)
            if norm < 1e-9:
                fx, fy = -math.cos(predators[0]["angle"]), -math.sin(predators[0]["angle"])
                norm = 1.
            fx, fy = 4. * fx / norm, 4. * fy / norm
        else:
            fx, fy = .15 * math.cos(wander), .15 * math.sin(wander)
            for i, fruit in enumerate(fruits):
                # Individual fruit energy is not observed. Distance is the
                # available value proxy; favor the nearest to avoid averaging
                # equally between multiple targets.
                weight = 40. / max(fruit["distance"], 8.)
                if i == 0:
                    weight *= 3.
                fx += weight * math.cos(fruit["angle"])
                fy += weight * math.sin(fruit["angle"])

        # Obstacle clearance stays active during evasion, but clumping must
        # never overwhelm the escape vector.
        wall_range = max(20., min(40., 2. * walk + 5.))
        edges = {tuple(tuple(p) for p in o["coords"]) for o in observations if o["type"] == "Edge"}
        for edge in sorted(edges):
            px, py = closest_point(edge)
            distance = max(math.hypot(px, py), .1)
            if distance >= wall_range:
                continue
            strength = min(12., 4. * (1. - distance / wall_range) ** 2 * 5. / max(distance - 5., 1.))
            nx, ny = -px / distance, -py / distance
            tx, ty = -ny, nx
            if tx * fx + ty * fy < 0:
                tx, ty = -tx, -ty
            fx += strength * (nx + .5 * tx)
            fy += strength * (ny + .5 * ty)
        sx = sy = 0.
        for other in neighbors:
            if other["distance"] < 25.:
                weight = .3 * (1. - other["distance"] / 25.)
                sx -= weight * math.cos(other["angle"])
                sy -= weight * math.sin(other["angle"])
        magnitude = math.hypot(sx, sy)
        scale = min(1., .5 / max(magnitude, 1e-9))
        fx += sx * scale
        fy += sy * scale
        direction = math.atan2(fy, fx) if math.hypot(fx, fy) > 1e-9 else wander

        distance = walk
        critical = max(45., 1.2 * state["hearing_radius"])
        if predators:
            if fraction > .4 and nearest_threat < critical:
                distance = sprint
        else:
            # Aging cost is linear, with onset hidden in [60, 120]. Never
            # reduce emergency evasion or movement to immediately nearby food.
            if state["age"] > 60. and (not target or target["distance"] > state["hearing_radius"]):
                distance *= max(.5, 60. / state["age"])
            if target and abs(wrap(direction - target["angle"])) < .5:
                terrain = {"swamp": .5, "river": .3, "desert": .8}.get(state["biome"], 1.)
                distance = min(distance, max(0., target["distance"] - 6.) / terrain)

        # Absolute birth cost still matters for mutants with low capacity.
        threshold = max(self.birth_fraction * capacity, 100. + .2 * capacity)
        spawn = not predators and energy > threshold
        turn = max(-.4, min(.4, direction))
        return ActionRequest(agent_id=state["agent_id"], move_distance=distance,
                             move_direction=direction, turn_angle=turn, spawn_agent=spawn)


def initial_hash(sim):
    return hashlib.sha256(json.dumps({
        "agents": [(a.x, a.y, a.direction) for a in sim.env.agents],
        "fruits": [(a.x, a.y) for a in sim.env.fruits],
        "trees": [(a.x, a.y, a.age) for a in sim.env.trees],
        "obstacles": [(a.x, a.y, a.width, a.height) for a in sim.env.obstacles],
        "rng": repr(sim.rng.getstate()),
    }, sort_keys=True).encode()).hexdigest()


def run(seed, birth_fraction):
    start = time.perf_counter()
    policy = HierarchicalFields(birth_fraction)
    sim = SimulationCore(seed=seed)
    old = json.loads(Path('benchmark_results.json').read_text())
    assert initial_hash(sim) == next(r['initial_state_sha256'] for r in old if r['seed'] == seed)
    # Observational diagnostics only; forward every removal unchanged.
    deaths = []
    original_kill = sim.env.kill_agent
    def record_kill(agent):
        deaths.append((float(agent.age), float(agent.energy)))
        original_kill(agent)
    sim.env.kill_agent = record_kill
    actions = []
    peak = len(sim.env.agents)
    calls = 0
    policy_time = 0.
    for tick in range(30000):
        state = sim.step(actions)
        peak = max(peak, state['num_agents'])
        if (tick + 1) % 1000 == 0:
            print(json.dumps(dict(event='progress', seed=seed, birth_fraction=birth_fraction,
                                  time=round(state['sim_time'], 1), alive=state['num_agents'],
                                  born=sim.env._next_agent_id, score=round(state['score'], 2))), flush=True)
        if not state['num_agents']:
            break
        t = time.perf_counter()
        actions = [(obs['agent_id'], policy.decide(obs)) for obs in state['observations']]
        calls += len(actions)
        policy_time += time.perf_counter() - t
    result = dict(seed=seed, birth_fraction=birth_fraction, survival_seconds=round(state['sim_time'], 1),
                  score=state['score'], completed=bool(state['num_agents'] and tick + 1 == 30000),
                  peak_agents=peak, agents_born=sim.env._next_agent_id,
                  deaths_with_no_energy=sum(energy <= 0 for age, energy in deaths),
                  deaths_with_energy=sum(energy > 0 for age, energy in deaths),
                  mean_age_at_death=statistics.mean(age for age, energy in deaths) if deaths else None,
                  controller_us=policy_time * 1e6 / max(calls, 1), wall_seconds=time.perf_counter() - start)
    print(json.dumps(dict(event='result', **result)), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seeds', nargs='+', type=int, default=[1, 2, 3])
    parser.add_argument('--birth-fraction', type=float, default=.8)
    args = parser.parse_args()
    results = [run(seed, args.birth_fraction) for seed in args.seeds]
    print(json.dumps(dict(event='summary', results=results,
                          mean_survival=statistics.mean(r['survival_seconds'] for r in results),
                          mean_score=statistics.mean(r['score'] for r in results))), flush=True)
