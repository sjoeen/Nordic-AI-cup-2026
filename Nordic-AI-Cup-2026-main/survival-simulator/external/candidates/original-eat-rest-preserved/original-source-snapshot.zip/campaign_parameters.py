"""Predeclared full-size controlled parameter comparisons."""
import sys
from campaign_runner import run

CASES=[
 ('param_rest200',{'hard_idle_energy':200.}),
 ('param_rest300',{'hard_idle_energy':300.}),
 ('param_birth160',{'birth_energy':160.}),
 ('param_birth210',{'birth_energy':210.}),
 ('param_renew55',{'young_age':55.,'renewal_age':65.}),
 ('param_scan01',{'scan':.1}),
 ('param_scan035',{'scan':.35}),
 ('param_search06',{'search_speed':.6}),
 ('param_colonize60',{'dispersal_distance':60.}),
 ('param_floor4',{'population_floor':4}),
 ('param_decay1400',{'population_decay':1400.}),
 ('param_danger80',{'escape_radius':80.,'rest_radius':35.}),
]

if __name__=='__main__':
    seed=int(sys.argv[1]);start=int(sys.argv[2]) if len(sys.argv)>2 else 0
    for label,config in CASES[start:]:
        run(seed,'dispersal_policy:DispersalPolicy',dict(dispersal_distance=100.,**config) if 'dispersal_distance' not in config else config,label)
