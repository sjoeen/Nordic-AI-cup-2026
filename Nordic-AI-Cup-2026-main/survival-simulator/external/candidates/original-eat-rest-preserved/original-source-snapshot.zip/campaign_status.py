import json
from pathlib import Path
from collections import defaultdict
import statistics

groups=defaultdict(dict)
progress=[]
for p in sorted(Path('campaign').glob('*.jsonl')):
    rows=[]
    for line in p.read_text().splitlines():
        try:rows.append(json.loads(line))
        except ValueError:pass
    if not rows:continue
    last=rows[-1]
    if last['event']=='result':groups[last['label']][last['seed']]=last
    else:progress.append((last['label'],last['seed'],last.get('time',0.),last.get('alive')))
print('Completed games',sum(map(len,groups.values())))
ranked=[]
for label,runs in groups.items():
    if set((1,2,3)).issubset(runs):
        triplet=[runs[s]['survival_seconds'] for s in (1,2,3)]
        ranked.append((statistics.mean(triplet),label,triplet,
                       sum(runs[s]['completed'] for s in (1,2,3)),
                       round(statistics.mean(runs[s]['controller_mean_ms'] for s in (1,2,3)),2)))
for mean,label,triplet,complete,ms in sorted(ranked,reverse=True):
    print(round(mean,1),label,triplet,'full',complete,'mean_ms',ms)
print('Incomplete',progress)
for label,runs in groups.items():
    if not set((1,2,3)).issubset(runs):print('Partial',label,{s:r['survival_seconds'] for s,r in runs.items()})
