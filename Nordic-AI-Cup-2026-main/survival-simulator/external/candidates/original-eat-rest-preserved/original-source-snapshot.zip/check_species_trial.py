"""Focused checks using synthetic observations, not an altered simulator."""
import math
from species_field_trial import SpeciesFields, wrap
from verify_controller import observation


def fruit(x, y):
    return dict(type='Fruit', distance=math.hypot(x,y), angle=math.atan2(y,x))


def threat(distance, angle=0., rel_dir=0.):
    return dict(type='Predator', distance=distance, angle=angle, rel_dir=rel_dir)


def test_persistence():
    policy = SpeciesFields('persistent')
    a = policy.decide_all([observation(age=1., observations=[fruit(50,0),fruit(55,20)])])[0]
    original = policy.memory[0].target_id
    assert a.move_direction == 0.
    # After walking 10 units forward, a new closer fruit appears off-axis.
    b = policy.decide_all([observation(age=1.1, observations=[fruit(40,0),fruit(45,20),fruit(10,8)])])[0]
    assert policy.memory[0].target_id == original
    assert abs(b.move_direction) < 1e-9
    c = policy.decide_all([observation(age=1.2, energy=250., observations=[fruit(30,0),threat(40.)])])[0]
    assert policy.memory[0].target_id is None and math.cos(c.move_direction)<-.9
    assert c.move_distance == 20.
    # New run with reused ID resets the old target and heading state.
    policy.decide_all([observation(age=.1, observations=[fruit(0,30)])])
    assert policy.memory[0].last_age == .1


def test_shared_assignment():
    policy = SpeciesFields('allocated')
    # A at (0,0), heading 0. B at (20,0), heading pi/2.
    a = observation(agent_id=0,observations=[fruit(50,0),fruit(100,30),
                         dict(type='Agent',id=1,distance=20.,angle=0.,rel_dir=math.pi/2)])
    b = observation(agent_id=1,observations=[fruit(0,-30),fruit(30,-80),
                         dict(type='Agent',id=0,distance=20.,angle=math.pi/2,rel_dir=0.)])
    policy.decide_all([a,b])
    ka, kb = policy.memory[0].target_id, policy.memory[1].target_id
    assert ka != kb
    assert policy.canonical((0,1)) == policy.canonical((1,1)) == kb
    assert policy.canonical((0,2)) == policy.canonical((1,2)) == ka
    # The closer teammate can receive a fruit observed only by the other
    # agent; the shared frame supplies its relative bearing and distance.
    policy = SpeciesFields('allocated')
    hidden_from_b = dict(b, observations=[o for o in b['observations'] if o['type']!='Fruit'])
    policy.decide_all([a,hidden_from_b])
    assert policy.memory[1].target_id == policy.canonical((0,1))
    # An escaping agent cannot claim a fruit.
    policy = SpeciesFields('allocated')
    b['observations'].append(threat(100.))
    policy.decide_all([a,b])
    assert policy.memory[1].target_id is None and policy.memory[0].target_id is not None


def test_modes():
    for variant in ('modes','persistent','allocated','sliding','tangent'):
        p = SpeciesFields(variant)
        action = p.decide_all([observation(energy=200.,observations=[threat(40.),fruit(20,0)])])[0]
        assert action.move_distance == 10. and not action.spawn_agent
        assert p.metrics['escape_ticks'] == 1
        p = SpeciesFields(variant)
        action = p.decide_all([observation(observations=[threat(150.),fruit(30,0)])])[0]
        assert abs(action.move_direction)<1e-9 and p.metrics['eat_ticks']==1
        p = SpeciesFields(variant)
        action = p.decide_all([observation()])[0]
        assert action.move_distance>0. and math.isfinite(action.move_direction)


def test_sliding_and_arc():
    p = SpeciesFields('sliding')
    action = p.decide_all([observation(observations=[fruit(50,0),
                                dict(type='Edge',coords=((12.,-100.),(12.,100.)))])])[0]
    assert abs(math.sin(action.move_direction))>.95
    assert math.cos(action.move_direction)>-.2
    p = SpeciesFields('sliding')
    action = p.decide_all([observation(observations=[dict(type='Edge',coords=((12.,-100.),(12.,100.)))])])[0]
    assert abs(wrap(p.memory[0].search_heading-action.move_direction))<1e-9
    p = SpeciesFields('tangent')
    action = p.decide_all([observation(energy=250.,observations=[threat(40.)])])[0]
    assert abs(abs(wrap(action.move_direction-math.pi))-math.pi/3)<1e-9
    assert action.move_distance==20.


if __name__=='__main__':
    for check in (test_persistence,test_shared_assignment,test_modes,test_sliding_and_arc):
        check()
        print(check.__name__, 'passed')
