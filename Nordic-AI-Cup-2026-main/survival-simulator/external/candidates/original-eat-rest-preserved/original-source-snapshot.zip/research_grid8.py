import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('sticky',{'label':'committed_walls','stuck_recovery':False}),
 ('sticky',{'label':'stalled_target_release','wall_follow':False}),
 ('sticky',{'label':'committed_walls_release'}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid8_{seed}.jsonl')
