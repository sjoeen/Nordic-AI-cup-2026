import collections,datetime,json,pathlib,statistics,sys,time
G=collections.defaultdict(list);active=[]
for f in pathlib.Path('.').glob('research*.jsonl'):
 rows=[]
 for l in f.read_text().splitlines():
  try:r=json.loads(l)
  except ValueError:continue
  rows.append(r)
  if r.get('event')=='result':G[r['overrides'].get('label',r['preset'])].append(r)
 if rows and rows[-1]['event']!='result' and time.time()-f.stat().st_mtime<900:
  starts=[r for r in rows if r['event']=='start']
  if starts:
   r=starts[-1];active.append((r['overrides'].get('label',r['preset']),r['seed'],rows[-1].get('time',0),f.stem))
rank=[]
for label,rows in G.items():
 if len(rows)==3 and {r['seed'] for r in rows}=={1,2,3}:
  rows.sort(key=lambda r:r['seed'])
  rank.append((round(statistics.mean(r['survival_seconds'] for r in rows),1),label,[r['survival_seconds'] for r in rows],round(statistics.mean(r['score'] for r in rows),1)))
print(datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'))
print('COMPLETED',sum(map(len,G.values())),'FULL_BATCHES',len(rank),'SURVIVED_3000',sum(r['completed'] for rows in G.values() for r in rows))
for row in sorted(rank,reverse=True)[:12]:print(row)
if '--active' in sys.argv:
 for item in sorted(active):print('ACTIVE',item)
for label in sys.argv[1:]:
 if label.startswith('--'):continue
 print('CASE',label,[(r['seed'],r['survival_seconds'],round(r['score'],1)) for r in G[label]])
