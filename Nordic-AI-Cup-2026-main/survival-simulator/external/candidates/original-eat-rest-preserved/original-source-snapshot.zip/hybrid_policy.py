"""Short predictive safety filtering with offspring dispersal and refuges."""
import math
from safety_policy import SafetyPolicy
from dispersal_policy import DispersalPolicy
from nursery_policy import segment_clear


class HybridPolicy(SafetyPolicy, DispersalPolicy):
    def __init__(self,preset='hybrid',**overrides):
        config=dict(dispersal_distance=100.,enemy_speed='maximum',filter_horizon=2,
                    planning=False,hard_idle_energy=250.,birth_energy=180.,
                    stale_correction=True,ignore_sheltered=True)
        config.update(overrides)
        super().__init__(preset,**config)

    def steer(self,view):
        original=view['predators']
        if self.config['ignore_sheltered']:
            relevant=[]
            for enemy in original:
                blocked=[edge for edge,t in getattr(view['mem'],'shelter_edges',[])
                         if not segment_clear((0.,0.),enemy['p'],[edge],0.)]
                distance=0.
                if blocked:
                    distance=max(min(math.hypot(*p)+math.hypot(p[0]-enemy['p'][0],p[1]-enemy['p'][1]) for p in edge) for edge in blocked)
                if distance<=65. or enemy['obs']['distance']<=22.:relevant.append(enemy)
            view['predators']=relevant
        action=super().steer(view)
        view['predators']=original
        return action
