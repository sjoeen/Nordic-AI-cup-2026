"""Smoother generational replacement without changing simulator rules."""
import math
from dispersal_policy import DispersalPolicy


class GenerationPolicy(DispersalPolicy):
    def __init__(self,preset='generation',**overrides):
        config=dict(dispersal_distance=100.,generation_mode='baseline',generation_fraction=.65,
                    generation_lifetime=90.,birth_spacing=0.,maximum_birth_gap=0.,
                    elder_birth_priority=False,young_energy_weight=0.)
        config.update(overrides);super().__init__(preset,**config)
        self.last_normal_birth=-1000.

    def decide_all(self,states,sim_time=None):
        if ((sim_time is not None and sim_time<self.clock) or
                any(s['agent_id'] in self.memory and s['age']<self.memory[s['agent_id']].last_age for s in states)):
            self.last_normal_birth=-1000.
        return super().decide_all(states,sim_time)

    def allocate(self,views):
        c=self.config
        if c['generation_mode']!='baseline' or c['birth_spacing'] or c['maximum_birth_gap'] or c['elder_birth_priority']:
            states=[v['state'] for v in views.values()]
            cap=max(c['population_floor'],round(c['population']*.5**(self.clock/c['population_decay'])))
            young=sum(s['age']<c['young_age'] for s in states)
            budget=max(0,cap-young)
            if c['generation_mode']=='linear':
                effective=sum(max(0.,1.-s['age']/c['generation_lifetime']) for s in states)
                budget=max(0,math.floor(cap*c['generation_fraction']-effective+.5))
            elif c['generation_mode']=='energy':
                effective=sum(min(1.,max(.25,s['energy']/120.)) for s in states if s['age']<c['young_age'])
                budget=max(0,math.floor(cap-effective+.5))
            if c['maximum_birth_gap'] and len(states)<2*cap:
                youngest=min((s['age'] for s in states if s['energy']>40.),default=1000.)
                if youngest>c['maximum_birth_gap']:budget=max(budget,1)
            if c['birth_spacing']:
                budget=min(budget,int(self.clock-self.last_normal_birth>=c['birth_spacing']))
            candidates=[]
            for aid,v in views.items():
                s=v['state']
                threshold=max(c['birth_floor'],min(c['birth_energy'],.75*s['max_energy']))
                if s['age']>60 and young<max(2,cap//2):threshold=min(threshold,160.)
                safe=not v['predators'] or min(p['obs']['distance'] for p in v['predators'])>130.
                if s['energy']<=threshold or not safe or aid in self.retired_ids:continue
                quality=min(s['speed'],s['sprint_speed'])+.015*s['hearing_radius']+.003*s['vision_range']
                elder=(s['age']>70.,s['age']) if c['elder_birth_priority'] else (False,0.)
                candidates.append((elder,quality,s['energy'],-aid,aid))
            self.spawn_ids={item[-1] for item in sorted(candidates,reverse=True)[:budget]}
            if self.spawn_ids:self.last_normal_birth=self.clock
            for aid,v in views.items():
                s=v['state']
                v['resting']=aid in self.retired_ids or (s['energy']>min(c['hard_idle_energy'],c['idle_energy']*s['max_energy']) and aid not in self.spawn_ids)
                v['eligible']=not v['resting']
        super().allocate(views)
