"""Shared predator alarms and energy-aware fruit assignment."""
import math
from adaptive_policy import AdaptivePolicy
from species_field_trial import rotate,wrap


class AlarmPolicy(AdaptivePolicy):
    def __init__(self,preset='alarm',**overrides):
        config=dict(crowd_escape=False,emergency_birth=False,population=8,population_floor=3,
                    alarm_sharing=True,food_triage=True,triage_age=80.,triage_reserve=150.)
        config.update(overrides)
        super().__init__(preset,**config)

    def shared_frames(self,views):
        super().shared_frames(views)
        if not self.config['alarm_sharing']:return
        pooled=[]
        for aid,view in views.items():
            comp,origin,heading=view['shared_pose']
            for enemy in view['predators']:
                p=rotate(enemy['p'],heading)
                pooled.append((comp,(p[0]+origin[0],p[1]+origin[1]),rotate(enemy['velocity'],heading),wrap(enemy['heading']+heading),enemy['measured']))
        for aid,view in views.items():
            comp,origin,heading=view['shared_pose']
            for pc,p,v,h,measured in pooled:
                if pc!=comp:continue
                q=rotate((p[0]-origin[0],p[1]-origin[1]),-heading)
                d=math.hypot(*q)
                if d>220. or any(math.hypot(e['p'][0]-q[0],e['p'][1]-q[1])<8. for e in view['predators']):continue
                view['predators'].append(dict(p=q,heading=wrap(h-heading),velocity=rotate(v,-heading),measured=measured,
                    obs=dict(type='Predator',distance=d,angle=math.atan2(q[1],q[0])),shared=True))
                self.metrics['shared_predator_observations']+=1
            view['predators'].sort(key=lambda e:e['obs']['distance'])
            threats=[]
            for enemy in view['predators']:
                d=enemy['obs']['distance'];v=enemy['velocity']
                closing=-(v[0]*enemy['p'][0]+v[1]*enemy['p'][1])/max(1.,d)
                radius=self.config['rest_radius'] if enemy['measured'] and math.hypot(*v)<.5 else self.config['escape_radius']
                if d<radius or (closing>2. and d/closing<7.):threats.append(enemy)
            view['escaping']=bool(threats)
            if threats:
                view['predators'].sort(key=lambda e:(e not in threats,e['obs']['distance']))

    def allocate(self,views):
        if not self.config['food_triage']:
            return super().allocate(views)
        self.shared_frames(views)
        young=sum(v['state']['age']<60 for v in views.values())
        candidates=[]
        for aid,view in views.items():
            s,mem=view['state'],view['mem']
            if s['age']>self.config['triage_age'] and s['energy']>self.config['triage_reserve'] and young>=2:
                view['resting']=True;view['eligible']=False
            visible={self.canonical(f['key']):f for f in view['fruits']}
            view['visible']=visible
            previous=self.canonical(mem.target_id) if mem.target_id is not None else None
            mem.target_id=None
            if view['escaping'] or not view.get('eligible',True):continue
            urgency=max(.4,min(2.,s['energy']/120.))*(1.+max(0.,s['age']-60.)/60.)
            for key,f in visible.items():
                cost=(f['obs']['distance']+10.)*urgency
                if key==previous:cost*=.7
                candidates.append((cost,aid,key))
        used=set();assigned=set()
        for cost,aid,key in sorted(candidates):
            if aid not in assigned and key not in used:
                views[aid]['mem'].target_id=key;assigned.add(aid);used.add(key)

    def steer(self,view):
        action=super().steer(view)
        if view['predators'] and min(e['obs']['distance'] for e in view['predators'])<100.:
            action.spawn_agent=False
        return action
