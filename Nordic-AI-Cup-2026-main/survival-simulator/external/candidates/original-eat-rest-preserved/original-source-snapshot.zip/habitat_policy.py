"""Inherit productive habitat waypoints through observed teammates."""
import math
from mpc_policy import PredictiveForager
from species_field_trial import point,rotate,wrap
from src.utils.controllers.potential_field_policy import closest_point

QUALITY={'forest':1.,'grassland':.7,'swamp':.35,'desert':.1,'river':0.}

class HabitatPolicy(PredictiveForager):
    def __init__(self,preset='habitat',**overrides):
        config=dict(boundary_bias=True,search_reorient=8.,population=8,population_floor=3,
                    habitat_pull=250.,idle_energy=.65,food_weight=.6)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state)
        mem=view['mem']
        for name in ('home','center'):
            p=getattr(mem,name,None)
            if p is not None:
                q=rotate(p,-mem.last_turn)
                setattr(mem,name,(q[0]-view['translation'][0],q[1]-view['translation'][1]))
        quality=QUALITY.get(state['biome'],.4)
        if quality>getattr(mem,'home_quality',-1.):
            mem.home=(0.,0.);mem.home_quality=quality;mem.home_since=self.clock
        elif quality==getattr(mem,'home_quality',-1.) and quality>=.7:
            mem.home=(mem.home[0]*.995,mem.home[1]*.995)
        for edge in view['edges']:
            length=math.hypot(edge[1][0]-edge[0][0],edge[1][1]-edge[0][1])
            if abs(length-1600.)<1. or abs(length-1200.)<1.:
                p=closest_point(edge);d=math.hypot(*p)
                if d<1e-6:continue
                normal=(-p[0]/d,-p[1]/d)
                # The boundary's inner face is 30 units from the world edge.
                perpendicular=570. if abs(length-1600.)<1. else 770.
                midpoint=((edge[0][0]+edge[1][0])/2.,(edge[0][1]+edge[1][1])/2.)
                mem.center=(midpoint[0]+normal[0]*perpendicular,midpoint[1]+normal[1]*perpendicular)
        return view

    def allocate(self,views):
        # Waypoints are transformed using only observed teammate bearings and
        # headings; children retain the habitat knowledge of their neighbors.
        for _ in range(2):
            for aid,view in views.items():
                mem=view['mem']
                for obs in view['agents']:
                    if obs.get('id') not in views:continue
                    other=views[obs['id']]['mem']
                    better=(other.home_quality>mem.home_quality or
                            (other.home_quality==mem.home_quality and other.home_since<mem.home_since))
                    angle=wrap(obs['angle']+math.pi-obs['rel_dir'])
                    offset=point(obs)
                    if better:
                        q=rotate(other.home,angle)
                        mem.home=(offset[0]+q[0],offset[1]+q[1])
                        mem.home_quality=other.home_quality;mem.home_since=other.home_since
                        self.metrics['habitat_transfers']+=1
                    if getattr(mem,'center',None) is None and getattr(other,'center',None) is not None:
                        q=rotate(other.center,angle)
                        mem.center=(offset[0]+q[0],offset[1]+q[1])
        super().allocate(views)

    def steer(self,view):
        s,mem=view['state'],view['mem']
        if mem.target_id is None and not view.get('resting'):
            quality=QUALITY.get(s['biome'],.4)
            desired=None
            if mem.home_quality>quality+.1 and math.hypot(*mem.home)>35.:
                desired=mem.home
            elif quality>=.7 and math.hypot(*mem.home)>self.config['habitat_pull']:
                desired=mem.home
            elif getattr(mem,'center',None) is not None:
                near_boundary=any(math.hypot(e[1][0]-e[0][0],e[1][1]-e[0][1])>800. and math.hypot(*closest_point(e))<140. for e in view['edges'])
                if near_boundary:desired=mem.center
            if desired is not None:
                mem.search_heading=wrap(mem.heading+math.atan2(desired[1],desired[0]))
                mem.next_reorient=self.clock+2.
                self.metrics['habitat_return_ticks']+=1
        return super().steer(view)
