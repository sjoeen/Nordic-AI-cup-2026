import argparse
from research_runner import run

CONFIGS=[
 ('guard',dict(label='guard')),
 ('direct',dict(label='small_population',population=6,population_floor=3,birth_energy=200.)),
 ('direct',dict(label='selective',selective_breeding=250.)),
 ('roamer',dict(label='slow_roamer',search_speed=.25,population=8,birth_energy=250.)),
 ('direct',dict(label='constant_population',population=12,population_floor=12)),
 ('guard',dict(label='selective_guard',selective_breeding=250.,population=10,population_floor=4)),
]

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True);a=p.parse_args()
 for preset,config in CONFIGS:
  run(a.seed,preset,config,log=f'research_grid_{a.seed}.jsonl')
