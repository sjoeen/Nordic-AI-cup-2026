import sys
from campaign_runner import run
CASES=[
 ('late_birth140',{'birth_energy':140.}),
 ('late_reserve180',{'hard_idle_energy':180.}),
 ('late_floor4',{'population_floor':4}),
 ('late_renewal',{'young_age':45.,'renewal_age':60.,'retirement':90.}),
 ('late_fast_search',{'search_speed':.7,'scan':.35}),
 ('late_no_dispersal',{'dispersal_distance':0.,'dispersal_time':0.}),
 ('late_ripen',{'ripen_seconds':10.}),
 ('late_tight_danger',{'escape_radius':70.,'rest_radius':30.}),
]
if __name__=='__main__':
    for label,settings in CASES:run(int(sys.argv[1]),'phase2_policy:PhasePolicy',{'late_settings':settings},label)
