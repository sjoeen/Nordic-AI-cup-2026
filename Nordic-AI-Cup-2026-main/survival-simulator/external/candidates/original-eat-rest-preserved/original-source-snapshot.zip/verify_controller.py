"""Focused steering checks and a real HTTP round trip through the simulator."""
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

from src.utils.DTOs import ActionRequest
from src.utils.controllers.potential_field_policy import PotentialFieldPolicy


def observation(**changes):
    base = dict(agent_id=0, energy=150., biome="forest", age=1., speed=10.,
                sprint_speed=20., hearing_radius=50., vision_angle=math.pi / 3,
                vision_range=200., max_energy=500., observations=[])
    base.update(changes)
    return base


class SteeringChecks(unittest.TestCase):
    def setUp(self):
        self.policy = PotentialFieldPolicy()

    def test_food_to_left_uses_relative_movement(self):
        action = self.policy.decide(observation(observations=[dict(type="Fruit", distance=50., angle=math.pi / 2)]))
        self.assertGreater(action.move_direction, 1.3)
        self.assertLessEqual(action.turn_angle, .4)

    def test_close_predator_overrides_food(self):
        obs = [dict(type="Fruit", distance=50., angle=0.) for _ in range(50)]
        obs.append(dict(type="Predator", distance=35., angle=0., rel_dir=0.))
        action = self.policy.decide(observation(observations=obs))
        self.assertLess(math.cos(action.move_direction), -.9)
        self.assertEqual(action.move_distance, 20.)
        self.assertFalse(action.spawn_agent)

    def test_duplicate_wall_rays_do_not_change_force(self):
        edge = dict(type="Edge", coords=((15., -20.), (15., 20.)))
        one = self.policy.decide(observation(observations=[edge]))
        many = self.policy.decide(observation(observations=[edge] * 20))
        self.assertEqual(one, many)
        self.assertLess(math.cos(one.move_direction), 0.)

    def test_mutated_speed_and_low_energy(self):
        action = self.policy.decide(observation(speed=20., sprint_speed=8., energy=30.,
                                               observations=[dict(type="Predator", distance=30., angle=0.)]))
        self.assertLessEqual(action.move_distance, 8.)
        self.assertFalse(action.spawn_agent)

    def test_exact_facing_target_in_simulator(self):
        # Confirm move_direction refers to the heading before turn_angle.
        from src.elements.environment import Environment
        from src.elements.agent import Agent
        from src.elements.biome import Forest_biome
        from types import SimpleNamespace
        import numpy as np
        import random
        agent = Agent(100., 100., rng=random.Random(0))
        agent.direction = math.pi / 2
        env = SimpleNamespace(biome_map=np.full((300, 300), Forest_biome(), dtype=object),
                              width=300, height=300,
                              update_entity_energy=lambda a, cost: None,
                              _in_obstacle=lambda *a, **k: False,
                              _keep_agent_in_bounds=lambda a: None)
        Environment.update_entity_position(env, agent, 10., math.pi / 2, [])
        self.assertAlmostEqual(agent.x, 90.)
        self.assertAlmostEqual(agent.y, 100.)


def http_check():
    import requests
    from src.core import SimulationCore
    log_path = Path("http_server.log")
    with log_path.open("w") as log:
        server = subprocess.Popen([sys.executable, "-m", "uvicorn", "potential_field_server:app",
                                   "--host", "127.0.0.1", "--port", "9052", "--no-access-log"],
                                  stdout=log, stderr=log)
        try:
            for _ in range(100):
                try:
                    requests.get("http://127.0.0.1:9052/", timeout=.5).raise_for_status()
                    break
                except requests.RequestException:
                    if server.poll() is not None:
                        raise RuntimeError(log_path.read_text())
                    time.sleep(.1)
            else:
                raise RuntimeError("Agent endpoint did not start")
            sim = SimulationCore(seed=123)
            actions = []
            times = []
            for _ in range(100):
                state = sim.step(actions)
                start = time.perf_counter()
                response = requests.post("http://127.0.0.1:9052/predict", timeout=10,
                                         json=dict(game_status="ok", score=state["score"],
                                                   sim_time=state["sim_time"], n_agents=state["num_agents"],
                                                   agent_status=state["observations"]))
                response.raise_for_status()
                decoded = [ActionRequest(**a) for a in response.json()["actions"]]
                assert sorted(a.agent_id for a in decoded) == sorted(o["agent_id"] for o in state["observations"])
                times.append(time.perf_counter() - start)
                actions = [(a.agent_id, a) for a in decoded]
            # Stateless controller should accept consecutive games without reset.
            for _ in range(3):
                response = requests.post("http://127.0.0.1:9052/predict", timeout=10,
                                         json=dict(game_status="ok", score=0, sim_time=0,
                                                   n_agents=0, agent_status=[]))
                response.raise_for_status()
                assert response.json() == {"actions": []}
            result = dict(requests=103, simulation_ticks=100, alive=state["num_agents"],
                          mean_response_ms=sum(times) * 1000 / len(times),
                          max_response_ms=max(times) * 1000)
            Path("http_verification.json").write_text(json.dumps(result, indent=2) + "\n")
            print("HTTP verification:", json.dumps(result))
        finally:
            server.terminate()
            try:
                server.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait()


if __name__ == "__main__":
    tests = unittest.defaultTestLoader.loadTestsFromTestCase(SteeringChecks)
    result = unittest.TextTestRunner(verbosity=2).run(tests)
    if not result.wasSuccessful():
        raise SystemExit(1)
    http_check()
