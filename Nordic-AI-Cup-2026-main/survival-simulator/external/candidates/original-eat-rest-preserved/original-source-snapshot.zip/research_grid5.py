import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('camp',{'label':'tree_camp'}),
 ('refuge',{'label':'obstacle_refuge'}),
 ('gaze',{'label':'gaze_fixed'}),
 ('lineage',{'label':'lineage_farmer_repeat','fresh_ripen':18.,'ripen_age_limit':45.,'patch_wait':10.}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid5_{seed}.jsonl')
