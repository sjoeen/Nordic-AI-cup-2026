"""Couple feeding and birth thresholds to the real sprint-energy requirement."""
import math
from generation_policy import GenerationPolicy
from dispersal_policy import DispersalPolicy


class ReservePolicy(GenerationPolicy):
    def __init__(self, preset='reserve', **overrides):
        config = dict(maximum_birth_gap=20., energy_margin=25., feeding_margin=50.,
                      trait_start=0., emergency_birth=False, reserve_hysteresis=0.)
        config.update(overrides)
        super().__init__(preset, **config)

    def decide_all(self, states, sim_time=None):
        now = float(sim_time) if sim_time is not None else self.clock+.1
        self.config['emergency_birth'] = now < self.config['trait_start']
        return super().decide_all(states, sim_time)

    def allocate(self, views):
        c = self.config
        if self.clock < c['trait_start']:
            return super().allocate(views)
        cap = max(c['population_floor'], round(c['population']*.5**(self.clock/c['population_decay'])))
        young = sum(v['state']['age'] < c['young_age'] for v in views.values())
        budget = max(0, cap-young)
        youngest = min((v['state']['age'] for v in views.values() if v['state']['energy'] > 40.), default=1000.)
        if c['maximum_birth_gap'] and len(views) < 2*cap and youngest > c['maximum_birth_gap']:
            budget = max(budget, 1)
        candidates = []
        for aid, v in views.items():
            s = v['state']
            reserve = .2*s['max_energy']+c['energy_margin']
            threshold = 100.+reserve
            # An old final lineage still needs a replacement if the full
            # reserve has become unattainable.
            if youngest > 75. or (len(views) < 3 and s['age'] > 60.):
                threshold = min(threshold, 140.)
                budget = max(budget, 1)
            if v['escaping'] or (v['predators'] and min(p['obs']['distance'] for p in v['predators']) < 130.):
                continue
            if s['energy'] <= threshold or aid in self.retired_ids:
                continue
            quality = min(s['speed'],s['sprint_speed'])+.015*s['hearing_radius']+.003*s['vision_range']
            candidates.append((quality, s['energy'], -aid, aid))
        self.spawn_ids = {row[-1] for row in sorted(candidates, reverse=True)[:budget]}
        for aid, v in views.items():
            s, m = v['state'], v['mem']
            target = min(.92*s['max_energy'], max(250., 100.+.2*s['max_energy']+c['energy_margin']+c['feeding_margin']))
            rest = s['energy'] >= target and aid not in self.spawn_ids
            if c['reserve_hysteresis'] and getattr(m, 'reserve_resting', False):
                rest = s['energy'] >= target-c['reserve_hysteresis'] and aid not in self.spawn_ids
            m.reserve_resting = rest
            v['resting'] = aid in self.retired_ids or rest
            v['eligible'] = not v['resting']
        DispersalPolicy.allocate(self, views)
