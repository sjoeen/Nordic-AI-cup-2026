"""Full-size second campaign. Diagnostics never enter policy observations."""
import argparse
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
import gzip
import hashlib
import importlib
import inspect
import json
import math
import os
from pathlib import Path
import statistics
import time
import zipfile

os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')
from src.core import SimulationCore
from src.elements.environment import Environment
from hierarchical_field_trial import initial_hash
from species_field_trial import rotate

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'campaign'


def policy_factory(name, config):
    module, cls = name.split(':')
    return getattr(importlib.import_module(module), cls)(**config)


def snapshot_sources(label):
    OUT.mkdir(exist_ok=True)
    source = [(p.relative_to(ROOT).as_posix(), p.read_bytes())
              for p in sorted(ROOT.glob('*.py'))]
    source += [(p.relative_to(ROOT).as_posix(), p.read_bytes())
               for p in sorted((ROOT / 'src').rglob('*.py'))]
    digest = hashlib.sha256(b''.join(n.encode()+b for n,b in source)).hexdigest()
    dest = OUT / f'source_{digest[:16]}.zip'
    if not dest.exists():
        with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as z:
            for n,b in source:z.writestr(n,b)
    return digest


def run(seed, name, config, label, diagnostic=False, parity=None, limit=3000.):
    started = time.perf_counter()
    source_hash = snapshot_sources(label)
    policy = policy_factory(name, config)
    mirror = None
    if parity:
        import importlib.util
        import sys
        spec = importlib.util.spec_from_file_location('_campaign_candidate', parity)
        module = importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
        spec.loader.exec_module(module);mirror=module.make_policy()
    views = {}
    old_steer = policy.steer
    def record_steer(view):
        action = old_steer(view)
        views[view['state']['agent_id']] = view
        return action
    if diagnostic:policy.steer = record_steer
    sim = SimulationCore(seed=seed)
    digest = initial_hash(sim)
    reference=json.loads((ROOT/'benchmark_results.json').read_text())
    expected=[r for r in reference if r['seed']==seed]
    if expected:assert digest==expected[0]['initial_state_sha256']
    log = OUT / f'{label}_s{seed}.jsonl'
    diag = gzip.open(OUT/f'{label}_s{seed}_diagnostic.jsonl.gz','wt') if diagnostic else None
    ages = {}; paths=defaultdict(lambda:deque(maxlen=100)); frames=defaultdict(lambda:deque(maxlen=40))
    deaths=[]; eaten=[]; rotten=[]; birth_survival=[]; trace=[]
    old_kill=sim.env.kill_agent
    def record_kill(a):
        mem=policy.memory.get(a.agent_id)
        nearest=min((math.hypot(f.x-a.x,f.y-a.y) for f in sim.env.fruits),default=None)
        record=dict(id=a.agent_id,time=round(sim.env.time,1),age=round(a.age,1),energy=round(a.energy,2),
                    mode=getattr(mem,'last_mode',None),nearest_food=nearest,
                    speed=a.speed,sprint_speed=a.sprint_speed,vision=a.vision_radius,capacity=a.max_energy)
        deaths.append(record)
        if diag:diag.write(json.dumps(dict(event='death',**record,frames=list(frames[a.agent_id])))+'\n')
        old_kill(a)
    sim.env.kill_agent=record_kill
    lines,start=inspect.getsourcelines(Environment.non_agent_step)
    eaten_line=next(start+i for i,line in enumerate(lines) if 'self.remove_fruit(fruit) # Remove fruit' in line)
    old_remove=sim.env.remove_fruit
    def record_remove(fruit):
        (eaten if inspect.currentframe().f_back.f_lineno==eaten_line else rotten).append(float(fruit.energy))
        old_remove(fruit)
    sim.env.remove_fruit=record_remove
    def emit(r):
        r['label']=label;r['seed']=seed
        text=json.dumps(r)
        print(text,flush=True)
        with log.open('a') as f:f.write(text+'\n');f.flush();os.fsync(f.fileno())
    emit(dict(event='start',policy=name,config=config,source_sha256=source_hash,
              initial_state_sha256=digest,utc=datetime.now(timezone.utc).isoformat(),limit=limit,diagnostic=diagnostic))
    actions=[];controller_time=0.;latencies=[];peak=5;stats=Counter();interval=Counter()
    for tick in range(round(limit/.1)):
        state=sim.step(actions)
        peak=max(peak,state['num_agents'])
        if not state['num_agents']:break
        t=time.perf_counter()
        decoded=policy.decide_all(state['observations'],state['sim_time'])
        elapsed=time.perf_counter()-t
        controller_time+=elapsed;latencies.append(elapsed)
        if mirror is not None:
            exported=mirror.decide_all(state['observations'],state['sim_time'])
            assert [a.model_dump() for a in decoded]==[a.model_dump() for a in exported],('parity',seed,tick)
        actions=[(a.agent_id,a) for a in decoded]
        if diagnostic:
            byid={a.agent_id:a for a in decoded}
            for a,s in zip(sim.env.agents,state['observations']):
                aid=a.agent_id;view=views.get(aid);mem=policy.memory.get(aid)
                if view is None:continue
                paths[aid].append((a.x,a.y))
                target=view.get('visible',{}).get(mem.target_id)
                delta=view.get('translation',(0.,0.))
                stats['observations']+=1
                if len(paths[aid])>1:
                    old=paths[aid][-2]
                    actual=rotate((a.x-old[0],a.y-old[1]),-a.direction)
                    error=math.hypot(actual[0]-delta[0],actual[1]-delta[1])
                    stats['odometry_error_sum']+=error
                    stats['odometry_bad_ticks']+=error>2.
                if tick%10:continue
                nearest=min(sim.env.fruits,key=lambda f:math.hypot(f.x-a.x,f.y-a.y),default=None)
                frame=dict(time=round(sim.env.time,1),age=round(a.age,1),energy=round(a.energy,2),
                           x=round(a.x,2),y=round(a.y,2),mode=getattr(mem,'last_mode',None),biome=s['biome'],
                           move=round(byid[aid].move_distance,2),turn=round(byid[aid].turn_angle,3),
                           fruit_observed=sum(o['type']=='Fruit' for o in s['observations']),
                           tree_observed=sum(o['type']=='Tree' for o in s['observations']),
                           predator_observed=sum(o['type']=='Predator' for o in s['observations']),
                           nearest_food=round(math.hypot(nearest.x-a.x,nearest.y-a.y),2) if nearest else None)
                if target is not None:
                    q=rotate(target['p'],a.direction);px,py=a.x+q[0],a.y+q[1]
                    error=min((math.hypot(f.x-px,f.y-py) for f in sim.env.fruits),default=9999.)
                    frame.update(target_distance=round(math.hypot(*target['p']),2),target_error=round(error,2),
                                 target_shared=target.get('shared',False),target_remembered=target.get('remembered',False),
                                 target_x=round(px,2),target_y=round(py,2))
                    stats['target_samples']+=1;stats['target_inaccurate_samples']+=error>5.
                frames[aid].append(frame)
                if diag and tick%100==0:diag.write(json.dumps(dict(event='sample',id=aid,**frame))+'\n')
            if tick%100==0:
                live={a.agent_id for a in sim.env.agents}
                paths={k:v for k,v in paths.items() if k in live}
                paths=defaultdict(lambda:deque(maxlen=100),paths)
                frames=defaultdict(lambda:deque(maxlen=40),{k:v for k,v in frames.items() if k in live})
        if (tick+1)%2000==0:
            p=dict(event='progress',time=round(sim.env.time,1),alive=state['num_agents'],
                   energy=round(sum(a.energy for a in sim.env.agents),1),food=len(sim.env.fruits),trees=len(sim.env.trees),
                   predators=len(sim.env.predators),score=round(state['score'],2),
                   biomes=dict(Counter(s['biome'] for s in state['observations'])))
            trace.append(p);emit(p)
    latencies.sort()
    result=dict(event='result',policy=name,config=config,survival_seconds=round(state['sim_time'],1),
                completed=bool(state['num_agents'] and tick+1==round(limit/.1)),limit=limit,alive=state['num_agents'],
                score=state['score'],peak_agents=peak,agents_born=sim.env._next_agent_id,
                energy_deaths=sum(d['energy']<=0 for d in deaths),predator_deaths=sum(d['energy']>0 for d in deaths),
                young_energy_deaths=sum(d['energy']<=0 and d['age']<30 for d in deaths),
                young_deaths=sum(d['age']<30 for d in deaths),fruits_eaten=len(eaten),
                mean_fruit_energy=statistics.mean(eaten) if eaten else 0.,fruits_rotted=len(rotten),
                metrics=dict(policy.metrics),diagnostics=dict(stats),last_deaths=deaths[-12:],trace=trace,
                controller_seconds=controller_time,controller_mean_ms=1000*controller_time/max(1,len(latencies)),
                controller_p99_ms=1000*latencies[min(len(latencies)-1,int(.99*len(latencies)))] if latencies else 0.,
                wall_seconds=time.perf_counter()-started,source_sha256=source_hash,
                initial_state_sha256=digest,standalone_parity_checked=mirror is not None)
    if diag:diag.close()
    emit(result)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--policy',default='dispersal_policy:DispersalPolicy')
    p.add_argument('--config',default='{"dispersal_distance":100.0}')
    p.add_argument('--label',required=True)
    p.add_argument('--seeds',type=int,nargs='+',default=[1,2,3])
    p.add_argument('--diagnostic',action='store_true')
    p.add_argument('--parity')
    p.add_argument('--limit',type=float,default=3000.)
    a=p.parse_args()
    for seed in a.seeds:run(seed,a.policy,json.loads(a.config),a.label,a.diagnostic,a.parity,a.limit)
