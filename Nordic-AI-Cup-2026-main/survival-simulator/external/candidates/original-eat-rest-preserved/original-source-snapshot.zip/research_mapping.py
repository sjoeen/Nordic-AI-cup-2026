import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('mapped_colony',{'label':'local_map_colony'}),
 ('mapped_colony',{'label':'persistent_map_colony','persistent_sharing':True}),
 ('learning_colony',{'label':'learning_colony'}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_mapping_{seed}.jsonl')
