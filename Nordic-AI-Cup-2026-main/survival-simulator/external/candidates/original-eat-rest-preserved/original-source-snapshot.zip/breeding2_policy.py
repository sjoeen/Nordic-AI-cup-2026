"""Controlled trait selection and energy-aware generational turnover."""
import math
from dispersal_policy import DispersalPolicy


class BreedingPolicy(DispersalPolicy):
    def __init__(self,preset='breeding2',**overrides):
        config=dict(dispersal_distance=100.,fitness='baseline',elite_fraction=0.,
                    local_birth=False,retire_weak=False,local_radius=180.,brood_margin=0.)
        config.update(overrides);super().__init__(preset,**config)

    def fitness(self,s):
        mode=self.config['fitness']
        walk=max(.1,min(s['speed'],s['sprint_speed']))
        vision=max(1.,s['vision_range']);hearing=max(1.,s['hearing_radius']);cone=max(.02,s['vision_angle'])
        fertility=min(1.,max(.01,(s['max_energy']-100.)/100.))
        if mode=='vision':return min(walk,16.)**.5*math.sqrt(vision*vision*cone+math.pi*hearing*hearing)*fertility
        if mode=='hearing':return min(walk,16.)**.5*hearing**1.5*vision**.25*fertility
        if mode=='balanced':return min(walk,16.)*vision**.8*hearing**.4*cone**.3*fertility
        if mode=='sprint':return min(walk,16.)**.5*min(s['sprint_speed'],22.)**.3*vision*cone**.4*fertility
        return walk+.015*hearing+.003*vision

    def decide_all(self,states,sim_time=None):
        if any(s['agent_id'] in self.memory and s['age']<self.memory[s['agent_id']].last_age for s in states):
            self.memory.clear();self.parents.clear();self.first_seen.clear();self.birth_times.clear();self.clock=0.
        self.clock=float(sim_time) if sim_time is not None else self.clock+.1
        live={s['agent_id'] for s in states}
        self.memory={k:v for k,v in self.memory.items() if k in live}
        views={s['agent_id']:self.observe(s) for s in sorted(states,key=lambda s:s['agent_id'])}
        c=self.config
        cap=max(c['population_floor'],round(c['population']*.5**(self.clock/c['population_decay'])))
        values={s['agent_id']:self.fitness(s) for s in states};best=max(values.values(),default=1.)
        young=sum(s['age']<c['young_age'] and values[s['agent_id']]>=c['elite_fraction']*best for s in states)
        self.retired_ids={s['agent_id'] for s in states if s['age']>c['retirement'] and young>=max(2,cap//2)}
        if c['retire_weak'] and young>=3:
            self.retired_ids.update(s['agent_id'] for s in states if s['age']>20. and values[s['agent_id']]<c['elite_fraction']*best)
        candidates=[]
        for aid,v in views.items():
            s=v['state'];threshold=max(c['birth_floor'],min(c['birth_energy'],.75*s['max_energy']))
            if s['age']>60. and young<max(2,cap//2):threshold=min(threshold,160.)
            if c['brood_margin'] and values[aid]<best*.9:threshold+=c['brood_margin']*(1.-values[aid]/best)
            safe=not v['predators'] or min(p['obs']['distance'] for p in v['predators'])>130.
            safe=safe and self.clock-getattr(v['mem'],'enemy_seen',-10000.)>=c['threat_cooldown']
            if c['local_birth']:
                crowd=sum(o['distance']<c['local_radius'] for o in v['agents'])
                safe=safe and (crowd<2 or s['age']>75.)
            if s['energy']>threshold and safe and aid not in self.retired_ids:
                candidates.append((values[aid],s['energy'],-aid,aid))
        self.spawn_ids={x[-1] for x in sorted(candidates,reverse=True)[:max(0,cap-young)]}
        for aid,v in views.items():
            s=v['state']
            v['resting']=aid in self.retired_ids or (s['energy']>min(c['hard_idle_energy'],c['idle_energy']*s['max_energy']) and aid not in self.spawn_ids)
            v['eligible']=not v['resting']
        self.allocate(views)
        actions=[self.steer(views[s['agent_id']]) for s in states]
        # Match the existing emergency renewal behavior so the fitness test is isolated.
        if c['emergency_birth']:
            young=sum(s['age']<c['renewal_age'] for s in states);byid={s['agent_id']:s for s in states}
            for a in actions:
                s=byid[a.agent_id]
                if a.spawn_agent:continue
                enemies=[o['distance'] for o in s['observations'] if o['type']=='Predator']
                safe=not enemies or min(enemies)>c['emergency_birth_distance']
                cost=.05*min(a.move_distance,s['speed'])+.5*max(0.,a.move_distance-s['speed'])+abs(a.turn_angle)/(2*math.pi)
                if safe and s['energy']>112.+cost and (len(states)<3 or (s['age']>c['renewal_age'] and young<max(2,c['population_floor']))):
                    a.spawn_agent=True;young+=1;self.metrics['emergency_births']+=1
        return actions
