"""Observation-only newborn dispersal and persistent rest experiments."""
import math
from dispersal_policy import DispersalPolicy
from species_field_trial import wrap,unit


class ColonyPolicy(DispersalPolicy):
    def __init__(self,preset='colony2',**overrides):
        config=dict(dispersal_distance=100.,local_colonization=False,late_colonization=False,
                    outward_colonization=False,rest_hysteresis=0.,rest_release_food=0.,
                    colonization_population=5,colonization_radius=120.,colonization_min_neighbors=2)
        config.update(overrides);super().__init__(preset,**config)

    def decide_all(self,states,sim_time=None):
        self.colony_size=len(states)
        return super().decide_all(states,sim_time)

    def observe(self,state):
        view=super().observe(state);mem=view['mem'];c=self.config
        if mem.colonist and not getattr(mem,'colony_checked',False):
            mem.colony_checked=True
            neighbors=[o for o in view['agents'] if o['distance']<c['colonization_radius']]
            if c['local_colonization'] and len(neighbors)<c['colonization_min_neighbors']:
                mem.colonist=False
            if c['late_colonization'] and self.colony_size<c['colonization_population']:
                mem.colonist=False
            if c['outward_colonization'] and neighbors:
                x=y=0.
                for o in neighbors:
                    d=max(10.,o['distance']);x-=math.cos(o['angle'])/d;y-=math.sin(o['angle'])/d
                mem.migration_heading=wrap(mem.heading+math.atan2(y,x))
        return view

    def allocate(self,views):
        c=self.config
        if c['rest_hysteresis']:
            for aid,v in views.items():
                s,mem=v['state'],v['mem']
                if getattr(mem,'resting_latched',False):
                    near=c['rest_release_food'] and any(f['obs']['distance']<c['rest_release_food'] for f in v['fruits'])
                    if s['energy']<c['rest_hysteresis'] or aid in self.spawn_ids or near:
                        mem.resting_latched=False
                    elif aid not in self.retired_ids:
                        v['resting']=True;v['eligible']=False
                if v.get('resting') and aid not in self.retired_ids:mem.resting_latched=True
        super().allocate(views)
