import sys
from campaign_runner import run
from campaign_dev2 import CASES as DEV2
from campaign_guard import CASES as GUARD
from campaign_phase2 import CASES as PHASE
from campaign_allocation2 import CASES as ALLOCATION

seed=int(sys.argv[1])
for label,policy,config in DEV2:run(seed+3,policy,config,label)
for label,config in GUARD:run(seed,'guard_colony:GuardColony',config,label)
for label,settings in PHASE:run(seed,'phase2_policy:PhasePolicy',{'late_settings':settings},label)
for label,config in ALLOCATION:run(seed,'allocation2_policy:AllocationPolicy',config,label)
run(seed,'dispersal_policy:DispersalPolicy',{'dispersal_distance':100.,'boundary_bias':True},'boundary_interior')
