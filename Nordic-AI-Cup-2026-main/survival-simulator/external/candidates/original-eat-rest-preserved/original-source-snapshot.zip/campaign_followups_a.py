import sys
from campaign_runner import run
from campaign_growth import CASES as GROWTH
from campaign_precision import CASES as PRECISION
from campaign_sensors import CASES as SENSORS
from campaign_merit import CASES as MERIT

seed=int(sys.argv[1])
for cases,policy in [(GROWTH,'growth_policy:GrowthPolicy'),(PRECISION,'precision_food:PrecisionFood'),
                     (SENSORS,'sensor_search:SensorSearch'),(MERIT,'merit_policy:MeritPolicy')]:
    for label,config in cases:run(seed,policy,config,label)
