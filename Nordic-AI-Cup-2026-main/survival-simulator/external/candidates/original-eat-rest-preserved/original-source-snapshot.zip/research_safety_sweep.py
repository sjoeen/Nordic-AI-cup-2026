import sys
from research_runner import run
seed=int(sys.argv[1])
variants=[
 ('short_horizon',{'filter_horizon':1,'filter_margin':25.}),
 ('longer_horizon',{'filter_horizon':3,'filter_margin':25.}),
 ('tight_clearance',{'filter_margin':20.}),
 ('wide_clearance',{'filter_margin':35.}),
 ('food_value',{'filter_food':1.5}),
 ('limited_reserves',{'hard_idle_energy':250.,'birth_energy':180.}),
 ('uncertain_rest',{'rest_certainty':False}),
 ('vision_model',{'respect_enemy_vision':True,'concealment_bonus':10.}),
 ('threat_memory',{'threat_memory':.5}),
 ('more_lineages',{'population':10,'population_floor':3}),
 ('fast_exploration',{'search_speed':1.}),
 ('patch_exploration',{'search_speed':.25,'patch_wait':15.}),
]
for label,config in variants:
 config={'enemy_speed':'maximum','filter_horizon':2,**config,'label':'sweep_'+label}
 run(seed,'safety',config,log=f'research_safety_sweep_{seed}.jsonl')
