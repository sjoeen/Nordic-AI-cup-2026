"""Serve the tested controller with the competition's existing JSON contract."""
from fastapi import Body, FastAPI
from src.utils.DTOs import StepResponse
from src.utils.controllers.potential_field_policy import PotentialFieldPolicy

app = FastAPI(title="Potential Field Survival Agent")
policy = PotentialFieldPolicy()


@app.post("/predict")
def predict(step: StepResponse = Body(...)):
    return {"actions": [policy.decide(agent.model_dump()).model_dump()
                        for agent in step.agent_status]}


@app.get("/")
def index():
    return {"message": "Potential field agent running"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9052)
