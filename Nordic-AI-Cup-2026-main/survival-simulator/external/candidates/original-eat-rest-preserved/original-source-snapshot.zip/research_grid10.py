import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('safety',{'label':'collision_rollout','collision_model':True,'enemy_speed':'maximum','filter_horizon':2,'stale_correction':True}),
 ('refuge_memory',{'label':'refuge_memory'}),
 ('refuge_path',{'label':'refuge_path'}),
 ('refuge',{'label':'refuge_repeat'}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid10_{seed}.jsonl')
