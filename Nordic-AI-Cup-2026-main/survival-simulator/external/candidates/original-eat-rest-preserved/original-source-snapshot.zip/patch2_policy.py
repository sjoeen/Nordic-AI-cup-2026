"""Tree residence on the established controller, with explicit giving-up time."""
import math
from dispersal_policy import DispersalPolicy
from species_field_trial import rotate,wrap,unit,point
from nursery_policy import segment_clear


class PatchPolicy(DispersalPolicy):
    def __init__(self,preset='patch2',**overrides):
        config=dict(dispersal_distance=100.,tree_range=180.,tree_hold=12.,tree_stop=25.,
                    tree_memory=6.,tree_crowding=2,tree_age_limit=85.,tree_cooldown=15.,
                    child_settle=False,patch_recover=False)
        config.update(overrides);super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem'];s=view['state'];c=self.config
        current=[point(o) for o in s['observations'] if o['type']=='Tree']
        sites={};used=set()
        for key,item in getattr(mem,'patch_sites',{}).items():
            q=rotate(item['p'],-mem.last_turn);p=(q[0]-view['translation'][0],q[1]-view['translation'][1])
            match=min(range(len(current)),key=lambda i:math.hypot(current[i][0]-p[0],current[i][1]-p[1]),default=None)
            if match is not None and match not in used and math.hypot(current[match][0]-p[0],current[match][1]-p[1])<3.:
                sites[key]={**item,'p':current[match],'seen':self.clock};used.add(match);continue
            d=math.hypot(*p);theta=math.atan2(p[1],p[0])
            visible=(d<s['hearing_radius']-2. or (d<s['vision_range']-5. and abs(theta)<s['vision_angle']/2.-.04 and segment_clear((0.,0.),p,view['edges'],0.)))
            if not visible and self.clock-item['seen']<c['tree_memory']:
                sites[key]={**item,'p':p}
        for i,p in enumerate(current):
            if i in used:continue
            mem.patch_seq=getattr(mem,'patch_seq',0)+1
            sites[mem.patch_seq]=dict(p=p,seen=self.clock,first=self.clock,blocked_until=-1.)
        mem.patch_sites=sites
        old=getattr(mem,'patch_energy',s['energy']);cost=getattr(mem,'patch_cost',0.)
        if s['energy']-old+cost>5.:
            mem.patch_meal=self.clock
            key=getattr(mem,'patch_id',None)
            if key in sites:mem.patch_until=self.clock+c['tree_hold']
        mem.patch_energy=s['energy']
        if c['child_settle'] and mem.colonist and sites:
            if min(math.hypot(*v['p']) for v in sites.values())<80.:mem.colonist=False
        return view

    def steer(self,view):
        action=super().steer(view);s,mem,c=view['state'],view['mem'],self.config
        if view['escaping'] or view.get('resting') or mem.target_id is not None or mem.colonist:return action
        if s['age']>c['tree_age_limit']:return action
        if self.clock<getattr(mem,'patch_leave_until',-1.):return action
        current=getattr(mem,'patch_id',None)
        site=mem.patch_sites.get(current)
        if site is not None and self.clock>=getattr(mem,'patch_until',0.):
            site['blocked_until']=self.clock+c['tree_cooldown'];mem.patch_id=None;site=None
            mem.patch_leave_until=self.clock+2.
            self.metrics['patch_departures']+=1
            return action
        if site is None:
            choices=[]
            for key,item in mem.patch_sites.items():
                p=item['p'];distance=math.hypot(*p)
                if distance>c['tree_range'] or self.clock<item['blocked_until']:continue
                crowd=sum(math.hypot(point(o)[0]-p[0],point(o)[1]-p[1])<75. for o in view['agents'])
                if crowd>=c['tree_crowding']:continue
                danger=sum(max(0.,140.-math.hypot(e['p'][0]-p[0],e['p'][1]-p[1])) for e in view['predators'])
                if danger>60.:continue
                if not segment_clear((0.,0.),p,view['edges'],5.):continue
                score=distance+40.*crowd+2.*danger
                choices.append((score,key,item))
            if not choices:return action
            _,key,site=min(choices,key=lambda x:x[0]);mem.patch_id=key
            terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
            travel=max(0.,math.hypot(*site['p'])-c['tree_stop'])/max(1.,min(s['speed'],s['sprint_speed'])*terrain)*.1
            mem.patch_until=self.clock+c['tree_hold']+travel
        p=site['p'];distance=math.hypot(*p)
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        speed=min(s['speed'],s['sprint_speed'],max(0.,distance-c['tree_stop'])/terrain)
        direction,_=self.slide(unit(p),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=c['scan'] if distance<max(c['tree_stop']+2.,s['hearing_radius']) else max(-.6,min(.6,action.move_direction))
        mem.last_move=tuple(x*speed*terrain for x in direction);mem.last_turn=action.turn_angle
        if speed:mem.search_heading=wrap(mem.heading+action.move_direction)
        mem.last_mode='TREE_WAIT' if speed<.01 else 'TREE_APPROACH'
        self.metrics[mem.last_mode.lower()+'_ticks']+=1
        return action

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time);byid={s['agent_id']:s for s in states}
        for a in actions:
            s=byid[a.agent_id]
            self.memory[a.agent_id].patch_cost=.1+min(math.pi,abs(a.turn_angle))/(2*math.pi)+100.*a.spawn_agent
            self.memory[a.agent_id].patch_cost+=.05*min(a.move_distance,s['speed'])+.5*max(0.,a.move_distance-s['speed'])
        return actions
