"""State-adaptive coefficient search around the healthy-generation safeguard."""
from state_policy import StatePolicy
from gap_policy import GapPolicy


class StateGapPolicy(StatePolicy,GapPolicy):pass
