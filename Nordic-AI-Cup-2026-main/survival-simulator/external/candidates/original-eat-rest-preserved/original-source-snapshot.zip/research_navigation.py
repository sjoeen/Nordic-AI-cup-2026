import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('dispersal',{'label':'colonize_100_repeat','dispersal_distance':100.}),
 ('recover',{'label':'loop_recovery'}),
 ('colonize_memory',{'label':'colonize_memory'}),
 ('colonize_path',{'label':'colonize_path'}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_navigation_{seed}.jsonl')
