import sys
from campaign_runner import run
CASES=[
 ('gap20_repeat',{}),
 ('gap10',{'maximum_birth_gap':10.}),
 ('gap30',{'maximum_birth_gap':30.}),
 ('gap40',{'maximum_birth_gap':40.}),
 ('gap20_energy60',{'healthy_young_energy':60.}),
 ('gap20_birth160',{'birth_energy':160.}),
 ('gap20_late',{'gap_start':600.}),
]
if __name__=='__main__':
    for label,config in CASES:run(int(sys.argv[1]),'gap_policy:GapPolicy',config,label)
