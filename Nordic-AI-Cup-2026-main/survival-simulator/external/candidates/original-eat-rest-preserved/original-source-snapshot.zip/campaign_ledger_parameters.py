import sys
from campaign_runner import run
from campaign_parameters import CASES

seed=int(sys.argv[1])
parity='/workspace/scratch/df85f6754652/deliverables/survival-finalists/agent_dispersal.py' if seed==1 else None
run(seed,'ledger_policy:LedgerPolicy',{},'diagnosis_ledger',parity=parity)
for label,config in CASES:
    run(seed,'dispersal_policy:DispersalPolicy',{'dispersal_distance':100.,**config},label)
