"""Multiscale random search and a small online contextual search bandit."""
import math
from refuge_policy import RefugePolicy
from species_field_trial import wrap,unit
from src.utils.controllers.potential_field_policy import closest_point


class ForagingPolicy(RefugePolicy):
    def __init__(self,preset='foraging',**overrides):
        config=dict(forage_style='biexponential',forage_speed=.8,bandit_period=6.,stale_correction=True)
        config.update(overrides)
        super().__init__(preset,**config)
        self.search_values={}

    def decide_all(self,states,sim_time=None):
        live={s['agent_id'] for s in states}
        for aid,mem in self.memory.items():
            if aid not in live and hasattr(mem,'search_option'):
                self.update_bandit(mem,-15.)
        actions=super().decide_all(states,sim_time)
        for action in actions:self.memory[action.agent_id].search_spawn=action.spawn_agent
        return actions

    def update_bandit(self,mem,penalty=0.):
        if not hasattr(mem,'search_option'):return
        elapsed=max(.5,self.clock-mem.option_start)
        value=(mem.option_reward+penalty)/elapsed
        count,estimate=self.search_values.get((mem.search_context,mem.search_option),(0,0.))
        alpha=1./min(20,count+1)
        self.search_values[(mem.search_context,mem.search_option)]=(count+1,estimate+alpha*(value-estimate))
        del mem.search_option
        self.metrics['bandit_updates']+=1

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        old=getattr(mem,'search_energy',state['energy'])
        change=state['energy']-old+100.*getattr(mem,'search_spawn',False)
        if hasattr(mem,'search_option'):mem.option_reward+=change
        if change>5.:mem.last_meal=self.clock;mem.run_remaining=0.
        mem.search_energy=state['energy'];mem.search_spawn=False
        if getattr(mem,'last_mode','').startswith('MULTISCALE'):
            mem.run_remaining=max(0.,getattr(mem,'run_remaining',0.)-math.hypot(*view['translation']))
        return view

    def steer(self,view):
        action=super().steer(view)
        s,mem,c=view['state'],view['mem'],self.config
        if mem.last_mode!='SEARCH':return action
        style=c['forage_style'];speed_fraction=c['forage_speed']
        nearby_tree=any(o['type']=='Tree' and o['distance']<80. for o in s['observations'])
        if style=='bandit':
            context=(s['biome'],nearby_tree)
            if hasattr(mem,'search_option') and (self.clock-mem.option_start>=c['bandit_period'] or context!=mem.search_context):
                self.update_bandit(mem)
            if not hasattr(mem,'search_option'):
                total=1+sum(n for (ctx,a),(n,q) in self.search_values.items() if ctx==context)
                options=[]
                for option in range(4):
                    n,q=self.search_values.get((context,option),(0,0.))
                    score=q+5.*math.sqrt(math.log(total+1)/(n+1))
                    if n==0:score+=10.
                    options.append((score+mem.rng.random()*.01,option))
                _,mem.search_option=max(options)
                mem.search_context=context;mem.option_start=self.clock;mem.option_reward=0.
                mem.run_remaining=0.
                self.metrics['bandit_option_'+str(mem.search_option)]+=1
            speed_fraction=(1.,.6,.2,0.)[mem.search_option]
        if getattr(mem,'run_remaining',0.)<=0.:
            mem.run_heading=wrap(mem.search_heading+mem.rng.uniform(-math.pi,math.pi))
            recent=self.clock-getattr(mem,'last_meal',-1000.)<8.
            if style=='levy':length=min(600.,50./max(.08,mem.rng.random()))
            elif style=='bandit':length=(400.,150.,60.,10.)[mem.search_option]
            else:
                short=mem.rng.random()<(.85 if recent or nearby_tree else .35)
                length=max(30.,min(600.,mem.rng.expovariate(1./(60. if short else 350.))))
            mem.run_remaining=length
        angle=wrap(mem.run_heading-mem.heading);dx,dy=math.cos(angle),math.sin(angle)
        for edge in view['edges']:
            if math.hypot(edge[1][0]-edge[0][0],edge[1][1]-edge[0][1])<800.:continue
            p=closest_point(edge);d=math.hypot(*p)
            if d<100.:
                normal=unit((-p[0],-p[1]));weight=3.*max(0.,1.-d/100.)
                dx+=weight*normal[0];dy+=weight*normal[1]
        speed=min(s['speed'],s['sprint_speed'])*speed_fraction
        direction,_=self.slide(unit((dx,dy)),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=c['scan']
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        mem.last_move=tuple(v*speed*terrain for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.run_heading=mem.search_heading
        mem.last_mode='MULTISCALE_'+style;self.metrics['multiscale_search_ticks']+=1
        return action
