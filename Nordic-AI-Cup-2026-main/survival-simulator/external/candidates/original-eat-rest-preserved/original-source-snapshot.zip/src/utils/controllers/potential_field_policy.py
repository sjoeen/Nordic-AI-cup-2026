"""Small observation-only potential-field controller.

Angles and edge coordinates are in the agent's local frame. The simulator
moves first and turns second, so both action angles use the old look direction.
No world positions, simulator internals, or hidden entities are used here.
"""
from math import atan2, cos, hypot, pi, sin

from src.utils.DTOs import ActionRequest


def wrap(angle):
    return (angle + pi) % (2 * pi) - pi


def closest_point(edge):
    (ax, ay), (bx, by) = edge
    dx, dy = bx - ax, by - ay
    length2 = dx * dx + dy * dy
    t = max(0.0, min(1.0, -(ax * dx + ay * dy) / length2)) if length2 else 0.0
    return ax + t * dx, ay + t * dy


class PotentialFieldPolicy:
    """Vector steering with walking, emergency sprinting, and reproduction.

    With fields=False, keep food selection and reproduction thresholds, but
    omit repulsion and danger-dependent sprint/reproduction decisions. This
    is a complete greedy comparison policy, not a single-variable ablation.
    """

    def __init__(self, fields=True):
        self.fields = fields

    def decide(self, state):
        agent_id = state["agent_id"]
        energy = state["energy"]
        max_energy = state["max_energy"]
        age = state["age"]
        observations = state["observations"]
        walk = min(state["speed"], state["sprint_speed"])
        sprint = state["sprint_speed"]
        biome_factor = {"swamp": 0.5, "river": 0.3, "desert": 0.8}.get(state["biome"], 1.0)

        fruits = sorted((o for o in observations if o["type"] == "Fruit" and o["distance"] > 6),
                        key=lambda o: (o["distance"], o["angle"]))
        predators = sorted((o for o in observations if o["type"] == "Predator"),
                           key=lambda o: (o["distance"], o["angle"]))
        nearest_predator = predators[0]["distance"] if predators else float("inf")
        danger = self.fields and nearest_predator < 90

        # Slow curvature gives forward exploration persistence without global
        # coordinates or a random-number stream shared with the simulator.
        wander = 0.025 * sin(age * 0.13 + agent_id * 2.399963)
        fx, fy = 0.25 * cos(wander), 0.25 * sin(wander)
        target = fruits[0] if fruits else None
        if target:
            hunger = 1.0 - min(1.0, energy / max(max_energy, 1.0))
            attraction = (1.5 + hunger) * (0.12 if danger else 1.0)
            fx += attraction * cos(target["angle"])
            fy += attraction * sin(target["angle"])

        if self.fields:
            for predator in predators:
                distance = max(predator["distance"], 5.0)
                if distance < 180:
                    strength = min(25.0, 5.0 * (70.0 / distance) ** 2)
                    fx -= strength * cos(predator["angle"])
                    fy -= strength * sin(predator["angle"])

            # Ray casting reports the same edge many times. Count it once.
            edges = {tuple(tuple(point) for point in o["coords"])
                     for o in observations if o["type"] == "Edge"}
            for edge in sorted(edges):
                px, py = closest_point(edge)
                distance = max(hypot(px, py), 0.1)
                if distance < 40:
                    strength = min(12.0, 2.5 * (40.0 - distance) / max(distance - 5.0, 2.0))
                    nx, ny = -px / distance, -py / distance
                    fx += strength * nx
                    fy += strength * ny
                    # A small tangential component breaks head-on wall balance.
                    tx, ty = -ny, nx
                    if tx * fx + ty * fy < 0:
                        tx, ty = -tx, -ty
                    fx += 0.45 * strength * tx
                    fy += 0.45 * strength * ty

            neighbors = sorted((o for o in observations if o["type"] == "Agent"),
                               key=lambda o: (o["distance"], o["angle"], o.get("id", 0)))
            for neighbor in neighbors:
                if neighbor["distance"] < 25:
                    strength = 0.45 * (25 - neighbor["distance"]) / 25
                    fx -= strength * cos(neighbor["angle"])
                    fy -= strength * sin(neighbor["angle"])

        direction = atan2(fy, fx) if hypot(fx, fy) > 1e-8 else wander
        distance = walk
        if self.fields and nearest_predator < 65 and energy >= max_energy / 5 + 5:
            distance = sprint
        elif target and not danger and abs(wrap(direction - target["angle"])) < 0.5:
            distance = min(walk, max(0.0, target["distance"] - 6) / biome_factor)

        # Preserve energy for the parent; older agents can reproduce earlier.
        spawn_threshold = 180.0 if age < 65 else 135.0
        spawn = energy > spawn_threshold and (not self.fields or nearest_predator > 100)
        turn = max(-0.4, min(0.4, direction))
        return ActionRequest(agent_id=agent_id, move_distance=float(distance),
                             move_direction=float(direction), turn_angle=float(turn),
                             spawn_agent=bool(spawn))


_default_policy = PotentialFieldPolicy()


def action_decision(observation_response, rng=None):
    """Drop-in replacement for dummy_agent_policy.action_decision."""
    return _default_policy.decide(observation_response)
