import argparse
from campaign_runner import run

p=argparse.ArgumentParser();p.add_argument('seed',type=int);a=p.parse_args()
cases=[
 ('breed_vision',{'fitness':'vision'}),
 ('breed_hearing',{'fitness':'hearing'}),
 ('breed_balanced',{'fitness':'balanced'}),
 ('breed_elite_vision',{'fitness':'vision','elite_fraction':.7,'retire_weak':True}),
 ('breed_local',{'local_birth':True}),
]
for label,config in cases:run(a.seed,'breeding2_policy:BreedingPolicy',config,label)
