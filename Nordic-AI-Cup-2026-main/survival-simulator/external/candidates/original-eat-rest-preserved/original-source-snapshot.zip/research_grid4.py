import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('adaptive',{'label':'absolute_reserve','crowd_escape':False,'hard_idle_energy':240.,'birth_energy':175.,'birth_floor':112.,'fertile_population':True,'population':8,'population_floor':3}),
 ('adaptive',{'label':'frugal_family','crowd_escape':False,'hard_idle_energy':180.,'birth_energy':145.,'birth_floor':108.,'fertile_population':True,'population':6,'population_floor':2}),
 ('alarm',{'label':'triage_reserve','hard_idle_energy':240.,'birth_energy':180.,'birth_floor':112.,'fertile_population':True,'emergency_birth':True}),
 ('direct',{'label':'hearing_selection','hard_idle_energy':250.,'birth_energy':180.,'population':12,'selective_breeding':600.,'fertile_population':True}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid4_{seed}.jsonl')
