import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 {'label':'accessible_preference'},
 {'label':'accessible_only','accessible_mode':'strict'},
 {'label':'individual_targets','accessible_mode':'none','individual_targets':True},
]
for config in cases:run(seed,'accessible',config,log=f'research_accessible_{seed}.jsonl')
