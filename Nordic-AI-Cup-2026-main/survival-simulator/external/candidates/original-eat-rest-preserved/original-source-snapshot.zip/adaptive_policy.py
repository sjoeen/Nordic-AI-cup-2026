"""Emergency lineage renewal and multi-predator velocity steering."""
import math
from strategy_lab import SurvivalPolicy
from species_field_trial import rotate,wrap,unit


class AdaptivePolicy(SurvivalPolicy):
    def __init__(self,preset='adaptive',**overrides):
        config=dict(escape='direct',gaze_turn=math.pi,population=6,population_floor=2,
                    emergency_birth=True,emergency_birth_distance=55.,renewal_age=75.,
                    crowd_escape=True,crowd_margin=45.,hunger_feed=True,search_speed=.4,sprint_ceiling=None)
        config.update(overrides)
        super().__init__(preset,**config)

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time)
        c=self.config
        if c['sprint_ceiling'] is not None:
            byid={s['agent_id']:s for s in states}
            for action in actions:
                s=byid[action.agent_id]
                cap=max(min(s['speed'],s['sprint_speed']),min(c['sprint_ceiling'],s['sprint_speed']))
                if action.move_distance>cap:
                    action.move_distance=cap
                    terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
                    self.memory[action.agent_id].last_move=(cap*terrain*math.cos(action.move_direction),cap*terrain*math.sin(action.move_direction))
        if c['emergency_birth']:
            young=sum(s['age']<c['renewal_age'] for s in states)
            byid={s['agent_id']:s for s in states}
            for action in actions:
                s=byid[action.agent_id]
                if action.spawn_agent:continue
                enemies=[o['distance'] for o in s['observations'] if o['type']=='Predator']
                safe=not enemies or min(enemies)>c['emergency_birth_distance']
                cost=.05*min(action.move_distance,s['speed'])+.5*max(0.,action.move_distance-s['speed'])+abs(action.turn_angle)/(2*math.pi)
                if safe and s['energy']>112.+cost and (len(states)<3 or (s['age']>c['renewal_age'] and young<max(2,self.config['population_floor']))):
                    action.spawn_agent=True;young+=1
                    self.metrics['emergency_births']+=1
        return actions

    def steer(self,view):
        s,mem,c=view['state'],view['mem'],self.config
        action=super().steer(view)
        if not view['escaping'] or not c['crowd_escape']:return action
        enemies=view['predators'][:5]
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        walk=min(s['speed'],s['sprint_speed'])
        sx=sy=0.
        for p in enemies:
            d=max(10.,p['obs']['distance'])
            sx-=p['p'][0]/d**3;sy-=p['p'][1]/d**3
        away=math.atan2(sy,sx)
        speeds=[walk]
        if s['energy']>.2*s['max_energy']+5. and s['sprint_speed']>walk:
            speeds.extend(((walk+s['sprint_speed'])/2.,s['sprint_speed']))
        angles=[away+i*math.pi/12 for i in range(-6,7)]
        angles.append(action.move_direction)
        food=min(view['fruits'],key=lambda f:f['obs']['distance']) if view['fruits'] else None
        if food and c['hunger_feed']:angles.append(food['obs']['angle'])
        options=[]
        for speed in speeds:
            for angle in angles:
                direction,_=self.slide((math.cos(angle),math.sin(angle)),view,speed)
                vx,vy=direction[0]*speed*terrain,direction[1]*speed*terrain
                minimum=math.inf;ending=math.inf
                for enemy in enemies:
                    ex,ey=enemy['velocity']
                    if not enemy['measured']:
                        ex,ey=15.*terrain*math.cos(enemy['heading']),15.*terrain*math.sin(enemy['heading'])
                    for t in (1.,2.,3.):
                        d=math.hypot(enemy['p'][0]+ex*(t+1)-vx*t,enemy['p'][1]+ey*(t+1)-vy*t)
                        minimum=min(minimum,d)
                    ending=min(ending,d)
                cost=.05*min(speed,s['speed'])+.5*max(0.,speed-s['speed'])
                progress=0.
                if food and c['hunger_feed']:
                    d=food['obs']['distance']
                    progress=(d-math.hypot(food['p'][0]-vx*3,food['p'][1]-vy*3))*min(1.,75./max(50.,s['energy']))
                score=-1000.*max(0.,25.-minimum)-1.5*max(0.,c['crowd_margin']-minimum)+.15*min(ending,150.)-cost*5.+progress*.5
                goal=view.get('escape_goal')
                if goal is not None:
                    score+=view.get('escape_goal_weight',.5)*(math.hypot(*goal)-math.hypot(goal[0]-vx*3,goal[1]-vy*3))
                options.append((score,speed,direction))
        _,speed,direction=max(options,key=lambda x:x[0])
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=enemies[0]['obs']['angle']
        mem.last_move=(speed*terrain*direction[0],speed*terrain*direction[1])
        mem.last_turn=action.turn_angle;mem.search_heading=wrap(mem.heading+action.move_direction)
        mem.last_mode='CROWD_ESCAPE';self.metrics['crowd_escape_ticks']+=1
        return action
