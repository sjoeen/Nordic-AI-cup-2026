"""Separate fleeing agents and optionally lead hunters away with old agents."""
import math
from dispersal_policy import DispersalPolicy
from species_field_trial import point,unit,wrap


class DecoyPolicy(DispersalPolicy):
    def __init__(self,preset='decoy',**overrides):
        config=dict(dispersal_distance=100.,decoys=True,escape_separation=.5)
        config.update(overrides)
        super().__init__(preset,**config)

    def allocate(self,views):
        super().allocate(views)
        selected=None
        if self.config['decoys'] and len(views)>=4:
            candidates=[(v['state']['age'],aid) for aid,v in views.items()
                        if v['state']['age']>60. and v['state']['energy']>60.
                        and v['agents'] and v['predators'] and v['predators'][0]['obs']['distance']<160.]
            if candidates:selected=max(candidates)[1]
        for aid,view in views.items():
            view['decoy']=aid==selected
            if not view['agents']:continue
            if self.config['decoys'] and not view['decoy']:continue
            p=point(view['agents'][0]);direction=unit((-p[0],-p[1]))
            view['escape_goal']=tuple(200.*v for v in direction)
            view['escape_goal_weight']=self.config['escape_separation']
            if view['decoy']:
                view['mem'].target_id=None;view['resting']=False
                self.spawn_ids.discard(aid)

    def steer(self,view):
        action=super().steer(view)
        if not view.get('decoy') or view['escaping']:return action
        s,mem=view['state'],view['mem']
        speed=min(s['speed'],s['sprint_speed'])
        direction,_=self.slide(unit(view['escape_goal']),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=view['predators'][0]['obs']['angle'];action.spawn_agent=False
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        mem.last_move=tuple(v*speed*terrain for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.last_mode='DECOY'
        self.metrics['decoy_ticks']+=1
        return action
