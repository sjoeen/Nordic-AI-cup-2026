"""Observation-only experiments: modes, persistence, allocation, sliding, arcs.

No policy receives simulator positions, true fruit IDs, or predator velocity.
Synthetic fruit IDs are matched from static landmarks across local frames.
Shared frames are reconstructed from observed teammate IDs/bearings/headings.
"""
import argparse
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
import json
import math
import os
from pathlib import Path
import random
import statistics
import time

os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')

from src.core import SimulationCore
from src.utils.DTOs import ActionRequest
from src.utils.controllers.potential_field_policy import closest_point, wrap
from hierarchical_field_trial import initial_hash

VARIANTS = ('modes', 'persistent', 'allocated', 'sliding', 'tangent')


def rotate(point, angle):
    c, s = math.cos(angle), math.sin(angle)
    return c * point[0] - s * point[1], s * point[0] + c * point[1]


def unit(point, fallback=(1., 0.)):
    length = math.hypot(*point)
    return (point[0] / length, point[1] / length) if length > 1e-9 else fallback


def point(obs):
    return obs['distance'] * math.cos(obs['angle']), obs['distance'] * math.sin(obs['angle'])


@dataclass
class Memory:
    target_id: object = None
    fruit_tracks: list = field(default_factory=list)
    landmarks: list = field(default_factory=list)
    predators: list = field(default_factory=list)
    last_move: tuple = (0., 0.)
    last_turn: float = 0.
    heading: float = 0.
    search_heading: float = 0.
    sequence: int = 0
    last_age: float = -1.
    escape_side: int = 0
    rng: object = None


class SpeciesFields:
    def __init__(self, variant='tangent'):
        stage = VARIANTS.index(variant)
        self.variant = variant
        self.persistent = stage >= 1
        self.allocated = stage >= 2
        self.sliding = stage >= 3
        self.tangent = stage >= 4
        self.memory = {}
        self.parents = {}
        self.metrics = Counter()

    def canonical(self, key):
        self.parents.setdefault(key, key)
        root = key
        while self.parents[root] != root:
            root = self.parents[root]
        while self.parents[key] != key:
            parent = self.parents[key]
            self.parents[key] = root
            key = parent
        return root

    def merge(self, a, b):
        a, b = self.canonical(a), self.canonical(b)
        if a != b:
            self.parents[max(a, b)] = min(a, b)
            self.metrics['cross_agent_track_merges'] += 1

    def observe(self, state):
        aid = state['agent_id']
        mem = self.memory.setdefault(aid, Memory(rng=random.Random(7919 + aid * 104729)))
        observations = state['observations']
        if getattr(self,'config',{}).get('stale_correction',False):
            # Removing an agent while the engine iterates its list can skip
            # the next survivor's sensing/living-cost update. Its action still
            # ran, so unchanged age means the returned bearings are stale.
            if state['age']==mem.last_age and mem.last_age>=0.:
                previous_turn=getattr(mem,'stale_turn',0.)
                delta=rotate(mem.last_move,previous_turn)
                old_shift=getattr(mem,'stale_shift',(0.,0.))
                total_shift=(old_shift[0]+delta[0],old_shift[1]+delta[1])
                total_turn=previous_turn+mem.last_turn
                corrected=[]
                def transform(p):return rotate((p[0]-total_shift[0],p[1]-total_shift[1]),-total_turn)
                for original in observations:
                    obs=dict(original)
                    if obs['type']=='Edge':
                        obs['coords']=tuple(transform(p) for p in obs['coords'])
                    else:
                        p=transform(point(obs))
                        obs['distance']=math.hypot(*p);obs['angle']=math.atan2(p[1],p[0])
                        if 'rel_dir' in obs:
                            heading=original['angle']+math.pi-original['rel_dir']-total_turn
                            obs['rel_dir']=wrap(obs['angle']+math.pi-heading)
                    corrected.append(obs)
                observations=corrected
                state={**state,'observations':observations}
                mem.stale_turn=total_turn;mem.stale_shift=total_shift
                self.metrics['stale_observation_corrections']+=1
            else:
                mem.stale_turn=0.;mem.stale_shift=(0.,0.)
        fruits = sorted((o for o in observations if o['type'] == 'Fruit' and o['distance'] > 6),
                        key=lambda o: (o['distance'], o['angle']))
        predators = sorted((o for o in observations if o['type'] == 'Predator'),
                           key=lambda o: (o['distance'], o['angle']))
        agents = sorted((o for o in observations if o['type'] == 'Agent'),
                        key=lambda o: (o['distance'], o.get('id', -1)))
        edges = sorted({tuple(tuple(p) for p in o['coords']) for o in observations if o['type'] == 'Edge'})
        landmarks = [('Fruit', point(o)) for o in fruits]
        landmarks += [('Tree', point(o)) for o in observations if o['type'] == 'Tree']
        landmarks += [('Corner', p) for p in sorted({p for edge in edges for p in edge})]
        # Estimate actual translation from static landmarks. Commanded motion
        # is only a fallback because the simulator can redirect collisions.
        shift = rotate(mem.last_move, -mem.last_turn)
        rotated_old = [(kind, rotate(p, -mem.last_turn)) for kind, p in mem.landmarks]
        estimates = []
        for kind, old in rotated_old:
            candidates = [(q[0], q[1]) for k, q in landmarks if k == kind]
            if not candidates:
                continue
            expected = (old[0] - shift[0], old[1] - shift[1])
            q = min(candidates, key=lambda p: math.hypot(p[0] - expected[0], p[1] - expected[1]))
            if math.hypot(q[0] - expected[0], q[1] - expected[1]) < 3.:
                estimates.append((old[0] - q[0], old[1] - q[1]))
        if len(estimates) >= 2:
            shift = (statistics.median(p[0] for p in estimates), statistics.median(p[1] for p in estimates))
        elif rotated_old and landmarks:
            # Collision recovery: test rigid translations supported by at
            # least three landmarks of matching types, never hidden poses.
            max_shift = math.hypot(*mem.last_move) + 1.
            proposals = []
            for kind, p in rotated_old[:24]:
                for other_kind, q in landmarks[:24]:
                    delta = (p[0] - q[0], p[1] - q[1])
                    if kind == other_kind and math.hypot(*delta) <= max_shift:
                        proposals.append(delta)
            if proposals:
                best = max(proposals, key=lambda d: sum(math.hypot(d[0]-p[0], d[1]-p[1]) < .75 for p in proposals))
                support = [p for p in proposals if math.hypot(best[0]-p[0], best[1]-p[1]) < .75]
                if len(support) >= 3:
                    shift = (statistics.median(p[0] for p in support), statistics.median(p[1] for p in support))
                    self.metrics['motion_corrections'] += 1

        old_tracks = []
        for key, old in mem.fruit_tracks:
            p = rotate(old, -mem.last_turn)
            old_tracks.append((key, (p[0] - shift[0], p[1] - shift[1])))
        current_points = [point(o) for o in fruits]
        matches = sorted((math.hypot(old[0] - p[0], old[1] - p[1]), i, j)
                         for i, (_, old) in enumerate(old_tracks)
                         for j, p in enumerate(current_points)
                         if math.hypot(old[0] - p[0], old[1] - p[1]) < 2.)
        old_used, new_used, identifiers = set(), set(), {}
        for distance, i, j in matches:
            if i not in old_used and j not in new_used:
                identifiers[j] = old_tracks[i][0]
                old_used.add(i)
                new_used.add(j)
                self.metrics['fruit_track_matches'] += 1
        tracks = []
        for j, (obs, p) in enumerate(zip(fruits, current_points)):
            if j not in identifiers:
                mem.sequence += 1
                identifiers[j] = (aid, mem.sequence)
            tracks.append(dict(key=identifiers[j], p=p, obs=obs))

        # Predators have headings but no IDs/speeds. Estimate displacement
        # between observations when possible, otherwise use observed heading.
        old_pred = []
        for p in mem.predators:
            q = rotate(p, -mem.last_turn)
            old_pred.append((q[0] - shift[0], q[1] - shift[1]))
        pred_data = []
        for obs in predators:
            p = point(obs)
            heading = wrap(obs['angle'] + math.pi - obs.get('rel_dir', 0.))
            velocity = (0., 0.)
            measured = False
            if old_pred:
                previous = min(old_pred, key=lambda q: math.hypot(p[0]-q[0], p[1]-q[1]))
                delta = (p[0]-previous[0], p[1]-previous[1])
                if math.hypot(*delta) <= 18.:
                    velocity, measured = delta, True
            pred_data.append(dict(obs=obs, p=p, heading=heading, velocity=velocity, measured=measured))
        mem.fruit_tracks = [(t['key'], t['p']) for t in tracks]
        mem.landmarks = landmarks
        mem.predators = [point(o) for o in predators]
        mem.heading = wrap(mem.heading + mem.last_turn)
        mem.last_age = state['age']
        threshold = max(state['hearing_radius'], .6 * state['vision_range'])
        escaping = bool(predators and predators[0]['distance'] < threshold)
        return dict(state=state, mem=mem, fruits=tracks, predators=pred_data,
                    agents=agents, edges=edges, escaping=escaping, threshold=threshold, translation=shift)

    def shared_frames(self, views):
        graph = defaultdict(list)
        for aid, view in views.items():
            for obs in view['agents']:
                bid = obs.get('id')
                if bid not in views:
                    continue
                offset = point(obs)
                angle = wrap(obs['angle'] + math.pi - obs['rel_dir'])
                graph[aid].append((bid, offset, angle))
                reverse = rotate((-offset[0], -offset[1]), -angle)
                graph[bid].append((aid, reverse, -angle))
        poses = {}
        for root in sorted(views):
            if root in poses:
                continue
            poses[root] = (root, (0., 0.), 0.)
            queue = deque([root])
            while queue:
                aid = queue.popleft()
                component, origin, orientation = poses[aid]
                for bid, offset, angle in sorted(graph[aid]):
                    if bid in poses:
                        continue
                    rotated = rotate(offset, orientation)
                    poses[bid] = (component, (origin[0]+rotated[0], origin[1]+rotated[1]), wrap(orientation+angle))
                    queue.append(bid)
        self.metrics['component_ticks'] += len({p[0] for p in poses.values()})
        self.metrics['hivemind_ticks'] += 1
        # Spatial hashing only compares fruit in a currently aligned frame.
        cells = defaultdict(list)
        located = []
        for aid, view in sorted(views.items()):
            component, origin, orientation = poses[aid]
            for fruit in view['fruits']:
                p = rotate(fruit['p'], orientation)
                p = (p[0]+origin[0], p[1]+origin[1])
                cx, cy = math.floor(p[0]/2.), math.floor(p[1]/2.)
                candidates = [item for dx in (-1,0,1) for dy in (-1,0,1)
                              for item in cells[(component,cx+dx,cy+dy)]
                              if item[0] != aid and math.hypot(item[2][0]-p[0], item[2][1]-p[1]) < 1.]
                if candidates:
                    match = min(candidates, key=lambda item: math.hypot(item[2][0]-p[0], item[2][1]-p[1]))
                    self.merge(fruit['key'], match[1])
                cells[(component,cx,cy)].append((aid, fruit['key'], p))
                located.append((component, fruit['key'], p))
        # Share currently observed fruit throughout each reconstructed frame,
        # allowing the nearest agent to be assigned even when facing away.
        # No coordinates from the simulation engine enter this calculation.
        pooled = {}
        for component, key, p in located:
            pooled.setdefault((component, self.canonical(key)), p)
        for aid, view in views.items():
            component, origin, orientation = poses[aid]
            view['shared_pose'] = poses[aid]
            own = {self.canonical(f['key']) for f in view['fruits']}
            for (fruit_component, key), p in pooled.items():
                if fruit_component != component or key in own:
                    continue
                local = rotate((p[0]-origin[0], p[1]-origin[1]), -orientation)
                distance = math.hypot(*local)
                if distance <= 6.:
                    continue
                view['fruits'].append(dict(key=key,p=local,shared=True,
                                          obs=dict(type='Fruit',distance=distance,angle=math.atan2(local[1],local[0]))))
                self.metrics['shared_fruit_observations'] += 1

    def allocate(self, views):
        if self.allocated:
            self.shared_frames(views)
        for aid, view in views.items():
            if 'max_fruit_distance' in view:
                view['fruits'] = [f for f in view['fruits'] if f['obs']['distance'] <= view['max_fruit_distance']]
            for fruit in view['fruits']:
                fruit['id'] = self.canonical(fruit['key']) if self.allocated else fruit['key']
            mem = view['mem']
            if mem.target_id is not None and self.allocated:
                mem.target_id = self.canonical(mem.target_id)
            visible = {f['id']: f for f in view['fruits']}
            if view['escaping'] or not view.get('eligible',True) or mem.target_id not in visible or not self.persistent:
                mem.target_id = None
            view['visible'] = visible

        if not self.allocated:
            for view in views.values():
                mem = view['mem']
                if not view['escaping'] and view.get('eligible',True) and mem.target_id is None and view['fruits']:
                    mem.target_id = min(view['fruits'], key=lambda f:f['obs']['distance'])['id']
            return
        # Reserve valid existing targets before distance-based matching.
        proposals = []
        for aid, view in views.items():
            key = view['mem'].target_id
            if key is not None:
                proposals.append((view['visible'][key]['obs']['distance'], aid, key))
        owners, assigned = {}, set()
        for distance, aid, key in sorted(proposals):
            if key not in owners:
                owners[key], assigned = aid, assigned | {aid}
                self.metrics['preserved_assignments'] += 1
            else:
                views[aid]['mem'].target_id = None
                self.metrics['newly_discovered_conflicts'] += 1
        candidates = sorted((fruit['obs']['distance'], aid, fruit['id'])
                            for aid, view in views.items() if not view['escaping'] and view.get('eligible',True) and aid not in assigned
                            for fruit in view['fruits'])
        for distance, aid, key in candidates:
            if aid not in assigned and key not in owners:
                views[aid]['mem'].target_id = key
                owners[key] = aid
                assigned.add(aid)
        assert len(owners) == len(assigned)

    def slide(self, desired, view, distance):
        original = unit(desired)
        result = original
        terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(view['state']['biome'], 1.)
        travel = distance * terrain
        used = False
        walls = sorted(((math.hypot(*closest_point(e)), e) for e in view['edges']), key=lambda item:item[0])
        for clearance, edge in walls:
            p = closest_point(edge)
            normal = unit((-p[0], -p[1]))
            inward = -(result[0]*normal[0] + result[1]*normal[1])
            if clearance > 7. + max(0., inward)*travel or inward <= 0.:
                continue
            tangent = unit((edge[1][0]-edge[0][0], edge[1][1]-edge[0][1]))
            along = result[0]*tangent[0] + result[1]*tangent[1]
            if abs(along) < .05:
                prior = rotate(view['mem'].last_move, -view['mem'].last_turn)
                along = prior[0]*tangent[0] + prior[1]*tangent[1]
                if abs(along) < .05:
                    along = 1. if view['state']['agent_id'] % 2 == 0 else -1.
            sign = 1. if along >= 0 else -1.
            outward = .2 if clearance < 7. else .04
            result = unit((sign*tangent[0] + outward*normal[0], sign*tangent[1] + outward*normal[1]))
            used = True
        return result, used

    def arc_escape(self, view, distance):
        predator = view['predators'][0]
        away = unit((-predator['p'][0], -predator['p'][1]))
        velocity = predator['velocity']
        heading = (math.atan2(velocity[1], velocity[0])
                   if predator['measured'] and math.hypot(*velocity) > .5 else predator['heading'])
        # An approach line points from predator toward prey. If the observed
        # heading points away, use the line of sight for escape construction.
        if math.cos(heading)*away[0] + math.sin(heading)*away[1] < .3:
            heading = math.atan2(away[1], away[0])
        terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(view['state']['biome'], 1.)
        candidates = []
        for side in (-1, 1):
            angle = heading + side*math.pi/3.  # 60-degree evasion arc
            candidate = (math.cos(angle), math.sin(angle))
            if candidate[0]*away[0] + candidate[1]*away[1] < .1:
                angle = math.atan2(away[1], away[0]) + side*math.pi/3.
                candidate = (math.cos(angle), math.sin(angle))
            candidate, slid = self.slide(candidate, view, distance)
            clearance = math.inf
            for enemy in view['predators']:
                # When newly observed, only heading is known; compare current
                # separation rather than inventing the enemy's actual speed.
                vx, vy = enemy['velocity'] if enemy['measured'] else (0., 0.)
                for horizon in (1., 2.):
                    ax, ay = candidate[0]*distance*terrain*horizon, candidate[1]*distance*terrain*horizon
                    px, py = enemy['p'][0]+vx*horizon, enemy['p'][1]+vy*horizon
                    clearance = min(clearance, math.hypot(ax-px, ay-py))
            score = clearance + (2. if side == view['mem'].escape_side else 0.)
            candidates.append((score, side, candidate))
        _, side, result = max(candidates, key=lambda c:(c[0], c[1]))
        view['mem'].escape_side = side
        return result

    def steer(self, view):
        state, mem = view['state'], view['mem']
        target = view['visible'].get(mem.target_id)
        fraction = state['energy'] / max(state['max_energy'], 1e-9)
        walk = max(0., min(state['speed'], state['sprint_speed']))
        distance = walk
        if view['escaping']:
            mode = 'ESCAPE'
            self.metrics['escape_ticks'] += 1
            if fraction > .4:
                distance = max(0., state['sprint_speed'])
                self.metrics['sprint_ticks'] += 1
            predator = view['predators'][0]
            desired = unit((-predator['p'][0], -predator['p'][1]))
            if self.tangent:
                desired = self.arc_escape(view, distance)
        elif target is not None:
            mode = 'EAT'
            self.metrics['eat_ticks'] += 1
            # Exactly one fruit contributes attraction; no predator field.
            strength = 40. / max(target['obs']['distance'], 8.)
            tx, ty = unit(target['p'])
            desired = (tx*strength, ty*strength)
            sx = sy = 0.
            for teammate in view['agents']:
                if teammate['distance'] < 25.:
                    weight = .2*(1.-teammate['distance']/25.)
                    sx -= weight*math.cos(teammate['angle'])
                    sy -= weight*math.sin(teammate['angle'])
            # Keep separation mild relative to attraction, even in a crowd.
            cap = min(1., .2*strength/max(math.hypot(sx, sy), 1e-9))
            desired = (desired[0]+cap*sx, desired[1]+cap*sy)
        else:
            mode = 'SEARCH'
            self.metrics['search_ticks'] += 1
            if self.allocated and view['fruits'] and view['agents']:
                nearest = view['agents'][0]
                mem.search_heading = wrap(mem.heading + nearest['angle'] + math.pi)
                self.metrics['displaced_search_ticks'] += 1
            mem.search_heading = wrap(mem.search_heading + mem.rng.uniform(-.025, .025))
            angle = wrap(mem.search_heading-mem.heading)
            desired = (math.cos(angle), math.sin(angle))

        if mode != 'ESCAPE' and state['age'] > 60. and (target is None or target['obs']['distance'] > state['hearing_radius']):
            distance *= max(.5, 60./state['age'])
        if self.sliding:
            desired, slid = self.slide(desired, view, distance)
            self.metrics['wall_slide_ticks'] += int(slid)
        else:
            # Earlier-stage control uses normal repulsion plus the same small
            # tangent used in the hierarchical experiment.
            fx, fy = desired
            radius = max(20., min(40., 2.*walk+5.))
            for edge in view['edges']:
                px, py = closest_point(edge)
                d = max(math.hypot(px, py), .1)
                if d >= radius:
                    continue
                strength = min(12., 4.*(1.-d/radius)**2*5./max(d-5., 1.))
                nx, ny = -px/d, -py/d
                tx, ty = -ny, nx
                if tx*fx + ty*fy < 0:
                    tx, ty = -tx, -ty
                fx += strength*(nx+.5*tx)
                fy += strength*(ny+.5*ty)
            desired = (fx, fy)
        direction = math.atan2(desired[1], desired[0]) if math.hypot(*desired) > 1e-9 else wrap(mem.search_heading-mem.heading)
        if mode == 'EAT' and abs(wrap(direction-target['obs']['angle'])) < .5:
            terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(state['biome'], 1.)
            distance = min(distance, max(0., target['obs']['distance']-6.)/terrain)
        threshold = max(.8*state['max_energy'], 100.+.2*state['max_energy'])
        spawn = state['energy'] > threshold and not view['predators']
        turn = max(-.4, min(.4, direction))
        terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(state['biome'], 1.)
        mem.last_move = (distance*terrain*math.cos(direction), distance*terrain*math.sin(direction))
        mem.last_turn = turn
        # Persist the heading actually chosen, including wall deflections.
        # Keeping the pre-wall search heading repeatedly drives into the wall.
        mem.search_heading = wrap(mem.heading+direction)
        return ActionRequest(agent_id=state['agent_id'], move_distance=distance,
                             move_direction=direction, turn_angle=turn, spawn_agent=spawn)

    def decide_all(self, states):
        # A new game can reuse IDs and ages. Clear all cross-game state.
        if any(s['agent_id'] in self.memory and s['age'] < self.memory[s['agent_id']].last_age for s in states):
            self.memory.clear()
            self.parents.clear()
        live = {s['agent_id'] for s in states}
        self.memory = {key: value for key, value in self.memory.items() if key in live}
        views = {s['agent_id']:self.observe(s) for s in sorted(states,key=lambda s:s['agent_id'])}
        self.allocate(views)
        return [self.steer(views[s['agent_id']]) for s in states]


def run(seed, variant, limit=3000):
    started = time.perf_counter()
    policy = SpeciesFields(variant)
    sim = SimulationCore(seed=seed)
    reference = json.loads(Path('benchmark_results.json').read_text())
    assert initial_hash(sim) == next(r['initial_state_sha256'] for r in reference if r['seed']==seed)
    deaths = []
    original_kill = sim.env.kill_agent
    def record_kill(agent):
        deaths.append((float(agent.age), float(agent.energy)))
        original_kill(agent)
    sim.env.kill_agent = record_kill
    actions = []
    peak, calls, elapsed = len(sim.env.agents), 0, 0.
    for tick in range(round(limit/sim.dt)):
        state = sim.step(actions)
        peak = max(peak, state['num_agents'])
        if (tick+1) % 2000 == 0:
            print(json.dumps(dict(event='progress', variant=variant, seed=seed, time=round(state['sim_time'],1),
                                  alive=state['num_agents'], score=round(state['score'],2))),flush=True)
        if not state['num_agents']:
            break
        t = time.perf_counter()
        decoded = policy.decide_all(state['observations'])
        elapsed += time.perf_counter()-t
        calls += len(decoded)
        actions = [(action.agent_id, action) for action in decoded]
    result = dict(variant=variant, seed=seed, survival_seconds=round(state['sim_time'],1), score=state['score'],
                  completed=bool(state['num_agents'] and tick+1==round(limit/sim.dt)), peak_agents=peak,
                  agents_born=sim.env._next_agent_id, deaths_with_no_energy=sum(e<=0 for a,e in deaths),
                  deaths_with_energy=sum(e>0 for a,e in deaths), controller_seconds=elapsed,
                  controller_us=elapsed*1e6/max(calls,1), wall_seconds=time.perf_counter()-started,
                  metrics=dict(policy.metrics))
    print(json.dumps(dict(event='result',**result)),flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--variants', nargs='+', choices=VARIANTS, default=list(VARIANTS))
    parser.add_argument('--seeds', nargs='+', type=int, default=[1,2,3])
    parser.add_argument('--limit', type=float, default=3000)
    args = parser.parse_args()
    results = [run(seed, variant, args.limit) for variant in args.variants for seed in args.seeds]
    summaries = {variant: dict(mean_survival=statistics.mean(r['survival_seconds'] for r in results if r['variant']==variant),
                               mean_score=statistics.mean(r['score'] for r in results if r['variant']==variant)) for variant in args.variants}
    print(json.dumps(dict(event='summary', summaries=summaries, results=results)),flush=True)
