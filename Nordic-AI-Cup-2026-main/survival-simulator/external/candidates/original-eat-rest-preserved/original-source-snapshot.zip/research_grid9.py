import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('memory',{'label':'food_memory'}),
 ('memory',{'label':'food_memory_coverage','coverage':True}),
 ('adaptive',{'label':'stale_direct','crowd_escape':False,'stale_correction':True,'sprint_ceiling':16.}),
 ('safety',{'label':'stale_safety','enemy_speed':'maximum','filter_horizon':2,'stale_correction':True}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid9_{seed}.jsonl')
