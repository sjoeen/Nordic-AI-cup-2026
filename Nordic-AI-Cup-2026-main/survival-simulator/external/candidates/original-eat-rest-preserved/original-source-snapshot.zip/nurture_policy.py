"""Feeding policies layered on the existing generation-gap controller."""
import math
from generation_policy import GenerationPolicy
from nursery_policy import segment_clear


class NurturePolicy(GenerationPolicy):
    def __init__(self, preset='nurture', **overrides):
        config = dict(maximum_birth_gap=20., newborn_priority=False,
                      newborn_food_range=120., newborn_care_age=12.,
                      late_feeding=False, late_start=900., late_food_range=180.,
                      late_reserve=400., mature_age=85.)
        config.update(overrides)
        super().__init__(preset, **config)

    def observe(self, state):
        v = super().observe(state)
        c, m = self.config, v['mem']
        if c['newborn_priority'] and m.colonist and any(
                f['obs']['distance'] < c['newborn_food_range'] and
                segment_clear((0., 0.), f['p'], v['edges'], 0.)
                for f in v['fruits']):
            m.colonist = False
            self.metrics['nurture_food_interrupts'] += 1
        return v

    def shared_frames(self, views):
        super().shared_frames(views)
        c = self.config
        if c['late_feeding'] and self.clock >= c['late_start']:
            for aid, v in views.items():
                s = v['state']
                if aid in self.retired_ids or v['mem'].colonist:
                    continue
                # Build reserves where there is food; avoid an expensive
                # search merely because the desired reserve increased.
                affordable = any(10. < f['obs']['distance'] < c['late_food_range']
                                 and segment_clear((0., 0.), f['p'], v['edges'], 0.)
                                 for f in v['fruits'])
                if affordable and s['age'] < c['mature_age']:
                    v['resting'] = s['energy'] >= min(c['late_reserve'], .9*s['max_energy']) and aid not in self.spawn_ids
                    v['eligible'] = not v['resting']

    def allocate(self, views):
        super().allocate(views)
        c = self.config
        if not c['newborn_priority']:
            return
        owners = {v['mem'].target_id: aid for aid, v in views.items()
                  if v['mem'].target_id is not None}
        children = sorted((s['energy'], aid) for aid, v in views.items()
                          if (s := v['state'])['age'] < c['newborn_care_age']
                          and s['energy'] < 100. and not v['escaping'])
        for _, aid in children:
            v = views[aid]
            s, m = v['state'], v['mem']
            if m.colonist:
                continue
            options = []
            for key, f in v['visible'].items():
                d = f['obs']['distance']
                if d > c['newborn_food_range'] or not segment_clear((0., 0.), f['p'], v['edges'], 0.):
                    continue
                owner = owners.get(key)
                if owner is not None and owner != aid:
                    adult = views[owner]['state']
                    if adult['energy'] < 100. or adult['age'] < c['newborn_care_age']:
                        continue
                options.append((d, key, owner))
            if not options:
                continue
            _, key, owner = min(options)
            if key == m.target_id:
                continue
            if m.target_id is not None:
                owners.pop(m.target_id, None)
            if owner is not None and owner != aid:
                donor = views[owner]
                donor['mem'].target_id = None
                # Keep the displaced parent still if it can safely wait.
                if donor['state']['energy'] > 140.:
                    donor['resting'] = True
                self.metrics['nurture_food_donations'] += 1
            m.target_id = key
            v['resting'] = False
            owners[key] = aid
