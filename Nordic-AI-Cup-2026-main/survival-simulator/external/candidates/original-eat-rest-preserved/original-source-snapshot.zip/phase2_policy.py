"""Keep the tested opening, then change explicitly named late-game settings."""
from dispersal_policy import DispersalPolicy


class PhasePolicy(DispersalPolicy):
    def __init__(self,preset='phase2',**overrides):
        config=dict(dispersal_distance=100.,phase_start=900.,late_settings={})
        config.update(overrides);super().__init__(preset,**config)
        self.early_settings={k:self.config[k] for k in self.config['late_settings']}

    def decide_all(self,states,sim_time=None):
        now=float(sim_time) if sim_time is not None else self.clock+.1
        self.config.update(self.config['late_settings'] if now>=self.config['phase_start'] else self.early_settings)
        return super().decide_all(states,sim_time)
