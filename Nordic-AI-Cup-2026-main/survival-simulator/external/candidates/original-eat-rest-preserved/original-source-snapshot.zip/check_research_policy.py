import math
from strategy_lab import SurvivalPolicy
from atlas_policy import AtlasPolicy
from verify_controller import observation
from check_species_trial import fruit,threat

def check_rest_allocation():
    for cls in (SurvivalPolicy,AtlasPolicy):
        p=cls(population=0,population_floor=0)
        # Resting A nearest fruit; hungry B must get that fruit, including
        # when its only observation is supplied by A.
        a=observation(agent_id=0,energy=490.,observations=[fruit(20,0),
            dict(type='Agent',id=1,distance=40.,angle=math.pi,rel_dir=0.)])
        b=observation(agent_id=1,energy=40.,observations=[
            dict(type='Agent',id=0,distance=40.,angle=0.,rel_dir=math.pi)])
        actions=p.decide_all([a,b],10.)
        assert p.memory[0].target_id is None
        assert p.memory[1].target_id is not None
        assert actions[0].move_distance==0 and actions[1].move_distance>0

def check_gaze_and_birth():
    p=SurvivalPolicy('direct')
    a=p.decide_all([observation(age=1.,energy=250.,observations=[threat(40.,math.pi)])],1.)[0]
    assert abs(abs(a.turn_angle)-math.pi)<1e-6
    assert math.cos(a.move_direction)>.9 and not a.spawn_agent
    p=SurvivalPolicy('economy')
    actions=p.decide_all([observation(agent_id=i,age=1.,energy=250.) for i in range(11)],1.)
    assert sum(a.spawn_agent for a in actions)==1

if __name__=='__main__':
    check_rest_allocation();check_gaze_and_birth()
    print('Research policy checks passed')
