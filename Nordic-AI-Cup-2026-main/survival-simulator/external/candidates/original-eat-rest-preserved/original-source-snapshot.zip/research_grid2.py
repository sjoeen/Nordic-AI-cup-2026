import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('nursery',{'label':'nursery'}),
 ('nursery_lineage',{'label':'nursery_lineage'}),
 ('direct',{'label':'minimal_lineage','population':4,'population_floor':1,'birth_energy':200.,'search_speed':.4}),
 ('direct',{'label':'rapid_selection','population':24,'population_floor':3,'population_decay':500.,'birth_energy':200.,'retirement':70.,'young_age':40.,'selective_breeding':400.}),
 ('direct',{'label':'cautious_breeding','population':8,'population_floor':2,'birth_energy':350.,'idle_energy':.7,'search_speed':.35}),
 ('nursery',{'label':'habitat_only','detours':False}),
 ('nursery',{'label':'detour_only','protect_habitat':False,'nursery_birth':False}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_grid2_{seed}.jsonl')
