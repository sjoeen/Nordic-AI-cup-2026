import sys
from campaign_runner import run
CASES=[
 ('sensor_distance',{}),
 ('sensor_scan',{'sensor_mode':'scan'}),
 ('sensor_terrain',{'sensor_terrain':True}),
 ('sensor_late',{'sensor_terrain':True,'sensor_start':900.}),
]
if __name__=='__main__':
    for label,config in CASES:run(int(sys.argv[1]),'sensor_search:SensorSearch',config,label)
