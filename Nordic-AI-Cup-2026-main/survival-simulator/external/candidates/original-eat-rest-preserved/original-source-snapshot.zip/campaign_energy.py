import argparse
from campaign_runner import run

p=argparse.ArgumentParser();p.add_argument('seed',type=int);a=p.parse_args()
cases=[
 ('patch2', 'patch2_policy:PatchPolicy',{}),
 ('patch2_children','patch2_policy:PatchPolicy',{'child_settle':True}),
 ('aging_retire','metabolic_policy:MetabolicPolicy',{'inferred_retirement':True}),
 ('aging_convert','metabolic_policy:MetabolicPolicy',{'convert_old_energy':True}),
 ('birth_insurance','metabolic_policy:MetabolicPolicy',{'deathbed_birth':True}),
]
for label,policy,config in cases:run(a.seed,policy,config,label)
