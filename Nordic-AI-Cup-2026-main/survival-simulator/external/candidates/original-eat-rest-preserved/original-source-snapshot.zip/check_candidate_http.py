"""Real HTTP/schema, duplicate-request, and consecutive-game reset check."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import requests

os.environ.setdefault('SDL_VIDEODRIVER','dummy')
os.environ.setdefault('SDL_AUDIODRIVER','dummy')
from src.core import SimulationCore
from src.utils.DTOs import ActionRequest

path=Path(sys.argv[1]).resolve()
spec=importlib.util.spec_from_file_location('candidate_http_reference',path)
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
spec.loader.exec_module(module)
process=subprocess.Popen([sys.executable,'-m','uvicorn','survival_agent:app','--app-dir',str(path.parent),
                          '--host','127.0.0.1','--port','9062'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
try:
    for _ in range(100):
        try:
            ready=requests.get('http://127.0.0.1:9062/',timeout=1)
            if ready.status_code==200:break
        except requests.ConnectionError:pass
        time.sleep(.1)
    else:raise RuntimeError('HTTP startup failed')
    checked=0
    for seed in (1,2,1):
        sim=SimulationCore(seed=seed);policy=module.make_policy();actions=[]
        for tick in range(25):
            result=sim.step(actions)
            payload=dict(game_status='ok',score=result['score'],sim_time=result['sim_time'],
                         n_agents=result['num_agents'],agent_status=result['observations'])
            expected=[a.model_dump() for a in policy.decide_all(result['observations'],result['sim_time'])]
            response=requests.post('http://127.0.0.1:9062/predict',json=payload,timeout=10)
            response.raise_for_status()
            assert response.json()=={'actions':expected},(seed,tick,'HTTP action mismatch')
            duplicate=requests.post('http://127.0.0.1:9062/predict',json=payload,timeout=10)
            assert duplicate.json()==response.json(), 'duplicate request changed state'
            actions=[(a['agent_id'],ActionRequest(**a)) for a in expected];checked+=1
    terminal=dict(game_status='done',score=0.,sim_time=3000.,n_agents=0,agent_status=[])
    assert requests.post('http://127.0.0.1:9062/predict',json=terminal,timeout=10).json()=={'actions':[]}
    print(json.dumps(dict(http_ticks=checked,duplicate_requests=checked,consecutive_games=3,terminal_reset=True,status='passed')))
finally:
    process.terminate()
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:process.kill();process.wait()
