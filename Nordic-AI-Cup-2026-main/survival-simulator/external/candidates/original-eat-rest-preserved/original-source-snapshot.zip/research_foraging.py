import sys
from research_runner import run
seed=int(sys.argv[1])
for style in ('levy','biexponential','bandit'):
 run(seed,'foraging',dict(label='search_'+style,forage_style=style),log=f'research_foraging_{seed}.jsonl')
