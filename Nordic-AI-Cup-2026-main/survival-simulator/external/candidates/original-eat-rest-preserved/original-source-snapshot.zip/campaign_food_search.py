"""Bounded search on the original full-length block; never changes birth gates."""
import json
import math
import random
import statistics
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from campaign_feeding_queue import complete, evaluate

DEFAULT = [250.,0.,80.,.7,7.,0.,0.,0.,0.,0.]
BOUNDS = [(170.,360.),(0.,100.),(35.,130.),(.15,1.),(2.,20.),(-.15,1.25),(0.,1.),(0.,.9),(0.,2.5),(0.,16.)]
SCALES = [35.,25.,20.,.16,3.,.3,.25,.2,.65,4.]
COARSE = ['loose_parent_capacity','loose_parent_sprint','loose_parent_balanced',
          'loose_orchard10','loose_orchard20','loose_orchard_newborn',
          'loose_appetite200','loose_appetite250','loose_appetite300',
          'loose_fresh5','loose_fresh10','loose_fresh15']
COARSE += ['loose_population24','loose_population_free']

def score(rows):
    values = [r['survival_seconds'] for r in rows]
    return 10000.*sum(r['completed'] for r in rows)+.6*statistics.mean(values)+.4*min(values)

def genes_for(label):
    p = list(DEFAULT)
    if label=='loose_appetite200':p[:3] = [200.,40.,80.]
    if label=='loose_appetite250':p[:3] = [250.,70.,80.]
    if label=='loose_appetite300':p[:3] = [300.,80.,100.]
    if label=='loose_parent_capacity':p[5] = .75
    if label=='loose_parent_sprint':p[8] = 2.
    if label=='loose_parent_balanced':p[5:8] = [.5,.6,.4]
    if label.startswith('loose_fresh'):p[9] = float(label.removeprefix('loose_fresh'))
    return p

def mutate(p, rng, scale=1.):
    q = list(p)
    selected = rng.sample(range(len(q)),rng.choice((1,2,3,5)))
    for i in selected:
        lo,hi = BOUNDS[i]
        q[i] = round(max(lo,min(hi,q[i]+rng.gauss(0.,SCALES[i]*scale))),4)
    return q

if __name__=='__main__':
    deadline = datetime.fromisoformat(json.loads(Path('campaign/session.json').read_text())['deadline'].replace('Z','+00:00')).timestamp()
    while not all(complete(label,s) for label in COARSE for s in (1,2,3)):
        if time.time()>deadline-300.:
            raise SystemExit('Deadline: no new search started.')
        time.sleep(10.)
    rng = random.Random(20260918)
    population_cases = ['loose_route2','loose_population24','loose_population_free']
    population_choice = max(population_cases,key=lambda label:score([complete(label,s) for s in (1,2,3)]))
    fixed = {'population':24} if population_choice=='loose_population24' else {'population':10000} if population_choice=='loose_population_free' else {}
    if all(complete(population_choice,s)['completed'] for s in (1,2,3)):
        raise SystemExit('A population variant completed all original seeds; ready for confirmation.')
    families = [label for label in COARSE if 'orchard' not in label and not label.startswith('loose_population')]+['loose_route2']
    ranked = sorted(families,key=lambda label:score([complete(label,s) for s in (1,2,3)]),reverse=True)
    proposals = [list(DEFAULT),genes_for(ranked[0]),genes_for(ranked[1])]
    records = []
    used = set()
    journal = Path('campaign/food_search_records.jsonl')
    if journal.exists():
        records = [json.loads(line) for line in journal.read_text().splitlines() if line.strip()]
        used = {tuple(r['parameters']) for r in records}
    for generation in range(4):
        if time.time()>deadline-300.:
            break
        if records:
            elites = sorted(records,key=lambda r:r['fitness'],reverse=True)[:3]
            proposals = [mutate(elites[0]['parameters'],rng,.65),mutate(elites[0]['parameters'],rng,.65)]
            proposals += [mutate(rng.choice(elites)['parameters'],rng,1.) for _ in range(4)]
        while len(proposals)<6:
            proposals.append(mutate(genes_for(ranked[0]),rng))
        fresh = []
        for p in proposals:
            for _ in range(30):
                if tuple(p) not in used:
                    break
                p = mutate(p,rng)
            if tuple(p) in used:
                continue
            used.add(tuple(p))
            fresh.append(p)
        # Complete all three seeds of each candidate before assessing it.
        for index,p in enumerate(fresh):
            if time.time()>deadline-300.:
                break
            label = f'food_search_t{len(records):03d}'
            configuration = Path('campaign')/f'{label}_config.json'
            if configuration.exists():
                config = json.loads(configuration.read_text())
                p = config['parameters']
            else:
                config = dict(fixed,parameters=p)
                configuration.write_text(json.dumps(config)+'\n')
            with ProcessPoolExecutor(max_workers=3) as pool:
                jobs = [pool.submit(evaluate,('food_search_policy:FoodSearchPolicy',label,config,s)) for s in (1,2,3)]
                for future in as_completed(jobs):
                    print(json.dumps(future.result()),flush=True)
            rows = [complete(label,s) for s in (1,2,3)]
            assert all(r['config']==config for r in rows), 'Candidate configuration mismatch'
            record = dict(label=label,parameters=p,fitness=score(rows),
                          survival=[r['survival_seconds'] for r in rows],completed=sum(r['completed'] for r in rows))
            records.append(record)
            with journal.open('a') as f:f.write(json.dumps(record)+'\n')
            print(json.dumps(dict(event='candidate',**record)),flush=True)
            if record['completed']==3:
                raise SystemExit('All original seeds completed; ready for confirmation.')
    if records:
        print(json.dumps(dict(event='best',**max(records,key=lambda r:r['fitness']))),flush=True)
