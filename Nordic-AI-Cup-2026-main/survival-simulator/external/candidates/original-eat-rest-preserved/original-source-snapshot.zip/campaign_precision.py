import sys
from campaign_runner import run
CASES=[
 ('precision_stop',{'precision_stop':9.5,'guaranteed_ghost_filter':True}),
 ('precision_budget',{'action_budget':True}),
 ('precision_gaze',{'food_gaze_saving':True}),
 ('precision_combined',{'precision_stop':9.5,'guaranteed_ghost_filter':True,'action_budget':True}),
]
if __name__=='__main__':
    for label,config in CASES:run(int(sys.argv[1]),'precision_food:PrecisionFood',config,label)
