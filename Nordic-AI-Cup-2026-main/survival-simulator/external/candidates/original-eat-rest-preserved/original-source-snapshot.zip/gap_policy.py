"""Add a healthy-generation safeguard to the normal colony birth allocator."""
from dispersal_policy import DispersalPolicy


class GapPolicy(DispersalPolicy):
    def __init__(self,preset='gap',**overrides):
        config=dict(dispersal_distance=100.,maximum_birth_gap=20.,healthy_young_energy=40.,
                    maximum_live_factor=2.,gap_start=0.)
        config.update(overrides);super().__init__(preset,**config)

    def allocate(self,views):
        c=self.config
        cap=max(c['population_floor'],round(c['population']*.5**(self.clock/c['population_decay'])))
        states=[v['state'] for v in views.values()]
        youngest=min((s['age'] for s in states if s['energy']>c['healthy_young_energy']),default=1000.)
        if not self.spawn_ids and self.clock>=c['gap_start'] and len(states)<c['maximum_live_factor']*cap and youngest>c['maximum_birth_gap']:
            young=sum(s['age']<c['young_age'] for s in states);candidates=[]
            for aid,v in views.items():
                s=v['state'];threshold=max(c['birth_floor'],min(c['birth_energy'],.75*s['max_energy']))
                if s['age']>60. and young<max(2,cap//2):threshold=min(threshold,160.)
                safe=not v['predators'] or min(p['obs']['distance'] for p in v['predators'])>130.
                if s['energy']>threshold and safe and aid not in self.retired_ids:
                    quality=min(s['speed'],s['sprint_speed'])+.015*s['hearing_radius']+.003*s['vision_range']
                    candidates.append((quality,s['energy'],-aid,aid))
            if candidates:
                aid=max(candidates)[-1];self.spawn_ids.add(aid)
                views[aid]['resting']=False;views[aid]['eligible']=True
                self.metrics['healthy_gap_births']+=1
        super().allocate(views)
