"""Share food through a map inferred exclusively from public wall observations.

The fixed arena dimensions and wall thickness are public simulator constants.
No engine instance, true creature position, or hidden fruit state is accessed.
"""
import math
from collections import defaultdict
from generation_policy import GenerationPolicy
from harvest_policy import HarvestPolicy
from species_field_trial import rotate, wrap


class FoodMapPolicy(GenerationPolicy):
    def __init__(self, preset='food_map', **overrides):
        config = dict(birth_energy=135., birth_floor=112., maximum_birth_gap=20.,
                      food_map_range=450., food_map_memory=12., food_map_start=0.,
                      map_use_landmarks=True,
                      arena_width=1600., arena_height=1200., boundary_thickness=30.)
        config.update(overrides)
        super().__init__(preset, **config)
        self.food_poses = {}
        self.edge_landmarks = {}
        self.food_cache = {}
        self.map_sequence = 0
        self.map_clock = -1.

    def observe(self, state):
        old = self.memory.get(state['agent_id'])
        stale = old is not None and old.last_age >= 0. and state['age'] == old.last_age
        view = super().observe(state)
        view['map_stale'] = stale
        return view

    def edge_pose(self, edge):
        """Recover a pose from a boundary, or a previously mapped rectangle."""
        a,b = edge
        length = math.hypot(b[0]-a[0], b[1]-a[1])
        angle = math.atan2(b[1]-a[1], b[0]-a[0])
        c = self.config
        width,height,thick = c['arena_width'],c['arena_height'],c['boundary_thickness']
        if abs(length-width) < 1e-5:
            heading = wrap(-angle)
            q = rotate(a,heading)
            origin = (-q[0], (thick if q[1]<0. else height-thick)-q[1])
            return origin,heading
        if abs(length-height) < 1e-5:
            heading = wrap(math.pi/2.-angle)
            q = rotate(a,heading)
            origin = ((thick if q[0]<0. else width-thick)-q[0],-q[1])
            return origin,heading
        return None

    def landmark_poses(self, edge):
        a,b = edge
        length = round(math.hypot(b[0]-a[0],b[1]-a[1]),6)
        angle = math.atan2(b[1]-a[1],b[0]-a[0])
        c = self.config
        if not c['map_use_landmarks']:
            return []
        candidates = []
        for axis in (0,1):
            heading = wrap(axis*math.pi/2.-angle)
            q = rotate(a,heading)
            for known in self.edge_landmarks.get((length,axis),[]):
                origin = (known[0]-q[0],known[1]-q[1])
                if 25. < origin[0] < c['arena_width']-25. and 25. < origin[1] < c['arena_height']-25.:
                    candidates.append((origin,heading,(length,axis)))
        return candidates

    def shared_frames(self, views):
        # This also constructs exact poses in each currently connected group.
        super().shared_frames(views)
        c = self.config
        if self.clock < self.map_clock:
            self.food_poses.clear()
            self.edge_landmarks.clear()
            self.food_cache.clear()
            self.map_sequence = 0
        self.map_clock = self.clock
        self.food_poses = {aid:p for aid,p in self.food_poses.items() if aid in views}
        anchors = {}
        for aid,v in views.items():
            if aid in self.food_poses:
                p,h,error = self.food_poses[aid]
                h = wrap(h+v['mem'].last_turn)
                delta = rotate(v['translation'],h)
                self.food_poses[aid] = ((p[0]+delta[0],p[1]+delta[1]),h,
                                        error+.002*math.hypot(*delta)+.002)
            for edge in ([] if v['map_stale'] else v['edges']):
                pose = self.edge_pose(edge)
                if pose is not None:
                    anchors[aid] = (pose[0],pose[1],0.)
                    break
            if aid not in anchors and not v['map_stale']:
                candidates = [p for edge in v['edges'] for p in self.landmark_poses(edge)]
                agreed = []
                for p,h,key in candidates:
                    support = len({other_key for q,angle,other_key in candidates
                                   if math.hypot(p[0]-q[0],p[1]-q[1])<1e-5 and abs(wrap(h-angle))<1e-5})
                    if support >= 2:
                        agreed.append((support,p,h))
                if agreed:
                    _,p,h = max(agreed,key=lambda row:row[0])
                    anchors[aid] = (p,h,0.)
                elif aid in self.food_poses:
                    old,h,error = self.food_poses[aid]
                    nearby = [(math.hypot(p[0]-old[0],p[1]-old[1]),p,angle)
                              for p,angle,_ in candidates if abs(wrap(h-angle))<1e-5]
                    if nearby:
                        distance,p,angle = min(nearby,key=lambda row:row[0])
                        if distance < min(15.,max(6.,error*2.)):
                            anchors[aid] = (p,angle,.01)
        self.food_poses.update(anchors)
        groups = defaultdict(list)
        for aid,v in views.items():
            groups[v['shared_pose'][0]].append(aid)
        for group in groups.values():
            if any(views[aid]['map_stale'] for aid in group):
                continue
            known = [aid for aid in group if aid in self.food_poses]
            if not known:
                continue
            anchor = min(known,key=lambda aid:self.food_poses[aid][2])
            p,h,error = self.food_poses[anchor]
            _,local,angle = views[anchor]['shared_pose']
            rotation = wrap(h-angle)
            q = rotate(local,rotation)
            root = (p[0]-q[0],p[1]-q[1])
            for aid in group:
                _,local,angle = views[aid]['shared_pose']
                q = rotate(local,rotation)
                self.food_poses[aid] = ((root[0]+q[0],root[1]+q[1]),wrap(rotation+angle),error)
        for aid,v in views.items():
            pose = self.food_poses.get(aid)
            if pose is None:
                continue
            origin,heading,error = pose
            if error > 0. or v['map_stale']:
                continue
            for edge in v['edges']:
                a,b = edge
                length = math.hypot(b[0]-a[0],b[1]-a[1])
                if length > 110. or length < 30.00001:
                    continue
                angle = wrap(math.atan2(b[1]-a[1],b[0]-a[0])+heading)
                axis = 0 if abs(angle)<.1 else 1 if abs(wrap(angle-math.pi/2.))<.1 else None
                if axis is None:
                    continue
                q = rotate(a,heading)
                absolute = (origin[0]+q[0],origin[1]+q[1])
                records = self.edge_landmarks.setdefault((round(length,6),axis),[])
                if not any(math.hypot(absolute[0]-p[0],absolute[1]-p[1])<1. for p in records):
                    records.append(absolute)
        self.metrics['mapped_agent_ticks'] += len(self.food_poses)
        if self.clock < c['food_map_start']:
            return
        reliable = {aid:p for aid,p in self.food_poses.items() if p[2]<=.01 and not views[aid]['map_stale']}
        # Expire old reports; negative hearing observations remove consumed
        # food without requiring access to fruit IDs or consumption events.
        self.food_cache = {k:r for k,r in self.food_cache.items() if self.clock-r[1]<c['food_map_memory']}
        observed = {}
        for aid,(origin,heading,error) in reliable.items():
            points = []
            for f in views[aid]['fruits']:
                if f.get('shared') or f['obs']['distance'] < 10.:
                    continue
                q = rotate(f['p'],heading)
                points.append(((origin[0]+q[0],origin[1]+q[1]),f['key']))
            observed[aid] = points
        for key,(p,seen,fruit_key) in list(self.food_cache.items()):
            for aid,(origin,heading,error) in reliable.items():
                distance = math.hypot(p[0]-origin[0],p[1]-origin[1])
                if distance < views[aid]['state']['hearing_radius']-5.:
                    present = any(math.hypot(q[0]-p[0],q[1]-p[1])<5. for q,_ in observed[aid])
                    if distance < 10. or not present:
                        self.food_cache.pop(key,None)
                        break
        for aid,points in observed.items():
            for p,fruit_key in points:
                cell = (round(p[0]/4.),round(p[1]/4.))
                match = next((key for dx in (-1,0,1) for dy in (-1,0,1)
                              if (key:=(cell[0]+dx,cell[1]+dy)) in self.food_cache
                              and math.hypot(self.food_cache[key][0][0]-p[0],self.food_cache[key][0][1]-p[1])<3.),None)
                if match is not None:
                    self.merge(fruit_key,self.food_cache[match][2])
                    cell = match
                self.food_cache[cell] = (p,self.clock,fruit_key)
        for aid,(origin,heading,error) in reliable.items():
            v = views[aid]
            own = {self.canonical(f['key']) for f in v['fruits']}
            for p,seen,key in self.food_cache.values():
                key = self.canonical(key)
                if key in own:
                    continue
                local = rotate((p[0]-origin[0],p[1]-origin[1]),-heading)
                distance = math.hypot(*local)
                if not 10. < distance < c['food_map_range']:
                    continue
                v['fruits'].append(dict(key=key,p=local,shared=True,remembered=seen<self.clock,
                                        obs=dict(type='Fruit',distance=distance,angle=math.atan2(local[1],local[0]))))
                own.add(key)
                self.metrics['mapped_food_reports'] += 1


class MappedHarvestPolicy(FoodMapPolicy, HarvestPolicy):
    pass
