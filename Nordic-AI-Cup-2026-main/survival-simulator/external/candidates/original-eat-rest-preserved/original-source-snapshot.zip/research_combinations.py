import sys
from research_runner import run
seed=int(sys.argv[1])
cases=[
 ('hybrid',{'label':'hybrid_refuge_filter'}),
 ('dispersal',{'label':'colonize_fresh_farmer','dispersal_distance':100.,'fresh_ripen':14.,'ripen_age_limit':55.,'patch_wait':8.}),
 ('dispersal',{'label':'colonize_renewal','dispersal_distance':100.,'young_age':45.,'retirement':75.,'renewal_age':60.}),
 ('dispersal',{'label':'colonize_single_lineage','dispersal_distance':100.,'population_floor':1,'population_decay':600.,'birth_energy':220.}),
 ('dispersal',{'label':'colonize_slow_search','dispersal_distance':100.,'search_speed':.2}),
 ('dispersal',{'label':'colonize_fast_search','dispersal_distance':100.,'search_speed':.8}),
 ('hybrid',{'label':'hybrid_food_priority','filter_food':1.5,'filter_margin':22.}),
]
for preset,config in cases:run(seed,preset,config,log=f'research_combinations_{seed}.jsonl')
