"""Cross-entropy search, full 3-seed evaluations, no shortened screening games."""
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import contextlib
from datetime import datetime,timezone
import json
import math
from pathlib import Path
import statistics
import numpy as np

ROOT=Path(__file__).resolve().parent


def evaluate(job):
    from campaign_runner import run
    label,seed,weights,policy=job
    path=ROOT/f'campaign_{label}_s{seed}.out'
    if path.exists():
        for line in reversed(path.read_text().splitlines()):
            try:r=json.loads(line)
            except ValueError:continue
            if r.get('event')=='result':return label,seed,r
    with path.open('a',buffering=1) as output,contextlib.redirect_stdout(output):
        r=run(seed,policy,{'state_weights':weights},label)
    return label,seed,r


def main():
    p=argparse.ArgumentParser();p.add_argument('--rounds',type=int,default=3);p.add_argument('--size',type=int,default=10)
    p.add_argument('--workers',type=int,default=3);p.add_argument('--seed',type=int,default=20260918)
    p.add_argument('--prefix',default='evo');p.add_argument('--policy',default='state_policy:StatePolicy')
    p.add_argument('--dimensions',type=int,default=14);p.add_argument('--rotate-seeds',action='store_true');a=p.parse_args()
    rng=np.random.default_rng(a.seed);center=np.zeros(a.dimensions);center[5]=math.log(160./180.)
    if a.dimensions==15:center[14]=.25
    deviation=np.full(a.dimensions,.18)
    if a.dimensions==15:deviation[14]=.4
    champion=center.copy();best=-math.inf
    archive=[]
    for round_id in range(a.rounds):
        population=[champion.copy(),np.zeros(a.dimensions)]
        if a.dimensions==15:
            lower_birth=np.zeros(a.dimensions);lower_birth[5]=math.log(160./180.);population.append(lower_birth)
            gap=np.zeros(a.dimensions);gap[14]=.25;population.append(gap)
        population.extend(np.clip(center+rng.normal(size=a.dimensions)*deviation,-.65,.65) for _ in range(a.size-len(population)))
        seeds=tuple(range(3*round_id+1,3*round_id+4)) if a.rotate_seeds else (1,2,3)
        block=f'DEV{round_id+1}_' if a.rotate_seeds and round_id else ''
        labels=[f'{block}{a.prefix}_r{round_id:02d}_c{i:02d}' for i in range(len(population))]
        jobs=[(label,seed,weights.tolist(),a.policy) for label,weights in zip(labels,population) for seed in seeds]
        results={label:{} for label in labels}
        with ProcessPoolExecutor(max_workers=a.workers) as pool:
            pending=[pool.submit(evaluate,job) for job in jobs]
            for future in as_completed(pending):
                label,seed,r=future.result();results[label][seed]=r
                print(json.dumps(dict(event='evolution_finished',label=label,seed=seed,survival=r['survival_seconds'])),flush=True)
        ranked=[]
        for i,label in enumerate(labels):
            rr=results[label];times=[rr[s]['survival_seconds'] for s in seeds]
            score=(statistics.mean(times)+.25*min(times))/1.25+200.*sum(rr[s]['completed'] for s in seeds)
            item=dict(label=label,seeds=seeds,weights=population[i].tolist(),times=times,mean=statistics.mean(times),objective=score)
            ranked.append((score,i));archive.append(item)
        ranked.sort(reverse=True)
        if a.rotate_seeds or ranked[0][0]>best:best=ranked[0][0];champion=population[ranked[0][1]].copy()
        elite=np.array([population[i] for score,i in ranked[:max(3,a.size//3)]])
        center=.6*elite.mean(axis=0)+.4*center
        deviation=np.maximum(.06,.7*elite.std(axis=0)+.3*deviation)
        checkpoint=dict(round_completed=round_id,utc=datetime.now(timezone.utc).isoformat(),
                        champion=champion.tolist(),best_objective=best,center=center.tolist(),deviation=deviation.tolist(),archive=archive)
        path=ROOT/'campaign'/f'{a.prefix}_checkpoint.json'
        path.write_text(json.dumps(checkpoint,indent=2))
        print(json.dumps(dict(event='evolution_round',**checkpoint)),flush=True)


if __name__=='__main__':main()
