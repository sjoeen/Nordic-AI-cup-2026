import argparse
from campaign_runner import run

p=argparse.ArgumentParser();p.add_argument('seed',type=int);a=p.parse_args()
cases=[
 ('care_slide',{'migration_slide':True}),
 ('care_food',{'migration_food':100.}),
 ('care_hunger',{'hunger_allocation':True}),
 ('care_retarget',{'retarget_ratio':.5}),
 ('care_birth',{'birth_food_gate':True}),
]
for label,config in cases:run(a.seed,'care_policy:CarePolicy',config,label)
