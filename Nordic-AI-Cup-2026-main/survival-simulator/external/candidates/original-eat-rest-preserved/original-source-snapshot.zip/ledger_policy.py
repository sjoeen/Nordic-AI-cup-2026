"""Public-observation energy ledger; does not change baseline actions."""
import math
from collections import Counter
from dispersal_policy import DispersalPolicy


class LedgerPolicy(DispersalPolicy):
    def __init__(self, **config):
        config.setdefault('dispersal_distance',100.)
        super().__init__(**config)
        self.ledger_previous={}

    def decide_all(self,states,sim_time=None):
        if sim_time is not None and sim_time<self.clock:self.ledger_previous.clear()
        for s in states:
            p=self.ledger_previous.get(s['agent_id'])
            if p:
                old,cost,mode=p
                residual=s['energy']-old+cost
                if residual>5.:
                    self.metrics['ledger_intake_'+mode]+=residual
                    self.metrics['ledger_meals_'+mode]+=1
                elif residual<-.05:
                    self.metrics['ledger_unexplained_loss_'+mode]+=-residual
        actions=super().decide_all(states,sim_time)
        byid={s['agent_id']:s for s in states};previous={}
        for a in actions:
            s=byid[a.agent_id];mode=getattr(self.memory[a.agent_id],'last_mode','UNKNOWN')
            distance=min(a.move_distance,s['sprint_speed'] if s['energy']>.2*s['max_energy'] else s['speed'])
            motor=.05*min(distance,s['speed'])+.5*max(0.,distance-s['speed'])
            turn=min(math.pi,abs(a.turn_angle))/(2*math.pi)
            birth=100.*a.spawn_agent
            prefix='ledger_'+mode+'_'
            for name,value in [('ticks',1),('move',motor),('turn',turn),('living',.1),('birth',birth),
                               ('energy_sum',s['energy']),('vision_sum',s['vision_range']),('hearing_sum',s['hearing_radius']),
                               ('speed_sum',s['speed']),('young',s['age']<30.)]:
                self.metrics[prefix+name]+=value
            if s['energy']>180.:
                self.metrics['ledger_birth_eligible_energy']+=1
                self.metrics['ledger_birth_actual']+=a.spawn_agent
            previous[a.agent_id]=(s['energy'],motor+turn+.1+birth,mode)
        self.ledger_previous=previous
        return actions
