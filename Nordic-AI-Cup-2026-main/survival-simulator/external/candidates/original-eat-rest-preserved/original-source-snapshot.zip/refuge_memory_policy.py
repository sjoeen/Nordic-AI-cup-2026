from refuge_policy import RefugePolicy
from memory_policy import MemoryPolicy
from path_policy import PathPolicy


class RefugeMemory(RefugePolicy,MemoryPolicy):
    def __init__(self,preset='refuge_memory',**overrides):
        config=dict(wall_follow=False,stuck_recovery=False,fruit_memory_seconds=10.,stale_correction=True)
        config.update(overrides)
        super().__init__(preset,**config)


class RefugePath(RefugePolicy,PathPolicy):
    def __init__(self,preset='refuge_path',**overrides):
        config=dict(wall_follow=False,stuck_recovery=False,fruit_memory_seconds=10.,stale_correction=True)
        config.update(overrides)
        super().__init__(preset,**config)
