"""Keep loose birth frequency; rank eligible parents by offspring usefulness."""
import math
from harvest_policy import HarvestPolicy


class EfficientBreedingPolicy(HarvestPolicy):
    def __init__(self, preset='efficient_breeding', **overrides):
        config = dict(birth_energy=135.,birth_floor=112.,maximum_birth_gap=20.,
                      offspring_selection='capacity',capacity_exponent=.75)
        config.update(overrides)
        super().__init__(preset, **config)
        self.breeding_views = {}

    def allocate(self, views):
        super().allocate(views)
        self.breeding_views = views

    def parent_value(self, s):
        walk = max(.1,min(s['speed'],s['sprint_speed']))
        capacity = max(100.,s['max_energy'])
        fertile = min(1.,max(.01,(capacity-110.)/80.))
        base = walk+.015*s['hearing_radius']+.003*s['vision_range']
        mode = self.config['offspring_selection']
        if mode=='newborn_sprint':
            # Offspring start with 75 energy. The engine permits sprinting
            # at 20% capacity, and this controller retains 5 extra energy.
            # Thus a capacity below 350 lets a newborn sprint immediately.
            bonus = 1.+2./(1.+math.exp(max(-20.,min(20.,(capacity-350.)/40.))))
            return base*bonus*fertile
        if mode=='balanced':
            return (min(walk,18.)**.7 * max(.1,s['vision_range']/200.)**.6 *
                    max(.1,s['hearing_radius']/50.)**.4 * (375./max(160.,capacity))**.5 * fertile)
        return base*(375./max(160.,capacity))**self.config['capacity_exponent']*fertile

    def decide_all(self, states, sim_time=None):
        actions = super().decide_all(states,sim_time)
        original = {a.agent_id for a in actions if a.spawn_agent}
        normal = self.spawn_ids & original
        if not normal:
            return actions
        emergency = original-normal
        c = self.config
        cap = max(c['population_floor'],round(c['population']*.5**(self.clock/c['population_decay'])))
        young = sum(s['age']<c['young_age'] for s in states)
        candidates = []
        by_action = {a.agent_id:a for a in actions}
        for aid,v in self.breeding_views.items():
            s = v['state']
            if aid in emergency or aid in self.retired_ids:
                continue
            threshold = max(c['birth_floor'],min(c['birth_energy'],.75*s['max_energy']))
            if s['age']>60. and young<max(2,cap//2):
                threshold = min(threshold,160.)
            safe = not v['predators'] or min(p['obs']['distance'] for p in v['predators'])>130.
            if not safe or s['energy']<=threshold:
                continue
            a = by_action[aid]
            cost = .05*min(a.move_distance,s['speed'])+.5*max(0.,a.move_distance-s['speed'])+min(math.pi,abs(a.turn_angle))/(2*math.pi)
            if s['energy']-cost<=100.:
                continue
            candidates.append((self.parent_value(s),s['energy'],-aid,aid))
        if len(candidates)<len(normal):
            return actions
        chosen = {row[-1] for row in sorted(candidates,reverse=True)[:len(normal)]}
        for a in actions:
            a.spawn_agent = a.agent_id in chosen or a.agent_id in emergency
        assert sum(a.spawn_agent for a in actions)==len(original)
        self.metrics['parent_selection_changes'] += len(normal-chosen)
        return actions
