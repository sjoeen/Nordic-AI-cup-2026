"""Infer aging from public energy changes and test generation replacement."""
import math
from care_policy import CarePolicy


class MetabolicPolicy(CarePolicy):
    def __init__(self,preset='metabolic',**overrides):
        config=dict(inferred_retirement=False,convert_old_energy=False,deathbed_birth=False,
                    old_birth_cap=10,old_food_min_young=2)
        config.update(overrides);super().__init__(preset,**config)

    def observe(self,state):
        old=self.memory.get(state['agent_id'])
        residual=state['energy']-getattr(old,'care_energy',state['energy'])+getattr(old,'care_cost',0.)
        view=super().observe(state);mem=view['mem']
        if state['age']>60. and -.015*state['age']<residual<-.005*state['age']:
            mem.aging_evidence=getattr(mem,'aging_evidence',0)+1
            if mem.aging_evidence>=2 and not getattr(mem,'metabolic_old',False):
                mem.metabolic_old=True;self.metrics['detected_aging']+=1
        return view

    def allocate(self,views):
        c=self.config
        if c['inferred_retirement']:
            young=sum(not getattr(v['mem'],'metabolic_old',False) and v['state']['age']<65. and v['state']['energy']>100. for v in views.values())
            if young>=c['old_food_min_young']:
                for v in views.values():
                    if getattr(v['mem'],'metabolic_old',False):
                        v['resting']=True;v['eligible']=False
                        self.metrics['inferred_retirement_ticks']+=1
        super().allocate(views)

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time);byid={s['agent_id']:s for s in states}
        births=sum(a.spawn_agent for a in actions)
        for a in actions:
            s=byid[a.agent_id];mem=self.memory[a.agent_id]
            if a.spawn_agent:continue
            cost=mem.care_cost
            if s['energy']<112.+cost:continue
            preds=[o['distance'] for o in s['observations'] if o['type']=='Predator']
            distance=min(preds,default=math.inf)
            convert=self.config['convert_old_energy'] and getattr(mem,'metabolic_old',False) and distance>80. and len(states)+births<self.config['old_birth_cap']
            insure=self.config['deathbed_birth'] and distance<45. and (len(states)<4 or s['age']>65.)
            if convert or insure:
                a.spawn_agent=True;births+=1;mem.care_cost+=100.
                self.metrics['old_energy_births' if convert else 'deathbed_births']+=1
        return actions
