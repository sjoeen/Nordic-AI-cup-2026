"""Avoid unnecessary final approach and energy death before fruit collection."""
import math
from care_policy import CarePolicy
from species_field_trial import unit,wrap


class PrecisionFood(CarePolicy):
    def __init__(self,preset='precision_food',**overrides):
        config=dict(precision_stop=6.,guaranteed_ghost_filter=False,action_budget=False,food_gaze_saving=False)
        config.update(overrides);super().__init__(preset,**config)

    def observe(self,state):
        v=super().observe(state)
        if self.config['guaranteed_ghost_filter']:
            # Every fruit starts with radius >=5, every agent has radius 5.
            # These observations were taken before automatic fruit collection.
            v['fruits']=[f for f in v['fruits'] if f['obs']['distance']>=10.]
        return v

    def steer(self,view):
        a=super().steer(view);s,mem=view['state'],view['mem'];c=self.config
        target=view['visible'].get(mem.target_id)
        if target is None or mem.last_mode!='EAT':return a
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        if c['precision_stop']!=6.:
            distance=min(s['speed'],s['sprint_speed'],max(0.,target['obs']['distance']-c['precision_stop'])/terrain)
            direction,_=self.slide(unit(target['p']),view,distance)
            a.move_distance=distance;a.move_direction=math.atan2(direction[1],direction[0])
        if c['food_gaze_saving'] and target['obs']['distance']<min(30.,s['hearing_radius']) and not view['predators']:
            a.turn_angle=0.
        mem.last_move=(a.move_distance*terrain*math.cos(a.move_direction),a.move_distance*terrain*math.sin(a.move_direction))
        mem.last_turn=a.turn_angle
        if a.move_distance:mem.search_heading=wrap(mem.heading+a.move_direction)
        return a

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time)
        if not self.config['action_budget']:return actions
        byid={s['agent_id']:s for s in states}
        for a in actions:
            s=byid[a.agent_id];mem=self.memory[a.agent_id]
            budget=max(0.,s['energy']-.101-100.*a.spawn_agent)
            turn_cost=min(math.pi,abs(a.turn_angle))/(2*math.pi)
            if turn_cost>budget:
                a.turn_angle=math.copysign(budget*2*math.pi,a.turn_angle);turn_cost=budget
            motor_budget=max(0.,budget-turn_cost)
            speed=s['speed']
            maximum=motor_budget/.05 if motor_budget<=speed*.05 else speed+(motor_budget-speed*.05)/.5
            if a.move_distance>maximum:
                a.move_distance=maximum;self.metrics['energy_budget_interventions']+=1
            terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
            mem.last_move=(a.move_distance*terrain*math.cos(a.move_direction),a.move_distance*terrain*math.sin(a.move_direction))
            mem.last_turn=a.turn_angle
            mem.care_cost=.1+.05*min(a.move_distance,speed)+.5*max(0.,a.move_distance-speed)+turn_cost+100.*a.spawn_agent
        return actions
