"""Return promptly from river terrain using the last observed productive bank."""
import math
from dispersal_policy import DispersalPolicy
from species_field_trial import rotate,wrap,unit


class RiverPolicy(DispersalPolicy):
    def __init__(self,preset='river',**overrides):
        config=dict(dispersal_distance=100.,river_memory=8.,river_filter=True)
        config.update(overrides);super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        for attr in ('safe_bank','river_line'):
            p=getattr(mem,attr,None)
            if p is not None:
                q=rotate(p,-mem.last_turn)
                setattr(mem,attr,(q[0]-view['translation'][0],q[1]-view['translation'][1]))
        if getattr(mem,'river_normal',None) is not None:mem.river_normal=rotate(mem.river_normal,-mem.last_turn)
        if state['biome']=='river':
            if getattr(mem,'previous_biome','river')!='river' and getattr(mem,'safe_bank',None) is not None:
                mem.river_line=mem.safe_bank;mem.river_normal=unit((-mem.safe_bank[0],-mem.safe_bank[1]))
                mem.river_until=self.clock+self.config['river_memory']
            if getattr(mem,'safe_bank',None) is not None:mem.returning_to_bank=True
        else:
            mem.safe_bank=(0.,0.)
            if getattr(mem,'returning_to_bank',False) and getattr(mem,'river_normal',None) is not None:
                mem.search_heading=wrap(mem.heading+math.atan2(mem.river_normal[1],mem.river_normal[0])+(1. if state['agent_id']%2 else -1.)*math.pi/2)
            mem.returning_to_bank=False
        mem.previous_biome=state['biome']
        return view

    def shared_frames(self,views):
        super().shared_frames(views)
        if not self.config['river_filter']:return
        for view in views.values():
            mem=view['mem']
            if self.clock>=getattr(mem,'river_until',-1.) or getattr(mem,'river_line',None) is None:continue
            if math.hypot(*mem.river_line)>160.:continue
            p=mem.river_line;n=mem.river_normal
            view['fruits']=[f for f in view['fruits'] if f['obs']['distance']<20. or (f['p'][0]-p[0])*n[0]+(f['p'][1]-p[1])*n[1]<5.]

    def allocate(self,views):
        for view in views.values():
            if view['state']['biome']=='river' and getattr(view['mem'],'safe_bank',None) is not None:
                view['max_fruit_distance']=18.;view['resting']=False
        super().allocate(views)

    def steer(self,view):
        action=super().steer(view);s,mem=view['state'],view['mem']
        if s['biome']!='river' or view['escaping'] or getattr(mem,'safe_bank',None) is None:return action
        if mem.target_id is not None:return action
        goal=mem.safe_bank
        if any(math.hypot(e['p'][0]-goal[0],e['p'][1]-goal[1])<80. for e in view['predators']):return action
        speed=min(s['speed'],s['sprint_speed'],(math.hypot(*goal)+8.)/.3)
        direction,_=self.slide(unit(goal),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0]);action.turn_angle=action.move_direction
        mem.last_move=tuple(v*speed*.3 for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.last_mode='RIVER_RETURN'
        self.metrics['river_return_ticks']+=1
        return action
