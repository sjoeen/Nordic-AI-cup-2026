"""Extract a tested policy and its bases into a standalone HTTP agent."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import zipfile

SOURCES=['species_field_trial.py','strategy_lab.py','atlas_policy.py','mpc_policy.py','habitat_policy.py',
         'lineage_policy.py','nursery_policy.py','safety_policy.py','adaptive_policy.py','alarm_policy.py',
         'camp_policy.py','refuge_policy.py','island_policy.py','sticky_policy.py','memory_policy.py',
         'path_policy.py','refuge_memory_policy.py','dispersal_policy.py','foraging_policy.py','colonize_navigation.py','river_policy.py','hybrid_policy.py','accessible_policy.py','mapped_colony.py','decoy_policy.py','portfolio_policy.py']
SOURCES += ['generation_policy.py','harvest_policy.py','nurture_policy.py','food_map_policy.py',
            'orchard_policy.py','appetite_policy.py','efficient_breeding.py','food_search_policy.py']
REGISTRY={'portfolio':'PortfolioPolicy','decoy':'DecoyPolicy','mapped_colony':'MappedColony','learning_colony':'LearningColony','accessible':'AccessiblePolicy','hybrid':'HybridPolicy','river':'RiverPolicy','recover':'RecoverPolicy','colonize_memory':'ColonizeMemory','colonize_path':'ColonizePath','refuge':'RefugePolicy','safety':'SafetyPolicy','adaptive':'AdaptivePolicy','lineage':'LineagePolicy',
          'foraging':'ForagingPolicy','dispersal':'DispersalPolicy','refuge_memory':'RefugeMemory',
          'refuge_path':'RefugePath','path':'PathPolicy','memory':'MemoryPolicy','sticky':'StickyPolicy',
          'islands':'IslandPolicy','camp':'CampPolicy','alarm':'AlarmPolicy','nursery':'NurseryPolicy',
          'nursery_lineage':'NurseryLineage','habitat':'HabitatPolicy','atlas':'AtlasPolicy','mapped':'MappedPolicy'}
REGISTRY.update(generation='GenerationPolicy',harvest='HarvestPolicy',nurture='NurturePolicy',
                food_map='FoodMapPolicy',mapped_harvest='MappedHarvestPolicy',orchard='OrchardPolicy',
                appetite='AppetitePolicy',efficient_breeding='EfficientBreedingPolicy',food_search='FoodSearchPolicy')

SERVER='''
from threading import RLock
from fastapi import Body, FastAPI

app = FastAPI(title="Survival Agent")
_lock = RLock()
_policy = make_policy()
_last_time = None
_last_signature = None
_last_response = None
_largest_id = -1

@app.post("/predict")
def predict(step: StepResponse = Body(...)):
    global _policy, _last_time, _last_signature, _last_response, _largest_id
    with _lock:
        signature = json.dumps(step.model_dump(), sort_keys=True, separators=(",", ":"))
        if signature == _last_signature:
            return _last_response
        supplied_time = step.sim_time if "sim_time" in step.model_fields_set else None
        # Some clients serialize the DTO's default zero on every step.
        if supplied_time == 0.0 and any(a.age > 0.0 for a in step.agent_status):
            supplied_time = None
        current_ids = {a.agent_id for a in step.agent_status}
        live_before = set(getattr(_policy, "memory", {}))
        ids_restarted = bool(current_ids and live_before and not current_ids & live_before
                             and min(current_ids) < _largest_id)
        if ids_restarted or (_last_time is not None and supplied_time is not None and supplied_time < _last_time):
            _policy = make_policy()
            _largest_id = -1
        if step.game_status != "ok" or not step.agent_status:
            _policy = make_policy()
            _largest_id = -1
            response = {"actions": []}
        else:
            states = [agent.model_dump() for agent in step.agent_status]
            response = {"actions": [a.model_dump() for a in _policy.decide_all(states, supplied_time)]}
            _largest_id = max(_largest_id, max(current_ids))
        _last_time = supplied_time
        _last_signature = signature
        _last_response = response
        return response

@app.get("/")
def index():
    return {"status": "ok", "strategy": STRATEGY_NAME}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9052)
'''

def build(preset,config,destination):
    classes={};functions={};constants={}
    for filename in ['src/utils/DTOs.py','src/utils/controllers/potential_field_policy.py']+SOURCES:
        source=Path(filename).read_text();tree=ast.parse(source)
        for node in tree.body:
            if isinstance(node,ast.ClassDef):
                text=ast.get_source_segment(source,node)
                if node.name=='Memory':text='@dataclass\n'+text
                classes[node.name]=(node,text)
            elif isinstance(node,ast.FunctionDef):functions[node.name]=ast.get_source_segment(source,node)
            elif isinstance(node,ast.Assign):
                for target in node.targets:
                    if isinstance(target,ast.Name):constants[target.id]=ast.get_source_segment(source,node)
    selected=REGISTRY.get(preset,'SurvivalPolicy')
    order=[]
    def add(name):
        if name in order:return
        node,_=classes[name]
        for base in node.bases:
            if isinstance(base,ast.Name) and base.id in classes:add(base.id)
        order.append(name)
    for name in ('ActionRequest','ObservationResponse','StepResponse','Memory',selected):add(name)
    header='''"""Tested observation-only controller. No simulator or hidden-world imports."""
import heapq
import json
import math
import random
import statistics
from collections import Counter,defaultdict,deque
from dataclasses import dataclass,field
from typing import List,Dict
from math import atan2,cos,hypot,pi,sin
from pydantic import BaseModel
'''
    helper_names=['wrap','closest_point','rotate','unit','point','point_segment','segment_clear']
    if 'SafetyPolicy' in order:helper_names+=['chase_step','resolve_motion']
    pieces=[header]+[constants[n] for n in ('VARIANTS','PRESETS','QUALITY')]
    pieces += [functions[n] for n in helper_names]
    pieces += [classes[n][1] for n in order]
    pieces += [f'STRATEGY_NAME = {preset!r}',f'CONFIG = json.loads({json.dumps(config)!r})',
               f'def make_policy():\n    return {selected}({preset!r}, **CONFIG)',SERVER]
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    code='\n\n'.join(pieces)+'\n'
    ast.parse(code)
    (destination/'survival_agent.py').write_text(code)
    (destination/'requirements-agent.txt').write_text('fastapi==0.121.2\npydantic==2.12.4\nuvicorn==0.38.0\n')
    return destination/'survival_agent.py'

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--preset',required=True)
    parser.add_argument('--config',default='{}')
    parser.add_argument('--destination',required=True)
    args=parser.parse_args()
    result=build(args.preset,json.loads(args.config),args.destination)
    print(result)
