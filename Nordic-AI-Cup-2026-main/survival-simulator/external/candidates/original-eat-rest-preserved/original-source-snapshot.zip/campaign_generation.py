import sys
from campaign_runner import run

CASES=[
 ('generation_linear55',{'generation_mode':'linear','generation_fraction':.55}),
 ('generation_linear70',{'generation_mode':'linear','generation_fraction':.7}),
 ('generation_energy',{'generation_mode':'energy'}),
 ('generation_elders',{'elder_birth_priority':True}),
 ('generation_spacing5',{'birth_spacing':5.}),
 ('generation_gap20',{'maximum_birth_gap':20.}),
 ('generation_young45',{'young_age':45.}),
 ('generation_young80',{'young_age':80.}),
]
if __name__=='__main__':
    for label,config in CASES:run(int(sys.argv[1]),'generation_policy:GenerationPolicy',config,label)
