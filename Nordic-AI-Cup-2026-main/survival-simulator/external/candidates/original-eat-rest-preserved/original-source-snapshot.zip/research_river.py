import sys
from research_runner import run
seed=int(sys.argv[1])
for label,config in [('river_avoidance',{}),('river_return_only',{'river_filter':False}),('river_sensory',{'quality_mode':'sensory','fitness_population':True,'population':10,'population_floor':3})]:
 run(seed,'river',dict(label=label,**config),log=f'research_river_{seed}.jsonl')
