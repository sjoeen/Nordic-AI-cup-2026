# One-hour hybrid reinforcement learning follow-up

Budget:2026-09-18 21:14:52–22:14:52 UTC. Original preserved baseline and all
previous outputs retained. The first hybrid mean was1360.6s versus1779.3s for
the baseline, a23.5% decrease, despite a small win on seed2.

All performance games use the unchanged normal stock simulator, original world
size, starting populations/resources, timestep and3000-second/extinction horizon.
They run through the stock HTTP client and actual `/predict` endpoint. Source
checks guard engine and candidate bytes. The existing user-authorized DTO defaults
remain the sole historical engine-source exception. No hidden engine state is
given to any controller. At most two simulation workers run simultaneously.

## Hypotheses and candidates

1. **movement_only:** Reuse the original frozen learned Q table, but remove
   stationary scanning from its action set. Require5 samples for baseline and
   selected action, plus0.1 estimated advantage. No new training. This checks
   whether eliminating repeated waiting salvages useful movement choices.
2. **foraging_3:** New tabular Q learner after three normal training games.
3. **foraging_6:** The same learner after six normal training games.
4. **forest_6**, if time permits: fit a tree-based Q approximator to exactly the
   same six-game experience. This tests generalization between similar states
   without spending time on more simulator training episodes.
5. **adaptive_6**, only if time remains for a complete comparison: initialize
   from the six-game table and update it during the current game. Action choice
   remains greedy with the same support/advantage guards and no random
   exploration. Each game resets to the same pretrained model. This is an
   explicitly adaptive submission, not a frozen-model evaluation. It uses only
   public observations that are available in the real submission API.

Each frozen candidate is compared on seeds1,2,3 against the existing saved
baseline scores1887.8/1618.9/1831.2. No routine baseline reruns. Training seeds
are7–12. These evaluation seeds were used earlier in the project and are not
untouched validation data. Process-sensitive engine predator-distance tie ordering
is a known source of numerical variation, so small changes are exploratory.

## Fixed controller boundaries

The baseline computes every action first, including its emergency birth
action-cost checks. The learner can change only safe, fruitless SEARCH movement.
No observed predator or fruit, no active rest, no retirement, no newborn dispersal,
and no requested birth may be overridden. Training starts at600s to collect more
experience; frozen evaluation starts at900s to retain original early behavior.
This changes the training controller, never the simulation or its horizon.

The options are40% walking speed (baseline),20%,70%, and a stationary scan.
Turns and birth flags stay unchanged. Food or predator observations interrupt an
option immediately. A scan is available only with energy>=100, a tree within100,
and at least6 seconds since the previous scan started. It lasts at most1 second.
Thus the learner cannot choose uninterrupted waiting. Normal wall sliding and
trait-aware movement bounds remain in place.

## Learning changes

State: energy bins<75/75–150/>=150; age<60/>=60; tree within100; slow terrain;
walking speed<12/>=12; fruitless duration<3s/>=3s; and scan availability.
The final two features distinguish a new search from a prolonged failure to
find food and make the scan cooldown visible to the learner.

Reward: public energy change/50, correcting the baseline parent's100-energy
birth cost and then charging the species'25-energy net birth loss. There is
a0.01-per-second time penalty,0.5 bonus for an inferred meal, an additional1.0
for a first meal before age30, and0.5 for reaching age30. An observed predator
ends the option with a0.25 penalty; disappearance gives a3-point terminal penalty.
Food is inferred from public energy changes plus known action/living costs;
hidden aging losses make this a conservative proxy, not exact food-energy truth.
The first-meal bonus means the first detected meal after observation begins;
food eaten before a newborn's first observation can be missed by that reward.
Offspring diagnostics separately count elevated initial energy as an inferred
immediate meal. Reward and diagnostic meal counts are therefore not identical.

Unlike the first hybrid, waiting without food has negative immediate reward.
Credit ends at an actual meal, observed threat, baseline rest/retirement takeover,
or8-second timeout. This avoids blaming a search action for an aging death long
after it found food. Ordinary consecutive search decisions use elapsed-time
discount0.99 per second and online Q learning rate0.1. Training exploration is0.5
for the first three episodes and0.3 for the last three. Twelve offline replay
passes use only collected normal-game transitions, with learning rate0.05.

Evaluation freezes learning. A non-baseline action needs at least5 completed
examples for itself and the baseline action in that state, and estimated
advantage>=0.1. This is a support guard, not a statistical safety guarantee.

## Optional fitted-Q trees

The tree variant uses16 fitted-Q iterations,32 ExtraTrees per action, maximum
depth5 and minimum leaf size8. Future values are clipped to[-5,5] during fitting.
At inference it needs8 observations for each compared action in the coarser
five-feature state, and an advantage greater than0.15 after subtracting half
the combined tree standard deviation. The dispersion penalty is a heuristic,
not a calibrated confidence interval or formal safe-improvement guarantee.

Trees are exported to pure-Python arrays and checked against the training
library's predictions. The submission does not require scikit-learn or NumPy.
Food targets, escape, reproduction, and the bounded search action set are the
same as for the new tabular learner.

## Integrity and interruptions

Two initial games were interrupted by an execution-runtime disconnect at about
300 seconds, before either learner activated. Their partial logs remain in
runs/. They have no completed result and are excluded. Only those unfinished
games were restarted, in runs_recovered/, with the same frozen controllers.
Completed games are never silently substituted or discarded.

Controller-only checks verify protected modes, immediate escape interruption,
negative fruitless reward, feeding terminal credit, and the scan cooldown.
These checks are not counted as simulation results.

Optional variants queue behind locks for the same two server ports. These locks
only serialize test processes and do not alter requests, actions, or game logic.
Scheduling amendment at21:56 UTC: the adaptive comparison was queued in the
newly free worker slot with18 minutes remaining, while the primary comparison
continued. The same two-port locks enforce the concurrency limit. Per-case
locks and source-hash checks reuse any already queued/completed case, so an
earlier coordinator's later request cannot repeat or overwrite a game.
This changes scheduling only. Untested or incomplete drafts are not scored.

## Primary references

- [Safe Policy Improvement with Baseline Bootstrapping](https://arxiv.org/abs/1712.06924)
  motivates falling back to an existing controller where data are weak. Our
  count/advantage guards do not inherit that paper's formal guarantees.
- [Tree-Based Batch Mode Reinforcement Learning](https://www.jmlr.org/papers/v6/ernst05a.html)
  describes fitting Q functions from recorded transitions using tree ensembles.
- [ExtraTreesRegressor documentation](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.ExtraTreesRegressor.html)
  supplies the training API; installed version1.8.0 was checked locally.
