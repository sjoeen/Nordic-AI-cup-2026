#!/usr/bin/env bash
# Usage from package root: bash slurm/submit_round.sh runs/experiment 0 32
# Select account/partition using your site's SBATCH_ACCOUNT/SBATCH_PARTITION
# environment variables or edit the corresponding .sbatch templates.
set -euo pipefail
run_path="${1:?Provide the initialized run directory}"
round_number="${2:?Provide a round number, starting at 0}"
parallel_jobs="${3:-32}"
python_binary="${PYTHON_BIN:-python3}"
plan_path="$("$python_binary" cluster.py plan-round --run "$run_path" --round "$round_number")"
job_count="$("$python_binary" -c 'import json,sys; print(len(json.load(open(sys.argv[1]))["jobs"]))' "$plan_path")"
last_index="$((job_count - 1))"
rollout_job="$(sbatch --parsable --array="0-${last_index}%${parallel_jobs}" slurm/rollout.sbatch "$plan_path")"
rollout_job="${rollout_job%%;*}"
merge_job="$(sbatch --parsable --dependency="afterok:${rollout_job}" slurm/merge.sbatch "$plan_path")"
printf 'Rollout array: %s\nMerge job: %s\nPlan: %s\n' "$rollout_job" "$merge_job" "$plan_path"
