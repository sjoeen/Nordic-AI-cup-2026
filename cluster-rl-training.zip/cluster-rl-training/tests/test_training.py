"""Controller/replay tests. Synthetic inputs here are never scored as games."""
from pathlib import Path
import copy
import importlib.util
import json
import math
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cluster
from common import ROOT, build_source, digest, read_json, setup_simulator, write_json, write_new

KEY = '1:0:0:0:0:0:0'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class TrainingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        setup_simulator()

    def test_seed_ranges_are_exclusive_and_unique(self):
        self.assertEqual(cluster.seeds('1000:1003,1100'), [1000, 1001, 1002, 1100])
        for bad in ('1,1', '-1', '5:3', '4294967296'):
            with self.assertRaises(ValueError):
                cluster.seeds(bad)

    def test_holdout_overlap_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaises(ValueError):
                cluster.initialize(root, [1000], [1000], [3000])
            with self.assertRaises(ValueError):
                cluster.initialize(root, [1000], [1], [3000])

    def test_export_recreates_tested_six_game_agent(self):
        source, settings = build_source(read_json(ROOT / 'warm_start/model.json'))
        self.assertEqual(source, (ROOT / 'warm_start/tested_agent.py').read_text())
        self.assertFalse(settings['training'])
        self.assertEqual(settings['epsilon'], 0.)

    def test_replay_counts_each_example_once(self):
        initial = dict(q={KEY: [0.] * 4}, counts={KEY: [100, 40, 20, 0]})
        examples = [[KEY, 0, 1., 0., None], [KEY, 1, 2., 0., None]]
        learned = cluster.replay(initial, examples, passes=20, alpha=1.)
        self.assertEqual(learned['counts'][KEY], [101, 41, 20, 0])
        self.assertEqual(learned['q'][KEY][:2], [1., 2.])
        self.assertEqual(initial['counts'][KEY], [100, 40, 20, 0])

    def test_unavailable_scan_is_excluded_from_bootstrap(self):
        model = dict(q={KEY: [0., 2., 1., 99999.]}, counts={KEY: [1] * 4})
        learned = cluster.replay(model, [[KEY, 0, 0., 1., KEY]], passes=1, alpha=1.)
        self.assertEqual(learned['q'][KEY][0], 2.)

    def test_bad_transition_is_rejected(self):
        for row in ([KEY, 3, 0., 0., None], [KEY, 0, float('nan'), 0., None],
                    [KEY, 0, 1., .9, None]):
            with self.assertRaises(ValueError):
                cluster.replay(dict(q={}, counts={}), [row])

    def test_immutable_writes(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'model.json'
            write_json(path, {'a': 1})
            write_json(path, {'a': 1})
            with self.assertRaises(ValueError):
                write_json(path, {'a': 2})

    def test_incomplete_round_and_eval_merge_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            run = cluster.initialize(folder, [1000], [2000], [3000])
            path = cluster.make_plan(run, number=0)
            with self.assertRaisesRegex(ValueError, 'Incomplete round'):
                cluster.merge(path)
            evaluation = cluster.make_plan(run, checkpoint=run / 'checkpoints/initial.json', split='validation')
            with self.assertRaisesRegex(ValueError, 'Evaluation experience'):
                cluster.merge(evaluation)

    def test_repeated_merge_does_not_double_count(self):
        with tempfile.TemporaryDirectory() as folder:
            run = cluster.initialize(folder, [1000], [2000], [3000], scratch=True)
            path = cluster.make_plan(run, number=0)
            plan = read_json(path)
            job = plan['jobs'][0]
            attempt = path.parent / 'jobs' / job['job_id'] / 'attempt_0001'
            write_json(attempt / 'result.json', dict(seed=1000, alive=0, survival_seconds=1.,
                       sources_unchanged=True, transitions=1, rl_stats={'q_updates': 1}))
            write_json(attempt / 'transitions.json', [[KEY, 0, 1., 0., None]])
            write_json(attempt.parent / 'done.json', dict(job=job, plan_sha256=digest(path),
                       attempt=attempt.name, hashes={name: digest(attempt / name) for name in
                                                   ('result.json', 'transitions.json')}))
            first = cluster.merge(path)
            before = digest(first)
            self.assertEqual(cluster.merge(path), first)
            self.assertEqual(digest(first), before)
            self.assertEqual(read_json(first)['model']['counts'][KEY], [1, 0, 0, 0])
            write_new(attempt / 'tampered.txt', 'This is an isolated unit-test fixture, not a game.')


class ControllerGuards(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = load(ROOT / 'policy/baseline.py', '_test_base')
        cls.hybrid = load(ROOT / 'warm_start/tested_agent.py', '_test_hybrid')

    def states(self, energy=100., age=20., observations=None, population=5):
        return [dict(agent_id=i, energy=energy, age=age, observations=observations or [],
                     speed=10., sprint_speed=20., max_energy=500., hearing_radius=50.,
                     vision_range=200., vision_angle=math.pi / 3., biome='forest')
                for i in range(population)]

    def test_original_modes_remain_protected(self):
        cases = [('early', 100., {}), ('rest', 1000., {'energy': 300.}),
                 ('newborn', 1000., {'age': .1, 'energy': 75.}),
                 ('birth', 1000., {'energy': 125., 'population': 2}),
                 ('fruit', 1000., {'observations': [dict(type='Fruit', distance=40., angle=.1)]}),
                 ('predator', 1000., {'observations': [dict(type='Predator', distance=40., angle=.1, rel_dir=0.)]})]
        for name, clock, kwargs in cases:
            with self.subTest(case=name):
                base, hybrid = self.base.make_policy(), self.hybrid.make_policy()
                hybrid.rl_choose = lambda key: 2
                states = self.states(**kwargs)
                a = base.decide_all(copy.deepcopy(states), clock)
                b = hybrid.decide_all(copy.deepcopy(states), clock)
                self.assertEqual([x.model_dump() for x in a], [x.model_dump() for x in b])

    def test_predator_interrupts_learned_movement(self):
        hybrid = self.hybrid.make_policy()
        hybrid.rl_choose = lambda key: 2
        hybrid.decide_all(self.states(), 1000.)
        hybrid.decide_all(self.states(age=20.1, observations=[dict(type='Predator', distance=40., angle=0., rel_dir=0.)]), 1000.1)
        self.assertTrue(all(m.last_mode == 'CROWD_ESCAPE' for m in hybrid.memory.values()))
        self.assertEqual(hybrid.rl_stats['threat_terminal_options'], 5)


if __name__ == '__main__':
    unittest.main()
