"""Portable files, immutable models, and the preserved submission builder."""
from contextlib import contextmanager
from pathlib import Path
import ast
import fcntl
import hashlib
import json
import math
import os
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
BASELINE_SHA = '79069207333851ea391b4ed4e30e459bef980790f3c4390a6363d020ad83555f'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def value_hash(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def write_new(path, data):
    """Atomic publication; an existing immutable file must have identical bytes."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = data.encode() if isinstance(data, str) else data
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError(f'Refusing to overwrite different contents: {path}')
        return
    fd, temp = tempfile.mkstemp(prefix=path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        try:
            os.link(temp, path)  # publish without replacing a concurrent writer
        except FileExistsError:
            if path.read_bytes() != data:
                raise ValueError(f'Conflicting concurrent write: {path}')
    finally:
        os.unlink(temp)


def write_json(path, value):
    write_new(path, json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


@contextmanager
def lock(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        yield


def validate_model(model):
    if set(model) != {'q', 'counts'} or set(model['q']) != set(model['counts']):
        raise ValueError('Model requires matching q/counts state keys')
    for key, values in model['q'].items():
        validate_state(key)
        counts = model['counts'][key]
        if len(values) != 4 or len(counts) != 4:
            raise ValueError('Each state requires four actions')
        if any(not isinstance(x, (int, float)) or not math.isfinite(x) for x in values):
            raise ValueError('Nonfinite Q value')
        if any(type(x) is not int or x < 0 for x in counts):
            raise ValueError('Counts must be nonnegative integers')
    return model


def validate_state(key):
    if not isinstance(key, str):
        raise ValueError('Invalid state')
    bits = key.split(':')
    if len(bits) != 7 or bits[0] not in ('0', '1', '2') or any(x not in ('0', '1') for x in bits[1:]):
        raise ValueError(f'Invalid state: {key}')


def allowed(key):
    return range(4) if key.endswith(':1') else range(3)


def build_source(model, *, training=False, learner_seed=123001, epsilon=0.0, start_time=None):
    validate_model(model)
    baseline = (ROOT / 'policy/baseline.py').read_text()
    if digest(ROOT / 'policy/baseline.py') != BASELINE_SHA:
        raise ValueError('Preserved baseline has changed')
    settings = read_json(ROOT / 'policy/settings.json')
    settings.update(training=training, epsilon=epsilon if training else 0., random_seed=learner_seed,
                    start_time=(600. if training else 900.) if start_time is None else start_time)
    insertion = 'RL_SETTINGS = ' + repr(settings) + '\nRL_MODEL = ' + repr(model) + '\n\n'
    insertion += (ROOT / 'policy/hybrid.py').read_text() + '\n\n'
    insertion += (ROOT / 'policy/foraging.py').read_text()
    insertion += "\n\ndef make_policy():\n    return ForagingRLPolicy('appetite', **CONFIG)"
    marker = "def make_policy():\n    return AppetitePolicy('appetite', **CONFIG)"
    if baseline.count(marker) != 1:
        raise ValueError('Baseline insertion point is ambiguous')
    source = baseline.replace(marker, insertion)
    ast.parse(source)
    return source, settings


def code_fingerprint():
    files = ('common.py', 'cluster.py', 'episode.py', 'policy/baseline.py', 'policy/hybrid.py',
             'policy/foraging.py', 'policy/settings.json', 'vendor/previous_runner.py',
             'vendor/survival-simulator.zip', 'requirements.txt')
    return value_hash({name: digest(ROOT / name) for name in files})


def expected_simulator():
    with zipfile.ZipFile(ROOT / 'vendor/survival-simulator.zip') as archive:
        result = {}
        for name in archive.namelist():
            if name.endswith('/'):
                continue
            parts = Path(name).parts
            if not parts or parts[0] != 'survival-simulator' or '..' in parts:
                raise ValueError('Unexpected simulator archive path')
            relative = Path(*parts[1:])
            data = archive.read(name)
            if str(relative) == 'src/utils/DTOs.py':
                text = data.decode()
                text = text.replace('    sim_time: float\n', '    sim_time: float = 0.0\n')
                text = text.replace('    n_agents: int\n', '    n_agents: int = 0\n')
                data = text.encode()
            result[str(relative)] = data
        return result


def setup_simulator():
    repo = ROOT / 'simulator'
    with lock(ROOT / '.setup.lock'):
        for relative, data in expected_simulator().items():
            write_new(repo / relative, data)
    return check_simulator()


def check_simulator():
    repo = ROOT / 'simulator'
    expected = expected_simulator()
    for relative, data in expected.items():
        path = repo / relative
        if not path.exists() or path.read_bytes() != data:
            raise ValueError(f'Simulator differs from packaged source: {relative}; run setup first')
    extra = set(str(p.relative_to(repo)) for p in repo.rglob('*.py')) - set(expected)
    if extra:
        raise ValueError(f'Unexpected simulator Python sources: {sorted(extra)}')
    return value_hash({name: hashlib.sha256(data).hexdigest() for name, data in expected.items()})
