"""One original, full-length game; the simulator talks to the actual HTTP app."""
from pathlib import Path
import contextlib
import importlib.util
import json
import os
import socket
import sys
import threading
import time
from common import ROOT, build_source, check_simulator, digest, read_json, write_json, write_new


def import_file(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run_episode(plan, job, output, model):
    for name, value in {'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
                        'MKL_NUM_THREADS': '1', 'PYGAME_HIDE_SUPPORT_PROMPT': '1',
                        'SDL_VIDEODRIVER': 'dummy', 'SDL_AUDIODRIVER': 'dummy'}.items():
        os.environ[name] = value
    import requests
    import uvicorn
    sys.path.insert(0, str(ROOT / 'simulator'))
    from simulation_server import run_local_game
    previous = import_file(ROOT / 'vendor/previous_runner.py', '_public_observer_helpers')
    simulator_hash = check_simulator()
    if simulator_hash != plan['simulator_fingerprint']:
        raise ValueError('Simulator changed after this plan was created')
    training = plan['kind'] == 'train'
    if plan['controller'] == 'baseline':
        source = (ROOT / 'policy/baseline.py').read_text()
        settings = None
    else:
        source, settings = build_source(model, training=training, learner_seed=job['learner_seed'],
                                        epsilon=plan['epsilon'], start_time=600. if training else 900.)
    candidate = output / 'survival_agent.py'
    write_new(candidate, source)
    candidate_hash = digest(candidate)
    agent = import_file(candidate, '_cluster_submission')
    observer = previous.PublicObserver(agent.app)
    # Bind before starting Uvicorn. The socket remains owned, so parallel jobs
    # cannot race between finding and claiming an unused port.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    sock.listen(1024)
    port = sock.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(observer, host='127.0.0.1', port=port,
                                         access_log=False, log_level='error'))
    thread = threading.Thread(target=server.run, kwargs={'sockets': [sock]}, daemon=True)
    thread.start()
    log = None
    started = time.perf_counter()
    try:
        deadline = time.monotonic() + 30.
        while not server.started:
            if not thread.is_alive() or time.monotonic() > deadline:
                raise RuntimeError('Agent HTTP server did not start')
            time.sleep(.05)
        response = requests.get(f'http://127.0.0.1:{port}/', timeout=5.)
        response.raise_for_status()
        metadata = dict(seed=job['seed'], kind=plan['kind'], settings=settings,
                        source_sha256=candidate_hash, simulator_fingerprint=simulator_hash,
                        game_overrides={}, transport='stock run_local_game -> HTTP POST /predict',
                        horizon='Original extinction or time > 3000 loop',
                        world=dict(width=1600, height=1200, starting_agents=5,
                                   starting_trees=50, starting_fruits=32, starting_predators=0, dt=.1),
                        dto_patch='Only the user-authorized sim_time/n_agents defaults',
                        python=sys.version, port=port)
        write_json(output / 'metadata.json', metadata)
        terminal = sys.stdout
        log = previous.StockLog(output / 'stock_stdout.log', job['seed'], terminal, observer)
        with contextlib.redirect_stdout(log):
            run_local_game(f'http://127.0.0.1:{port}/predict', seed=job['seed'])
        if log.error or log.last is None:
            raise RuntimeError(log.error or 'Stock simulator produced no result')
        if not (log.last['alive'] == 0 or log.last['survival_seconds'] > 3000.):
            raise RuntimeError('Incomplete game; no training data will be committed')
        extinct = log.last['alive'] == 0
        if extinct:
            observer.observe(dict(agent_status=[], sim_time=log.last['survival_seconds']))
        policy = agent._policy
        transitions, rl_stats = [], {}
        if plan['controller'] != 'baseline':
            policy.rl_finish(extinct)
            exported = policy.rl_export()
            transitions, rl_stats = policy.rl_transitions, exported['stats']
            if not training:
                if transitions or rl_stats.get('q_updates', 0):
                    raise RuntimeError('Evaluation unexpectedly performed learning')
                for key, q in model['q'].items():
                    if exported['q'][key] != q or exported['counts'][key] != model['counts'][key]:
                        raise RuntimeError('Frozen evaluation modified its input model')
        if digest(candidate) != candidate_hash or check_simulator() != simulator_hash:
            raise RuntimeError('Source changed during the game')
        result = dict(seed=job['seed'], **log.last, peak_agents=log.peak,
                      survived_full_horizon=not extinct,
                      observed_newborns=len(observer.newborns),
                      newborns_observed_reaching_age30=len(observer.reached30),
                      newborns_lost_before_observed_age30=len(observer.lost_before30),
                      prediction_requests=observer.requests,
                      maximum_request_seconds=max(observer.latencies, default=0.),
                      wall_seconds=time.perf_counter() - started,
                      source_sha256=candidate_hash, sources_unchanged=True,
                      simulator_fingerprint=simulator_hash,
                      rl_stats=rl_stats, transitions=len(transitions))
        write_json(output / 'transitions.json', transitions)
        write_json(output / 'result.json', result)
        return result
    finally:
        if log is not None:
            log.file.close()
        server.should_exit = True
        thread.join(timeout=15.)
        sock.close()
