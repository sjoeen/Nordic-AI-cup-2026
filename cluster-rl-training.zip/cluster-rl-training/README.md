# Parallel training for the preserved eat/rest hybrid

This is the **existing six-game tabular Q-learning experiment**, packaged for
many CPU workers and multiple cluster nodes. It starts from the tested model
that averaged **1,673.3 seconds** on development seeds 1–3. The original eat/rest
baseline averaged **1,779.3 seconds**. More training is an experiment, not a
demonstrated route to 3,000 seconds.

**One shared learner receives experience from many parallel games.** This is
not a collection of independent models whose scores are averaged. Workers
start each round from the same checkpoint, collect complete episodes, then a
single reducer learns from all their transitions. The next round receives
that updated checkpoint.

This learner needs **CPUs, not GPUs**. It is a small Q table, not PPO or a neural
network. A cluster speeds up simulation experience collection. It does not
expand the learner's state or action space automatically.

## What is fixed

- Original game size, initial populations/resources, timestep and complete
  extinction-or-3,000-second horizon. No shortened training worlds.
- Actual stock `simulation_server.run_local_game` and HTTP `/predict` requests.
- The only original-engine file difference is the already authorized DTO fix:
  `sim_time: float = 0.0` and `n_agents: int = 0`.
- The exact saved eat/rest baseline, including its reproduction and escape
  rules. RL can change only eligible, fruitless SEARCH movement.
- No observed predator, observed fruit, active rest, newborn dispersal,
  retirement or requested birth may be overridden.
- Four choices: baseline movement, 20% walking speed, 70% walking speed, or a
  bounded stationary scan. Food destinations and reproduction are not learned.
- Training activates after 600 simulation seconds; frozen evaluation after
  900, matching the preceding experiment. This changes the controller only.
- The exported submission has no trainer, model-server or simulator dependency.

The preserved reward, features and guard values are documented in
`PRIOR_METHOD.md`, `policy/settings.json` and the two extension files under
`policy/`. `policy/baseline.py` is hash-checked before building a controller.

## Install once on a Linux cluster

Use Python **3.12**, which was used for the verified package. Place the package
and its output directory on a filesystem shared by the worker nodes. The
filesystem must support POSIX file locks and atomic hard-link publication.
All nodes need the same code, Python dependencies and shared paths.

```bash
cd cluster-rl-training
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python cluster.py setup
python -m unittest discover -s tests -v
```

`setup` extracts the supplied original simulator and applies only the two DTO
defaults. It refuses to overwrite a different existing engine. Workers verify
the engine before and after each game. Source fingerprints also stop a run if
its training code changes between rounds.

## Start with a manageable pilot

Seed ranges are **start-inclusive, stop-exclusive**: `1000:1064` means 64 seeds.
Comma-separated values and ranges are accepted. These are example splits,
not special easy seeds. Set aside seeds nobody has used to choose this policy
if your other experiments have already used these examples.

```bash
python cluster.py init --run runs/pilot \
  --train-seeds 1000:1064 \
  --validation-seeds 2000:2016 \
  --test-seeds 3000:3032
```

This starts from `warm_start/model.json`, the six-game model. Use
`--from-scratch` at initialization for a separate experiment. The default
training exploration probability is 0.3; it is fixed in the run's config.
Evaluation and export always disable exploration and learning.

Do not put **every seed** into training. Here 64 training seeds produce
experience, 16 validation seeds guide checkpoint selection, and 32 final-test
seeds remain unused until one model has been selected. The tool rejects
overlap. Historical seeds 0–19 are also rejected as fresh holdouts.

## One large CPU node

```bash
python cluster.py train --run runs/pilot --rounds 3 --workers 16
```

This runs 64 games per round, with up to 16 games concurrently, and merges
after each round. `--rounds 3` means three total rounds, including any already
completed. Run the same command again to resume. Completed games and merges
are verified and reused. Incomplete games restart from their original seed;
their previous attempts stay on disk. There is no mid-game state recovery.

Start with 8–16 workers and check your node's CPU/RAM use before increasing.
The supplied Slurm template requests one CPU and 2 GiB per game as a starting
allocation, not a measured worst-case guarantee. Limit workers to your actual
allocation. No GPU allocation is needed.

## Multiple nodes with Slurm

Submit from the package directory after activating the environment. Set your
site's account/partition options as required. `PYTHON_BIN` can name an absolute
Python executable visible on every node.

```bash
export PYTHON_BIN="$PWD/.venv/bin/python"
bash slurm/submit_round.sh runs/pilot 0 32
```

This submits one array element per training seed, limits concurrency to 32,
and schedules the reducer after every element succeeds. Once the reducer
finishes, submit round 1, then round 2:

```bash
bash slurm/submit_round.sh runs/pilot 1 32
# Wait for round 1's merge before submitting round 2.
bash slurm/submit_round.sh runs/pilot 2 32
```

If an array task fails because of a node interruption or resource limit,
resubmitting the same round reuses its completed games and retries unfinished
ones. Cancel the old merge job if Slurm leaves it pending with an unsatisfied
dependency; the resubmission creates a new dependent merge job.

For another scheduler, launch this command once per index, with indexes
`0` through `len(plan["jobs"])-1`. Each command owns one full game:

```bash
python cluster.py plan-round --run runs/pilot --round 0
python cluster.py worker --plan /absolute/path/to/rounds/0000/plan.json --index 0
# After ALL indexes finish successfully:
python cluster.py merge --plan /absolute/path/to/rounds/0000/plan.json
```

Slurm arrays, concurrency limits and whole-array dependencies follow the
[official Slurm job-array documentation](https://slurm.schedmd.com/job_array.html).
The Slurm templates are supplied for your scheduler; their submission has not
been exercised on your cluster.

## Evaluate without training on the evaluation seeds

Run the original baseline **once on the new validation seeds**, then reuse
those results for each frozen checkpoint. The previous 1–3 baseline scores
cannot serve as paired results for seeds 2000–2015.

```bash
BASE_PLAN=$(python cluster.py plan-eval --run runs/pilot --split validation --baseline)
python cluster.py run --plan "$BASE_PLAN" --workers 16

MODEL_PLAN=$(python cluster.py plan-eval --run runs/pilot --split validation \
  --checkpoint runs/pilot/checkpoints/round_0002.json)
python cluster.py run --plan "$MODEL_PLAN" --workers 16
python cluster.py summary --plan "$MODEL_PLAN" --baseline-plan "$BASE_PLAN"
```

These evaluation plans can also be submitted as Slurm arrays using
`slurm/rollout.sbatch`, with one array index per listed job. They require no
merge. The reducer explicitly rejects validation and test experience.

The summary includes mean, median, worst survival, full-horizon completions,
per-seed times and paired differences. Training rewards or training survival
are not sufficient evidence of improvement. Select a checkpoint on validation,
then repeat this comparison with `--split test` once. Repeated tuning on that
test set turns it into another validation set.

The original engine has process-sensitive predator-distance tie ordering.
Identical seeds can therefore differ across execution contexts. Leave the
engine untouched; treat tiny differences cautiously, and confirm promising
gains across more seeds before declaring success.

## Export the submission

```bash
python cluster.py export \
  --checkpoint runs/pilot/checkpoints/round_0002.json \
  --output exports/round_0002
```

This creates `survival_agent.py`, `requirements-agent.txt` and provenance in
`export.json`. The submission is a frozen standalone FastAPI app, matching the
existing submission interface. For a local endpoint:

```bash
cd exports/round_0002
python -m uvicorn survival_agent:app --host 0.0.0.0 --port 8000
```

Export does not automatically replace your baseline. Keep a model only if its
normal-game validation supports that decision. Send back the paired summaries
and the chosen checkpoint JSON to continue analysis.

## How parallel learning differs from the preceding six-game run

The state, actions, reward, protected cases and inference guards are unchanged.
The collection/training schedule changes:

1. Every worker starts a round from the same immutable shared checkpoint.
   During its training game it explores and performs the existing local online
   Q updates. Those updates influence that worker's subsequent actions.
2. Workers emit raw `[state, action, reward, discount, next_state]` transitions.
   Their final Q tables are **not** averaged.
3. One reducer starts from the parent shared model and replays the new round's
   transitions in reproducibly shuffled order: 12 passes, learning rate 0.05.
4. Each real transition increases the shared support count exactly once.
   Parent support counts are included once, not once per worker or replay pass.
5. The resulting checkpoint initializes every worker in the next round.

The reducer uses this round's new transitions. It does not automatically replay
all earlier rounds again. Workers from the same round do not exchange updates
mid-game. This synchronization trades some policy freshness for straightforward,
auditable parallel collection. It will not reproduce the prior sequential
six-game training trajectory, even on identical seeds.

`vendor/previous_runner.py` supplies only its transparent HTTP observer and
stock-output parser. Its historical default candidate path is not used; the
active controller is built exclusively from the hash-checked
`policy/baseline.py` and the selected checkpoint.

Checkpoints, plans, source hashes and completed attempts are immutable.
`done.json` is written only after a whole game and all artifacts succeed.
Interrupted attempts retain `FAILED.txt` when the process can report the error.
Hard-killed attempts may lack that file but still lack `done.json` and are not
merged. A missing job blocks the merge, so failed or short games are not silently
discarded from the training batch. Resume after fixing resource limits or an
external interruption. Fixing code requires a new run directory.

## Limits of this experiment

The learner still sees a coarse seven-feature state and controls search pace.
It has no learned food-destination choice, long-term food supply estimate or
reproduction policy. More data may improve its choices, but cannot eliminate
those structural limitations. First-meal rewards and energy-death diagnostics
are public-observation proxies. The baseline-fallback count and advantage
thresholds are heuristics, not formal safe-improvement guarantees.

If a substantially larger training pilot fails to improve frozen validation,
stop scaling this exact learner. Its representation or decision scope may need
to change. Do not spend a large cluster allocation solely because training
reward increases.

See `VERIFICATION.md` for the package checks actually completed, and
`PRIOR_RESULTS.md` for the original three-seed comparisons.
