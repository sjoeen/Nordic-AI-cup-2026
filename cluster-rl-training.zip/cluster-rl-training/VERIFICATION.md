# Package verification

Eleven unit/controller tests passed. They cover protected baseline modes, immediate predator interruption, exact reconstruction of the tested six-game agent, seed separation, invalid transitions, immutable writes, replay support counts, excluded scan actions, rejection of incomplete/evaluation merges, and idempotent merging.

Two full normal games ran concurrently through the original stock HTTP client. Each owned a separately bound socket. A completed worker was requested again and reused its result without restarting the game.

| Purpose | Seed | Survival seconds | New training transitions |
|---|---:|---:|---:|
| Training pipeline check | 1000 | 1278.7 | 931 |
| Training pipeline check | 1001 | 1408.7 | 806 |
| Frozen runtime check | 2000 | 1229.7 | 0 |

The reducer consumed 1,737 transitions and increased support counts from 4,960 to 6,697. Repeating the merge left the checkpoint hash unchanged. It did not multiply inherited counts by the worker count or replay count.

The merged model was exported and evaluated on a separate seed. Frozen evaluation performed zero learning updates and preserved all learned values and support counts. Generated controllers differ in the unused evaluation-only learner RNG seed; the frozen action selector uses no RNG. The exported model and evaluation model otherwise share the same settings and weights.

All three games retained the original world and full extinction-or-3,000-second horizon. Engine files were checked before and after each game. Only the previously authorized DTO defaults differ from the supplied simulator archive. No hidden engine state was provided to the controller.

These runs verify the training pipeline. There is no baseline comparison on these new seeds, so their survival times do not establish a performance improvement. The two-game verification checkpoint is included as an example; normal initialization still starts from the previously tested six-game checkpoint.

The Slurm scripts passed shell syntax checking. Actual scheduler submission, filesystem behavior and resource allocation must be confirmed on the destination cluster.

Verification outputs are in verification_smoke/. The simulator can be reconstructed using python cluster.py setup. Original earlier outputs remain unchanged.
