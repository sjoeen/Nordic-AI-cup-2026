#!/usr/bin/env python3
"""Shared replay from parallel normal games; no simulation shortcuts."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import copy
import json
import math
import os
import random
import signal
import statistics
import subprocess
import sys
import threading
import time
import traceback
import uuid
from common import (ROOT, allowed, build_source, canonical, check_simulator, code_fingerprint,
                    digest, lock, read_json, setup_simulator, validate_model, validate_state,
                    value_hash, write_json, write_new)


def seeds(text):
    values = []
    for token in text.split(','):
        token = token.strip()
        if ':' in token:
            start, stop = map(int, token.split(':'))
            if not 0 <= start < stop <= 2**32 or stop - start > 100000:
                raise ValueError('Invalid or excessively large seed range')
            values.extend(range(start, stop))
        else:
            values.append(int(token))
    if not values or len(values) != len(set(values)) or any(x < 0 or x >= 2**32 for x in values):
        raise ValueError('Seeds must be distinct integers in [0, 2**32)')
    return values


def initialize(run, training, validation, test, epsilon=.3, scratch=False):
    if not 0 <= epsilon <= 1:
        raise ValueError('epsilon must be in [0,1]')
    sets = [set(x) for x in (training, validation, test)]
    if any(sets[i] & sets[j] for i in range(3) for j in range(i)):
        raise ValueError('Training, validation and test seeds overlap')
    # These seeds have already informed this project and its warm-start policy.
    if (sets[1] | sets[2]) & set(range(20)):
        raise ValueError('Seeds 0–19 are historical development seeds, not fresh holdouts')
    run = Path(run).resolve()
    with lock(run / '.initialize.lock'):
        config = dict(schema=1, train_seeds=training, validation_seeds=validation,
                      test_seeds=test, epsilon=epsilon, start_from_scratch=scratch,
                      policy='preserved eat/rest + bounded foraging search-speed RL',
                      train_start_time=600., evaluation_start_time=900.,
                      historical_development_seeds=list(range(20)),
                      code_fingerprint=code_fingerprint(), simulator_fingerprint=check_simulator())
        write_json(run / 'config.json', config)
        model = dict(q={}, counts={}) if scratch else read_json(ROOT / 'warm_start/model.json')
        validate_model(model)
        checkpoint = dict(schema=1, round=-1, model=model, lineage=[],
                          training_seeds=[] if scratch else list(range(7, 13)),
                          added_transitions=0, total_new_transitions=0,
                          provenance='empty model' if scratch else 'tested six-game model, seeds 7–12')
        write_json(run / 'checkpoints/initial.json', checkpoint)
    return run


def campaign(run):
    run = Path(run).resolve()
    config = read_json(run / 'config.json')
    if config['code_fingerprint'] != code_fingerprint():
        raise ValueError('Training code changed since initialization; start a new run')
    if config['simulator_fingerprint'] != check_simulator():
        raise ValueError('Simulator source differs from this run')
    return run, config


def checkpoint_path(run, number):
    return run / 'checkpoints' / ('initial.json' if number == -1 else f'round_{number:04d}.json')


def make_plan(run, *, number=None, checkpoint=None, split=None, baseline=False):
    run, config = campaign(run)
    training = split is None
    if training:
        if number is None or number < 0:
            raise ValueError('Round must be nonnegative')
        checkpoint = checkpoint_path(run, number - 1)
        if not checkpoint.exists():
            raise ValueError('Merge the previous round before planning this one')
        if read_json(checkpoint)['round'] != number - 1:
            raise ValueError('Wrong parent checkpoint round')
        folder = run / 'rounds' / f'{number:04d}'
        selected = config['train_seeds']
        label = f'train_r{number:04d}'
    else:
        if split not in ('validation', 'test'):
            raise ValueError('Evaluation split must be validation or test')
        if baseline:
            checkpoint = None
            label = split + '_baseline'
        else:
            checkpoint = Path(checkpoint).resolve()
            label = split + '_' + checkpoint.stem + '_' + digest(checkpoint)[:10]
        folder = run / 'evaluations' / label
        selected = config[split + '_seeds']
    checkpoint = Path(checkpoint).resolve() if checkpoint else None
    if checkpoint:
        data = read_json(checkpoint)
        validate_model(data['model'])
        holdouts = set(config['validation_seeds'] + config['test_seeds'])
        if set(data['training_seeds']) & holdouts:
            raise ValueError('Checkpoint training seeds overlap a holdout split')
    jobs = []
    for index, seed in enumerate(selected):
        learner_seed = int(value_hash([label, seed, 43521])[:8], 16)
        jobs.append(dict(index=index, seed=seed, learner_seed=learner_seed,
                         job_id=f'{label}_seed_{seed}'))
    plan = dict(schema=1, kind='train' if training else split, controller='baseline' if baseline else 'hybrid',
                round=number if training else None, epsilon=config['epsilon'] if training else 0.,
                run_root=os.path.relpath(run, folder), config_sha256=digest(run / 'config.json'),
                checkpoint=os.path.relpath(checkpoint, folder) if checkpoint else None,
                checkpoint_sha256=digest(checkpoint) if checkpoint else None,
                code_fingerprint=config['code_fingerprint'], simulator_fingerprint=config['simulator_fingerprint'],
                jobs=jobs)
    path = folder / 'plan.json'
    write_json(path, plan)
    return path


def load_plan(path):
    path = Path(path).resolve()
    plan = read_json(path)
    run, config = campaign(path.parent / plan['run_root'])
    if digest(run / 'config.json') != plan['config_sha256'] or plan['code_fingerprint'] != code_fingerprint():
        raise ValueError('Plan configuration or code changed')
    model = None
    if plan['checkpoint']:
        checkpoint = path.parent / plan['checkpoint']
        if digest(checkpoint) != plan['checkpoint_sha256']:
            raise ValueError('Input checkpoint changed')
        model = validate_model(read_json(checkpoint)['model'])
    return path, plan, run, model


def completed(path, plan, job):
    folder = path.parent / 'jobs' / job['job_id']
    marker = folder / 'done.json'
    if not marker.exists():
        return None
    done = read_json(marker)
    if done['plan_sha256'] != digest(path) or done['job'] != job:
        raise ValueError('Completed job belongs to a different plan')
    attempt = folder / done['attempt']
    for filename, expected in done['hashes'].items():
        if digest(attempt / filename) != expected:
            raise ValueError(f'Completed output changed: {attempt / filename}')
    result = read_json(attempt / 'result.json')
    if result['seed'] != job['seed'] or not result['sources_unchanged']:
        raise ValueError('Result identity/integrity mismatch')
    if result['alive'] != 0 and result['survival_seconds'] <= 3000.:
        raise ValueError('Result is not a complete normal game')
    return attempt, result


def worker(path, index):
    from episode import run_episode
    path, plan, run, model = load_plan(path)
    if index < 0 or index >= len(plan['jobs']):
        raise ValueError('Worker index outside plan')
    job = plan['jobs'][index]
    folder = path.parent / 'jobs' / job['job_id']
    with lock(folder / '.worker.lock'):
        done = completed(path, plan, job)
        if done:
            print(json.dumps(dict(event='completed_job_reused', seed=job['seed'])), flush=True)
            return done[1]
        existing = [int(p.name.split('_')[1]) for p in folder.glob('attempt_*') if p.is_dir()]
        attempt = folder / f'attempt_{max(existing, default=0) + 1:04d}'
        attempt.mkdir()
        try:
            result = run_episode(plan, job, attempt, model)
            if digest(path) != value_hash_bytes_plan(path, plan):
                raise ValueError('Plan changed while game was running')
            hashes = {name: digest(attempt / name) for name in
                      ('result.json', 'transitions.json', 'metadata.json', 'survival_agent.py')}
            write_json(folder / 'done.json', dict(job=job, plan_sha256=digest(path),
                       attempt=attempt.name, hashes=hashes))
            print(json.dumps(dict(event='completed', job=job['job_id'], survival=result['survival_seconds'],
                                  transitions=result['transitions'])), flush=True)
            return result
        except BaseException:
            write_new(attempt / 'FAILED.txt', traceback.format_exc())
            raise


def value_hash_bytes_plan(path, plan):
    # Plans use write_json's stable encoding, so an in-memory copy detects edits.
    import hashlib
    data = json.dumps(plan, indent=2, sort_keys=True, allow_nan=False) + '\n'
    return hashlib.sha256(data.encode()).hexdigest()


def replay(model, transitions, *, passes=12, alpha=.05, rng_seed=17483):
    """Merge raw experiences, never worker Q tables or inherited visit counts."""
    if passes < 1 or not 0 < alpha <= 1:
        raise ValueError('Invalid replay settings')
    result = copy.deepcopy(validate_model(model))
    for row in transitions:
        if len(row) != 5:
            raise ValueError('Malformed transition')
        key, action, reward, discount, nxt = row
        validate_state(key)
        if type(action) is not int or action not in allowed(key):
            raise ValueError('Invalid transition action')
        if not math.isfinite(reward) or not math.isfinite(discount) or not 0 <= discount <= 1:
            raise ValueError('Invalid reward/discount')
        if nxt is not None:
            validate_state(nxt)
        elif discount != 0:
            raise ValueError('Terminal transition must have zero discount')
        for state in (key, nxt):
            if state is not None:
                result['q'].setdefault(state, [0.] * 4)
                result['counts'].setdefault(state, [0] * 4)
        result['counts'][key][action] += 1  # exactly once, independent of replay passes
    indices = list(range(len(transitions)))
    rng = random.Random(rng_seed)
    for epoch in range(passes):
        rng.shuffle(indices)
        for index in indices:
            key, action, reward, discount, nxt = transitions[index]
            future = max(result['q'][nxt][a] for a in allowed(nxt)) if nxt is not None else 0.
            q = result['q'][key]
            q[action] += alpha * (reward + discount * future - q[action])
    return validate_model(result)


def merge(path, *, passes=12, alpha=.05):
    path, plan, run, model = load_plan(path)
    if plan['kind'] != 'train':
        raise ValueError('Evaluation experience must never be merged into training')
    target = checkpoint_path(run, plan['round'])
    with lock(run / '.merge.lock'):
        parent = read_json(path.parent / plan['checkpoint'])
        plan_hash = digest(path)
        if plan_hash in parent['lineage']:
            raise ValueError('This round was already consumed by its parent')
        rows, records = [], []
        for job in plan['jobs']:
            done = completed(path, plan, job)
            if done is None:
                raise ValueError(f'Incomplete round: {job["job_id"]}; rerun missing workers')
            attempt, result = done
            transitions = read_json(attempt / 'transitions.json')
            if len(transitions) != result['transitions'] or len(transitions) != result['rl_stats'].get('q_updates', 0):
                raise ValueError('Transition count mismatch')
            rows.extend(transitions)
            records.append(dict(job_id=job['job_id'], seed=job['seed'], transitions=len(transitions),
                                sha256=digest(attempt / 'transitions.json'), survival=result['survival_seconds']))
        settings = dict(passes=passes, alpha=alpha, rng_seed=17483 + plan['round'])
        if target.exists():
            saved = read_json(target)
            if saved['plan_sha256'] != plan_hash or saved['replay'] != settings or saved['episodes'] != records:
                raise ValueError('Existing checkpoint conflicts with requested merge')
            print(json.dumps(dict(event='checkpoint_reused', checkpoint=str(target))), flush=True)
            return target
        learned = replay(model, rows, **settings)
        checkpoint = dict(schema=1, round=plan['round'], model=learned, plan_sha256=plan_hash,
                          parent_sha256=plan['checkpoint_sha256'], replay=settings, episodes=records,
                          lineage=parent['lineage'] + [plan_hash], added_transitions=len(rows),
                          total_new_transitions=parent['total_new_transitions'] + len(rows),
                          training_seeds=sorted(set(parent['training_seeds']) | {j['seed'] for j in plan['jobs']}),
                          provenance='Shared replay of complete normal training games; inherited counts included once')
        write_json(target, checkpoint)
        print(json.dumps(dict(event='merged', checkpoint=str(target), new_transitions=len(rows),
                              states=len(learned['q']))), flush=True)
        return target


def run_local(path, workers):
    path, plan, _, _ = load_plan(path)
    if workers < 1:
        raise ValueError('workers must be positive')
    active, mutex = set(), threading.Lock()
    logs = path.parent / 'worker_logs'
    logs.mkdir(exist_ok=True)
    def launch(index):
        logpath = logs / f'{index:05d}_{uuid.uuid4().hex}.log'
        with logpath.open('x') as output:
            process = subprocess.Popen([sys.executable, '-u', str(ROOT / 'cluster.py'), 'worker',
                                        '--plan', str(path), '--index', str(index)],
                                       stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
            with mutex:
                active.add(process)
            try:
                code = process.wait()
                if code:
                    raise RuntimeError(f'Worker {index} exited {code}; see {logpath}')
                print(json.dumps(dict(event='worker_finished', index=index, log=str(logpath))), flush=True)
            finally:
                with mutex:
                    active.discard(process)
    pool = ThreadPoolExecutor(max_workers=workers)
    try:
        futures = [pool.submit(launch, j['index']) for j in plan['jobs']
                   if completed(path, plan, j) is None]
        for future in as_completed(futures):
            future.result()
    except BaseException:
        pool.shutdown(wait=False, cancel_futures=True)
        with mutex:
            for process in active:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGTERM)
        raise
    finally:
        pool.shutdown(wait=True, cancel_futures=True)


def summarize(path, baseline_path=None):
    path, plan, _, _ = load_plan(path)
    results = []
    for job in plan['jobs']:
        done = completed(path, plan, job)
        if done is None:
            raise ValueError('Finish every planned game before summarizing')
        results.append(done[1])
    scores = [r['survival_seconds'] for r in results]
    summary = dict(kind=plan['kind'], games=len(scores), mean=statistics.mean(scores),
                   median=statistics.median(scores), minimum=min(scores), maximum=max(scores),
                   full_horizon=sum(r['survived_full_horizon'] for r in results),
                   seeds={str(r['seed']): r['survival_seconds'] for r in results},
                   caveat='Known engine tie-order nondeterminism; seeds do not guarantee identical trajectories.')
    if baseline_path:
        bpath, bplan, _, _ = load_plan(baseline_path)
        if bplan['controller'] != 'baseline' or bplan['kind'] != plan['kind']:
            raise ValueError('Comparator must be a baseline plan on the same split')
        base = summarize(bpath)
        if set(summary['seeds']) != set(base['seeds']):
            raise ValueError('Paired comparisons require identical seeds')
        differences = {s: summary['seeds'][s] - base['seeds'][s] for s in summary['seeds']}
        summary['paired'] = dict(mean_delta=statistics.mean(differences.values()),
                                 seeds_better=sum(v > 0 for v in differences.values()),
                                 baseline_mean=base['mean'], differences=differences)
    return summary


def export(checkpoint, output):
    checkpoint, output = Path(checkpoint).resolve(), Path(output).resolve()
    source, settings = build_source(read_json(checkpoint)['model'])
    write_new(output / 'survival_agent.py', source)
    write_new(output / 'requirements-agent.txt', (ROOT / 'requirements-agent.txt').read_bytes())
    write_json(output / 'export.json', dict(checkpoint_sha256=digest(checkpoint), settings=settings,
               controller_sha256=digest(output / 'survival_agent.py'), learning_enabled=False,
               note='Experimental frozen hybrid; export does not imply it beats baseline.'))
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('setup', help='Unpack and verify the supplied original simulator')
    p = sub.add_parser('init')
    p.add_argument('--run', required=True)
    p.add_argument('--train-seeds', default='1000:1256')
    p.add_argument('--validation-seeds', default='2000:2016')
    p.add_argument('--test-seeds', default='3000:3032')
    p.add_argument('--epsilon', type=float, default=.3)
    p.add_argument('--from-scratch', action='store_true')
    p = sub.add_parser('plan-round')
    p.add_argument('--run', required=True)
    p.add_argument('--round', type=int, required=True)
    p = sub.add_parser('plan-eval')
    p.add_argument('--run', required=True)
    p.add_argument('--split', choices=['validation', 'test'], required=True)
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument('--checkpoint')
    group.add_argument('--baseline', action='store_true')
    p = sub.add_parser('worker')
    p.add_argument('--plan', required=True)
    p.add_argument('--index', type=int, required=True)
    p = sub.add_parser('run')
    p.add_argument('--plan', required=True)
    p.add_argument('--workers', type=int, default=4)
    p = sub.add_parser('merge')
    p.add_argument('--plan', required=True)
    p.add_argument('--passes', type=int, default=12)
    p.add_argument('--alpha', type=float, default=.05)
    p = sub.add_parser('train')
    p.add_argument('--run', required=True)
    p.add_argument('--rounds', type=int, default=1, help='Total rounds, including those already completed')
    p.add_argument('--workers', type=int, default=4)
    p = sub.add_parser('summary')
    p.add_argument('--plan', required=True)
    p.add_argument('--baseline-plan')
    p = sub.add_parser('export')
    p.add_argument('--checkpoint', required=True)
    p.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.command == 'setup':
        print(json.dumps(dict(simulator_fingerprint=setup_simulator())))
    elif args.command == 'init':
        print(initialize(args.run, seeds(args.train_seeds), seeds(args.validation_seeds),
                         seeds(args.test_seeds), args.epsilon, args.from_scratch))
    elif args.command == 'plan-round':
        print(make_plan(args.run, number=args.round))
    elif args.command == 'plan-eval':
        print(make_plan(args.run, checkpoint=args.checkpoint, split=args.split, baseline=args.baseline))
    elif args.command == 'worker':
        worker(args.plan, args.index)
    elif args.command == 'run':
        run_local(args.plan, args.workers)
    elif args.command == 'merge':
        print(merge(args.plan, passes=args.passes, alpha=args.alpha))
    elif args.command == 'train':
        if args.rounds < 1:
            parser.error('--rounds must be positive')
        for number in range(args.rounds):
            path = make_plan(args.run, number=number)
            run_local(path, args.workers)
            merge(path)
    elif args.command == 'summary':
        print(json.dumps(summarize(args.plan, args.baseline_plan), indent=2))
    elif args.command == 'export':
        print(export(args.checkpoint, args.output))


if __name__ == '__main__':
    main()
