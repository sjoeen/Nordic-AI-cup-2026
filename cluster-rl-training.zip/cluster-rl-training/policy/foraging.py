class ForagingRLPolicy(HybridRLPolicy):
    def __init__(self,preset='appetite',**kwargs):
        super().__init__(preset,**kwargs)
        self.rl_last_scan={}
        self.rl_meals=Counter()
        self.rl_foodless_since={}
        self.rl_events=[]
        self.rl_current_key=None

    def rl_state(self,view):
        key=super().rl_state(view)
        if RL_SETTINGS['kind']=='movement_only':
            return key
        aid=view['state']['agent_id']
        long_search=self.clock-self.rl_foodless_since.get(aid,self.clock)>=3.
        scan_ok=self.rl_scan_allowed(view)
        return key+':'+str(int(long_search))+':'+str(int(scan_ok))

    def rl_scan_allowed(self,view):
        s=view['state']
        return (s['energy']>=100. and any(o['type']=='Tree' and o['distance']<100.
                 for o in s['observations']) and
                self.clock-self.rl_last_scan.get(s['agent_id'],-1e9)>=RL_SETTINGS['scan_cooldown'])

    def rl_allowed(self,key):
        if RL_SETTINGS['kind']=='movement_only':return [0,1,2]
        return [0,1,2,3] if key.endswith(':1') else [0,1,2]

    def rl_choose(self,key):
        q,counts=self.rl_row(key);allowed=self.rl_allowed(key)
        if RL_SETTINGS['training']:
            untried=[i for i in allowed if counts[i]==0]
            if untried:return self.rl_rng.choice(untried)
            if self.rl_rng.random()<RL_SETTINGS['epsilon']:return self.rl_rng.choice(allowed)
            return max(allowed,key=lambda i:(q[i],-i))
        minimum=RL_SETTINGS['minimum_visits']
        if counts[0]<minimum:
            self.rl_stats['fallback_unseen_baseline']+=1;return 0
        supported=[i for i in allowed if counts[i]>=minimum]
        best=max(supported,key=lambda i:(q[i],-i))
        return best if q[best]>=q[0]+RL_SETTINGS['advantage_margin'] else 0

    def rl_close(self,aid,next_key=None,death=False):
        if RL_SETTINGS['kind']=='movement_only':
            return super().rl_close(aid,next_key,death)
        p=self.rl_pending.pop(aid,None)
        if p is None:return
        if death:
            p['reward']-=p['discount']*RL_SETTINGS['death_penalty']
            self.rl_stats['credited_deaths']+=1
        key,choice=p['state'],p['choice'];discount=p['discount'] if next_key is not None else 0.
        self.rl_stats['closed_options']+=1
        self.rl_stats['return_sum_'+RL_ACTION_NAMES[choice]]+=p['reward']
        self.rl_stats['return_count_'+RL_ACTION_NAMES[choice]]+=1
        if RL_SETTINGS['training']:
            q,n=self.rl_row(key)
            future=max(self.rl_row(next_key)[0][i] for i in self.rl_allowed(next_key)) if next_key is not None else 0.
            q[choice]+=RL_SETTINGS['alpha']*(p['reward']+discount*future-q[choice]);n[choice]+=1
            self.rl_transitions.append([key,choice,p['reward'],discount,next_key])
            self.rl_stats['q_updates']+=1

    def rl_observe_rewards(self,states):
        if RL_SETTINGS['kind']=='movement_only':
            # Evaluation only. Preserve the old telemetry reward definition.
            return super().rl_observe_rewards(states)
        current={s['agent_id']:s for s in states}
        dt=0. if self.rl_last_time is None else max(0.,self.clock-self.rl_last_time)
        for aid in list(self.rl_pending):
            if aid not in current:self.rl_close(aid,death=True)
        for aid,s in current.items():
            old=self.rl_previous.get(aid);view=self.rl_views[aid]
            self.rl_foodless_since.setdefault(aid,self.clock)
            if view['fruits']:self.rl_foodless_since[aid]=self.clock
            if old is None:continue
            p=self.rl_pending.get(aid)
            corrected=s['energy']-old['energy']+old['birth_cost']
            # Food is inferred from public energy and known action costs. Any
            # hidden aging loss only makes this lower-bound detector conservative.
            meal=corrected+old['action_cost']+max(0.,s['age']-old['age'])>.5
            first_meal=meal and self.rl_meals[aid]==0
            if meal:
                self.rl_meals[aid]+=1;self.rl_foodless_since[aid]=self.clock
            if p is None:continue
            reward=corrected/RL_SETTINGS['energy_reward_scale']
            reward-=.25*old['birth_cost']/RL_SETTINGS['energy_reward_scale']
            reward-=RL_SETTINGS['time_penalty']*dt
            if meal:
                reward+=RL_SETTINGS['meal_bonus'];self.rl_stats['credited_meals']+=1
                if first_meal and s['age']<30.:
                    reward+=RL_SETTINGS['first_meal_bonus'];self.rl_stats['credited_first_meals']+=1
            if old['age']<30.<=s['age']:
                reward+=RL_SETTINGS['young_survival_bonus'];self.rl_stats['credited_age30']+=1
            p['reward']+=p['discount']*reward
            p['discount']*=RL_SETTINGS['gamma_per_second']**dt
            self.rl_stats['reward_observation_steps']+=1
            # End credit at an actual feeding success, observed threat, or long
            # baseline takeover. Do not attribute a later retirement death to a
            # search decision that found food a minute earlier.
            if meal:
                self.rl_close(aid);self.rl_stats['food_terminal_options']+=1
            elif view['predators']:
                p['reward']-=p['discount']*RL_SETTINGS['threat_penalty']
                self.rl_close(aid);self.rl_stats['threat_terminal_options']+=1
            elif view.get('resting') or aid in self.retired_ids:
                self.rl_close(aid);self.rl_stats['baseline_rest_terminal_options']+=1
            elif self.clock-p['started']>=RL_SETTINGS['credit_timeout']:
                self.rl_close(aid);self.rl_stats['credit_timeout_options']+=1
        self.rl_last_time=self.clock

    def decide_all(self,states,sim_time=None):
        old_pending={aid:(p['started'],p['choice']) for aid,p in self.rl_pending.items()}
        actions=super().decide_all(states,sim_time)
        byid={s['agent_id']:s for s in states}
        for aid,p in self.rl_pending.items():
            if p['choice']==3 and old_pending.get(aid)!=(p['started'],p['choice']):
                self.rl_last_scan[aid]=self.clock
        for a in actions:
            s=byid[a.agent_id]
            move=.05*min(a.move_distance,s['speed'])+.5*max(0.,a.move_distance-s['speed'])
            turn=min(math.pi,abs(a.turn_angle))/(2*math.pi)
            self.rl_previous[a.agent_id].update(age=s['age'],action_cost=move+turn)
        return actions
