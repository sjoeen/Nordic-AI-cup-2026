"""Small tabular semi-Markov residual controller; public observations only.

The stock controller computes every action first. Only safe, fruitless SEARCH
movement after 900s is adjustable. Its birth flag and all protected modes survive.
"""

RL_ACTION_NAMES = ('baseline', 'slow_search', 'fast_search', 'scan_in_place')
RL_SPEED_FRACTIONS = (.4, .2, .7, 0.)


class HybridRLPolicy(AppetitePolicy):
    def __init__(self, preset='appetite', **kwargs):
        super().__init__(preset, **kwargs)
        self.rl_q = {k: list(v) for k, v in RL_MODEL.get('q', {}).items()}
        self.rl_counts = {k: list(v) for k, v in RL_MODEL.get('counts', {}).items()}
        self.rl_rng = random.Random(RL_SETTINGS['random_seed'])
        self.rl_pending = {}
        self.rl_previous = {}
        self.rl_views = {}
        self.rl_transitions = []
        self.rl_stats = Counter()
        self.rl_last_time = None

    def allocate(self, views):
        super().allocate(views)
        self.rl_views = views

    def rl_state(self, view):
        s = view['state']
        energy_bin = 0 if s['energy'] < 75. else 1 if s['energy'] < 150. else 2
        near_tree = any(o['type'] == 'Tree' and o['distance'] < 100.
                        for o in s['observations'])
        slow_terrain = s['biome'] in ('swamp', 'river')
        walk = min(s['speed'], s['sprint_speed'])
        return ':'.join(str(int(x)) for x in
                        (energy_bin, s['age'] >= 60., near_tree, slow_terrain, walk >= 12.))

    def rl_eligible(self, view, action):
        s, mem = view['state'], view['mem']
        return (self.clock >= RL_SETTINGS['start_time']
                and mem.last_mode == 'SEARCH'
                and not view['predators'] and not view['fruits']
                and not any(o['type'] == 'Fruit' for o in s['observations'])
                and not view.get('resting') and not view['escaping']
                and not mem.colonist and s['agent_id'] not in self.retired_ids
                and not action.spawn_agent)

    def rl_row(self, key):
        self.rl_q.setdefault(key, [0.] * 4)
        self.rl_counts.setdefault(key, [0] * 4)
        return self.rl_q[key], self.rl_counts[key]

    def rl_choose(self, key):
        q, counts = self.rl_row(key)
        if RL_SETTINGS['training']:
            untried = [i for i, n in enumerate(counts) if n == 0]
            if untried:
                return self.rl_rng.choice(untried)
            if self.rl_rng.random() < RL_SETTINGS['epsilon']:
                return self.rl_rng.randrange(4)
            return max(range(4), key=lambda i: (q[i], -i))
        minimum = RL_SETTINGS['minimum_visits']
        if counts[0] < minimum:
            self.rl_stats['fallback_unseen_baseline'] += 1
            return 0
        supported = [i for i in range(4) if counts[i] >= minimum]
        best = max(supported, key=lambda i: (q[i], -i))
        if q[best] < q[0] + RL_SETTINGS['advantage_margin']:
            return 0
        return best

    def rl_close(self, aid, next_key=None, death=False):
        pending = self.rl_pending.pop(aid, None)
        if pending is None:
            return
        if death:
            pending['reward'] -= pending['discount'] * RL_SETTINGS['death_penalty']
            self.rl_stats['credited_deaths'] += 1
        key, choice = pending['state'], pending['choice']
        discount = 0. if next_key is None else pending['discount']
        reward = pending['reward']
        self.rl_stats['closed_options'] += 1
        self.rl_stats['return_sum_' + RL_ACTION_NAMES[choice]] += reward
        self.rl_stats['return_count_' + RL_ACTION_NAMES[choice]] += 1
        if RL_SETTINGS['training']:
            q, counts = self.rl_row(key)
            future = max(self.rl_row(next_key)[0]) if next_key is not None else 0.
            q[choice] += RL_SETTINGS['alpha'] * (reward + discount * future - q[choice])
            counts[choice] += 1
            self.rl_transitions.append([key, choice, reward, discount, next_key])
            self.rl_stats['q_updates'] += 1

    def rl_observe_rewards(self, states):
        now = self.clock
        current = {s['agent_id']: s for s in states}
        dt = 0. if self.rl_last_time is None else max(0., now - self.rl_last_time)
        for aid, pending in list(self.rl_pending.items()):
            old = self.rl_previous.get(aid)
            if old is None:
                continue
            s = current.get(aid)
            if s is None:
                self.rl_close(aid, death=True)
                continue
            # Birth flags come from the unchanged baseline. Do not punish its
            # reproduction by charging the learner the parent's 100-energy cost.
            corrected_delta = s['energy'] - old['energy'] + old['birth_cost']
            reward = RL_SETTINGS['survival_reward_per_second'] * dt
            reward += corrected_delta / RL_SETTINGS['energy_reward_scale']
            pending['reward'] += pending['discount'] * reward
            pending['discount'] *= RL_SETTINGS['gamma_per_second'] ** dt
            self.rl_stats['reward_observation_steps'] += 1
        self.rl_last_time = now

    def decide_all(self, states, sim_time=None):
        # Running this first preserves all core allocation, escape, rest and
        # reproduction decisions, including emergency-birth action-cost checks.
        actions = super().decide_all(states, sim_time)
        self.rl_observe_rewards(states)
        byid = {s['agent_id']: s for s in states}
        for action in actions:
            aid = action.agent_id
            view = self.rl_views[aid]
            s, mem = view['state'], view['mem']
            pending = self.rl_pending.get(aid)
            if not self.rl_eligible(view, action):
                if pending is not None:
                    pending['interrupted'] = True
                self.rl_stats['protected_ticks'] += 1
                continue
            self.rl_stats['eligible_ticks'] += 1
            if (pending is None or pending['interrupted'] or
                    self.clock - pending['started'] >= RL_SETTINGS['option_seconds'] - 1e-7):
                key = self.rl_state(view)
                if pending is not None:
                    self.rl_close(aid, next_key=key)
                choice = self.rl_choose(key)
                pending = dict(state=key, choice=choice, started=self.clock,
                               reward=0., discount=1., interrupted=False)
                self.rl_pending[aid] = pending
                self.rl_stats['decisions_' + RL_ACTION_NAMES[choice]] += 1
            choice = pending['choice']
            self.rl_stats['ticks_' + RL_ACTION_NAMES[choice]] += 1
            if choice == 0:
                continue
            speed = min(s['speed'], s['sprint_speed']) * RL_SPEED_FRACTIONS[choice]
            desired = (math.cos(action.move_direction), math.sin(action.move_direction))
            desired, _ = self.slide(desired, view, speed)
            action.move_distance = speed
            action.move_direction = math.atan2(desired[1], desired[0])
            # Keep baseline scanning/turn and the baseline spawn flag exactly.
            terrain = {'river': .3, 'swamp': .5, 'desert': .8}.get(s['biome'], 1.)
            mem.last_move = (speed * terrain * desired[0], speed * terrain * desired[1])
            mem.last_turn = action.turn_angle
            if speed > 0.:
                mem.search_heading = wrap(mem.heading + action.move_direction)
            mem.last_mode = 'RL_' + RL_ACTION_NAMES[choice].upper()
            self.rl_stats['modified_ticks'] += 1
        self.rl_previous = {}
        for action in actions:
            s = byid[action.agent_id]
            move = action.move_distance
            move_cost = .05 * min(move, s['speed']) + .5 * max(0., move - s['speed'])
            turn_cost = min(math.pi, abs(action.turn_angle)) / (2. * math.pi)
            birth_cost = (100. if action.spawn_agent and
                          s['energy'] - move_cost - turn_cost > 100. else 0.)
            self.rl_previous[action.agent_id] = dict(energy=s['energy'], birth_cost=birth_cost)
        return actions

    def rl_finish(self, extinct):
        for aid in list(self.rl_pending):
            self.rl_close(aid, death=extinct)

    def rl_export(self):
        return dict(q=self.rl_q, counts=self.rl_counts, stats=dict(self.rl_stats))
