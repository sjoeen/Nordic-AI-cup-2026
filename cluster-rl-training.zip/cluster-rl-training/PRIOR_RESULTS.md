# One-hour hybrid RL follow-up

Recommended controller: **original-eat-rest-preserved**.

| Controller | Seed1 (s) | Seed2 (s) | Seed3 (s) | Mean (s) | vs baseline |
|---|---:|---:|---:|---:|---:|
| Original preserved eat/rest |1887.8|1618.9|1831.2|1779.3|—|
| Previous small hybrid |1202.1|1680.6|1199.2|1360.6|−23.5%|
| adaptive_6 | 1530.4 | 1615.3 | 1740.6 | 1628.8 | -8.5% |
| foraging_3 | 1480.7 | 1135.0 | 1570.0 | 1395.2 | -21.6% |
| foraging_6 | 1582.2 | 1513.2 | 1924.5 | 1673.3 | -6.0% |
| forest_6 | 1701.7 | 1535.5 | 1732.5 | 1656.6 | -6.9% |
| movement_only | 1443.2 | 1639.9 | 1535.8 | 1539.6 | -13.5% |

Best new model: **foraging_6**, mean1673.3s (-106.0s versus the original baseline; +312.7s versus the first small hybrid).

The original preserved eat/rest controller remains the best three-seed mean. The new variants are experimental and are not promoted.

Completed 6 normal training games and 15 normal evaluation games; 4960 new learning transitions. Training and evaluation seeds were separate.

## What changed

- The movement-only variant reused the first learned table, removed stationary waiting, and used more conservative support/advantage guards. It is not an isolated single-parameter ablation.
- The new learner received negative reward for fruitless energy spending, bonuses for actual feeding and early-life success, and bounded credit ending at food, threats, rest or timeout.
- One-second stationary scans require a nearby tree, energy>=100 and a six-second cooldown. Repeated indefinite waiting is impossible.
- Two extra state features describe prolonged fruitlessness and scan availability.
- Models after three and six training games were frozen before testing. The optional tree model reuses the same six-game data to generalize between related situations.
- If completed, adaptive_6 starts from the six-game model and updates only from the current game’s public observations. It uses the same support guards and no random exploration. This is an explicitly adaptive submission, separate from the frozen comparisons.
- Original food targeting, eat/rest thresholds, escape, reproduction, retirement and dispersal still control their original cases. RL only changes eligible fruitless SEARCH movement.

## Activation evidence

| Candidate | Modified agent-ticks | Slow search | Fast search | Stationary scan |
|---|---:|---:|---:|---:|
|adaptive_6|6327|4153|1948|226|
|foraging_3|3041|1191|1850|0|
|foraging_6|3413|1465|1832|116|
|forest_6|1994|1005|763|226|
|movement_only|3116|2333|783|0|

Each agent-tick is one 0.1-second action; these are not whole-game survival seconds.

## What the late-game observations show

Across the best new model's three games, 24 of 29 losses in the final 120 seconds had last-observed energy at or below 1. This is evidence of continued energy failure, using the public-observation death proxy; it does not establish exact engine death causes.

For seed 1, births in the same 900.0–1552.2s window: baseline 33 births, 28 with an inferred meal before age 30, 25 reaching age 30; the new model 27, 27, 26, respectively. These are equal birth-time windows, not matched individual agents.

Search-speed learning improved substantially over the first hybrid, but did not solve continued food access or demonstrate full-horizon survival. This experiment gave the learner control of search pace only. It did not test learned food destinations, resource allocation or reproduction. The coarse state also omits detailed tree geometry and estimated future food supply. Those are limitations of this experiment, not proven explanations for its score.

## Interpretation and limits

Only completed seeds are included. The same normal game size and full3000-second/extinction horizon were used throughout. No engine mechanics were changed, no hidden world state was used for decisions, and the original baseline was not rerun. The historical DTO defaults remain the only authorized engine-source exception. All candidate sources and frozen values were checked (adaptive_6 is the explicitly declared online-learning exception). Each game used the real stock HTTP path.

The first two unfinished games were interrupted by a runtime disconnect before RL activation; their logs remain preserved under runs/. Their same-controller restarts are under runs_recovered/. No completed game was discarded or silently substituted.

The three evaluation seeds are familiar development seeds. Known engine tie-order nondeterminism and the small sample limit strong generalization claims. Per-agent reward and tree disagreement are learning heuristics, not guarantees of species survival. Food/death classifications from public telemetry are proxies. Read METHOD.md for exact algorithms, parameters and sources.

Detailed late-game energy, movement, final deaths and equal-window offspring comparisons are in hybrid_hour/diagnostics.json. These are descriptive checks, not proof that a single mechanism caused a score change.

## Files

- survival_agent.py and requirements-agent.txt at the archive root: the recommended controller.
- best-new-hybrid/: the best completed new candidate, separately labeled even if below baseline.
- original-eat-rest-preserved.zip: unchanged saved original.
- hybrid_hour/: all new code, frozen models, results, partial logs, protocol and checks.
- Prior required controller/monitor code and the original simulator archive are included for reproducibility.
