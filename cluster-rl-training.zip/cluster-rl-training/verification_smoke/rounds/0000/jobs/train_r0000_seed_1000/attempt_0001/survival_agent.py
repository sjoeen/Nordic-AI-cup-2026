"""Tested observation-only controller. No simulator or hidden-world imports."""
import heapq
import json
import math
import random
import statistics
from collections import Counter,defaultdict,deque
from dataclasses import dataclass,field
from typing import List,Dict
from math import atan2,cos,hypot,pi,sin
from pydantic import BaseModel


VARIANTS = ('modes', 'persistent', 'allocated', 'sliding', 'tangent')

PRESETS = {
    'economy': {},
    'ripen': {'ripen_seconds': 12.},
    'patch': {'ripen_seconds': 12., 'patch_wait': 12.},
    'gaze': {'ripen_seconds': 12., 'patch_wait': 12., 'escape': 'gaze'},
    'predict': {'ripen_seconds': 12., 'patch_wait': 12., 'escape': 'predict'},
    'mapped': {'ripen_seconds': 8., 'patch_wait': 8., 'escape': 'predict', 'search_speed': .8},
    'direct': {'escape': 'direct', 'gaze_turn': math.pi, 'escape_radius': 110.},
    'agile': {'escape': 'predict', 'gaze_turn': math.pi, 'search_speed': .7,
              'prediction_horizon': 6, 'prediction_angles': 12},
    'vigilant': {'escape': 'direct', 'gaze_turn': math.pi, 'scan': .65,
                 'threat_memory': .8, 'threat_cooldown': 3., 'rest_radius': 60.,
                 'face_predators': True, 'escape_radius': 120.},
    'roamer': {'escape': 'direct', 'gaze_turn': math.pi, 'boundary_bias': True,
               'search_reorient': 5., 'scan': .35},
    'guard': {'escape': 'direct', 'gaze_turn': math.pi, 'scan': .3,
              'threat_memory': .5, 'threat_cooldown': 1.5, 'rest_radius': 65.,
              'escape_radius': 130., 'sprint_radius': 80., 'emergency_fraction': .22},
}

QUALITY={'forest':1.,'grassland':.7,'swamp':.35,'desert':.1,'river':0.}

def wrap(angle):
    return (angle + pi) % (2 * pi) - pi

def closest_point(edge):
    (ax, ay), (bx, by) = edge
    dx, dy = bx - ax, by - ay
    length2 = dx * dx + dy * dy
    t = max(0.0, min(1.0, -(ax * dx + ay * dy) / length2)) if length2 else 0.0
    return ax + t * dx, ay + t * dy

def rotate(point, angle):
    c, s = math.cos(angle), math.sin(angle)
    return c * point[0] - s * point[1], s * point[0] + c * point[1]

def unit(point, fallback=(1., 0.)):
    length = math.hypot(*point)
    return (point[0] / length, point[1] / length) if length > 1e-9 else fallback

def point(obs):
    return obs['distance'] * math.cos(obs['angle']), obs['distance'] * math.sin(obs['angle'])

def point_segment(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]
    t=max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/max(1e-9,dx*dx+dy*dy)))
    return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)

def segment_clear(a,b,edges,margin=6.):
    def cross(x,y,z):return (y[0]-x[0])*(z[1]-x[1])-(y[1]-x[1])*(z[0]-x[0])
    for c,d in edges:
        if cross(a,b,c)*cross(a,b,d)<0. and cross(c,d,a)*cross(c,d,b)<0.:return False
        if min(point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))<margin:return False
    return True

class ActionRequest(BaseModel):
    """
    Data transfer object to request an action from specific agent
    """
    agent_id: int
    move_distance: float
    move_direction: float # Relative angle in radians
    turn_angle: float # Relative angle in radians
    spawn_agent: bool

class ObservationResponse(BaseModel):
    """
    Data transfer object to receive an observation for specific agent
    """
    agent_id: int
    energy: float
    biome: str
    age: float

    # Agent attributes
    speed: float
    sprint_speed: float
    hearing_radius: float
    vision_angle: float
    vision_range: float
    max_energy: float

    observations: List[Dict]

class StepResponse(BaseModel):
    """
    Data transfer object to receive a step response
    """
    game_status: str
    score: float
    # These fields were omitted by an older testing client.  Defaults keep
    # that request shape valid while newer clients continue to send values.
    sim_time: float = 0.0
    n_agents: int = 0
    agent_status: List[ObservationResponse] = []

@dataclass
class Memory:
    target_id: object = None
    fruit_tracks: list = field(default_factory=list)
    landmarks: list = field(default_factory=list)
    predators: list = field(default_factory=list)
    last_move: tuple = (0., 0.)
    last_turn: float = 0.
    heading: float = 0.
    search_heading: float = 0.
    sequence: int = 0
    last_age: float = -1.
    escape_side: int = 0
    rng: object = None

class SpeciesFields:
    def __init__(self, variant='tangent'):
        stage = VARIANTS.index(variant)
        self.variant = variant
        self.persistent = stage >= 1
        self.allocated = stage >= 2
        self.sliding = stage >= 3
        self.tangent = stage >= 4
        self.memory = {}
        self.parents = {}
        self.metrics = Counter()

    def canonical(self, key):
        self.parents.setdefault(key, key)
        root = key
        while self.parents[root] != root:
            root = self.parents[root]
        while self.parents[key] != key:
            parent = self.parents[key]
            self.parents[key] = root
            key = parent
        return root

    def merge(self, a, b):
        a, b = self.canonical(a), self.canonical(b)
        if a != b:
            self.parents[max(a, b)] = min(a, b)
            self.metrics['cross_agent_track_merges'] += 1

    def observe(self, state):
        aid = state['agent_id']
        mem = self.memory.setdefault(aid, Memory(rng=random.Random(7919 + aid * 104729)))
        observations = state['observations']
        if getattr(self,'config',{}).get('stale_correction',False):
            # Removing an agent while the engine iterates its list can skip
            # the next survivor's sensing/living-cost update. Its action still
            # ran, so unchanged age means the returned bearings are stale.
            if state['age']==mem.last_age and mem.last_age>=0.:
                previous_turn=getattr(mem,'stale_turn',0.)
                delta=rotate(mem.last_move,previous_turn)
                old_shift=getattr(mem,'stale_shift',(0.,0.))
                total_shift=(old_shift[0]+delta[0],old_shift[1]+delta[1])
                total_turn=previous_turn+mem.last_turn
                corrected=[]
                def transform(p):return rotate((p[0]-total_shift[0],p[1]-total_shift[1]),-total_turn)
                for original in observations:
                    obs=dict(original)
                    if obs['type']=='Edge':
                        obs['coords']=tuple(transform(p) for p in obs['coords'])
                    else:
                        p=transform(point(obs))
                        obs['distance']=math.hypot(*p);obs['angle']=math.atan2(p[1],p[0])
                        if 'rel_dir' in obs:
                            heading=original['angle']+math.pi-original['rel_dir']-total_turn
                            obs['rel_dir']=wrap(obs['angle']+math.pi-heading)
                    corrected.append(obs)
                observations=corrected
                state={**state,'observations':observations}
                mem.stale_turn=total_turn;mem.stale_shift=total_shift
                self.metrics['stale_observation_corrections']+=1
            else:
                mem.stale_turn=0.;mem.stale_shift=(0.,0.)
        fruits = sorted((o for o in observations if o['type'] == 'Fruit' and o['distance'] > 6),
                        key=lambda o: (o['distance'], o['angle']))
        predators = sorted((o for o in observations if o['type'] == 'Predator'),
                           key=lambda o: (o['distance'], o['angle']))
        agents = sorted((o for o in observations if o['type'] == 'Agent'),
                        key=lambda o: (o['distance'], o.get('id', -1)))
        edges = sorted({tuple(tuple(p) for p in o['coords']) for o in observations if o['type'] == 'Edge'})
        landmarks = [('Fruit', point(o)) for o in fruits]
        landmarks += [('Tree', point(o)) for o in observations if o['type'] == 'Tree']
        landmarks += [('Corner', p) for p in sorted({p for edge in edges for p in edge})]
        # Estimate actual translation from static landmarks. Commanded motion
        # is only a fallback because the simulator can redirect collisions.
        shift = rotate(mem.last_move, -mem.last_turn)
        rotated_old = [(kind, rotate(p, -mem.last_turn)) for kind, p in mem.landmarks]
        estimates = []
        for kind, old in rotated_old:
            candidates = [(q[0], q[1]) for k, q in landmarks if k == kind]
            if not candidates:
                continue
            expected = (old[0] - shift[0], old[1] - shift[1])
            q = min(candidates, key=lambda p: math.hypot(p[0] - expected[0], p[1] - expected[1]))
            if math.hypot(q[0] - expected[0], q[1] - expected[1]) < 3.:
                estimates.append((old[0] - q[0], old[1] - q[1]))
        if len(estimates) >= 2:
            shift = (statistics.median(p[0] for p in estimates), statistics.median(p[1] for p in estimates))
        elif rotated_old and landmarks:
            # Collision recovery: test rigid translations supported by at
            # least three landmarks of matching types, never hidden poses.
            max_shift = math.hypot(*mem.last_move) + 1.
            proposals = []
            for kind, p in rotated_old[:24]:
                for other_kind, q in landmarks[:24]:
                    delta = (p[0] - q[0], p[1] - q[1])
                    if kind == other_kind and math.hypot(*delta) <= max_shift:
                        proposals.append(delta)
            if proposals:
                best = max(proposals, key=lambda d: sum(math.hypot(d[0]-p[0], d[1]-p[1]) < .75 for p in proposals))
                support = [p for p in proposals if math.hypot(best[0]-p[0], best[1]-p[1]) < .75]
                if len(support) >= 3:
                    shift = (statistics.median(p[0] for p in support), statistics.median(p[1] for p in support))
                    self.metrics['motion_corrections'] += 1

        old_tracks = []
        for key, old in mem.fruit_tracks:
            p = rotate(old, -mem.last_turn)
            old_tracks.append((key, (p[0] - shift[0], p[1] - shift[1])))
        current_points = [point(o) for o in fruits]
        matches = sorted((math.hypot(old[0] - p[0], old[1] - p[1]), i, j)
                         for i, (_, old) in enumerate(old_tracks)
                         for j, p in enumerate(current_points)
                         if math.hypot(old[0] - p[0], old[1] - p[1]) < 2.)
        old_used, new_used, identifiers = set(), set(), {}
        for distance, i, j in matches:
            if i not in old_used and j not in new_used:
                identifiers[j] = old_tracks[i][0]
                old_used.add(i)
                new_used.add(j)
                self.metrics['fruit_track_matches'] += 1
        tracks = []
        for j, (obs, p) in enumerate(zip(fruits, current_points)):
            if j not in identifiers:
                mem.sequence += 1
                identifiers[j] = (aid, mem.sequence)
            tracks.append(dict(key=identifiers[j], p=p, obs=obs))

        # Predators have headings but no IDs/speeds. Estimate displacement
        # between observations when possible, otherwise use observed heading.
        old_pred = []
        for p in mem.predators:
            q = rotate(p, -mem.last_turn)
            old_pred.append((q[0] - shift[0], q[1] - shift[1]))
        pred_data = []
        for obs in predators:
            p = point(obs)
            heading = wrap(obs['angle'] + math.pi - obs.get('rel_dir', 0.))
            velocity = (0., 0.)
            measured = False
            if old_pred:
                previous = min(old_pred, key=lambda q: math.hypot(p[0]-q[0], p[1]-q[1]))
                delta = (p[0]-previous[0], p[1]-previous[1])
                if math.hypot(*delta) <= 18.:
                    velocity, measured = delta, True
            pred_data.append(dict(obs=obs, p=p, heading=heading, velocity=velocity, measured=measured))
        mem.fruit_tracks = [(t['key'], t['p']) for t in tracks]
        mem.landmarks = landmarks
        mem.predators = [point(o) for o in predators]
        mem.heading = wrap(mem.heading + mem.last_turn)
        mem.last_age = state['age']
        threshold = max(state['hearing_radius'], .6 * state['vision_range'])
        escaping = bool(predators and predators[0]['distance'] < threshold)
        return dict(state=state, mem=mem, fruits=tracks, predators=pred_data,
                    agents=agents, edges=edges, escaping=escaping, threshold=threshold, translation=shift)

    def shared_frames(self, views):
        graph = defaultdict(list)
        for aid, view in views.items():
            for obs in view['agents']:
                bid = obs.get('id')
                if bid not in views:
                    continue
                offset = point(obs)
                angle = wrap(obs['angle'] + math.pi - obs['rel_dir'])
                graph[aid].append((bid, offset, angle))
                reverse = rotate((-offset[0], -offset[1]), -angle)
                graph[bid].append((aid, reverse, -angle))
        poses = {}
        for root in sorted(views):
            if root in poses:
                continue
            poses[root] = (root, (0., 0.), 0.)
            queue = deque([root])
            while queue:
                aid = queue.popleft()
                component, origin, orientation = poses[aid]
                for bid, offset, angle in sorted(graph[aid]):
                    if bid in poses:
                        continue
                    rotated = rotate(offset, orientation)
                    poses[bid] = (component, (origin[0]+rotated[0], origin[1]+rotated[1]), wrap(orientation+angle))
                    queue.append(bid)
        self.metrics['component_ticks'] += len({p[0] for p in poses.values()})
        self.metrics['hivemind_ticks'] += 1
        # Spatial hashing only compares fruit in a currently aligned frame.
        cells = defaultdict(list)
        located = []
        for aid, view in sorted(views.items()):
            component, origin, orientation = poses[aid]
            for fruit in view['fruits']:
                p = rotate(fruit['p'], orientation)
                p = (p[0]+origin[0], p[1]+origin[1])
                cx, cy = math.floor(p[0]/2.), math.floor(p[1]/2.)
                candidates = [item for dx in (-1,0,1) for dy in (-1,0,1)
                              for item in cells[(component,cx+dx,cy+dy)]
                              if item[0] != aid and math.hypot(item[2][0]-p[0], item[2][1]-p[1]) < 1.]
                if candidates:
                    match = min(candidates, key=lambda item: math.hypot(item[2][0]-p[0], item[2][1]-p[1]))
                    self.merge(fruit['key'], match[1])
                cells[(component,cx,cy)].append((aid, fruit['key'], p))
                located.append((component, fruit['key'], p))
        # Share currently observed fruit throughout each reconstructed frame,
        # allowing the nearest agent to be assigned even when facing away.
        # No coordinates from the simulation engine enter this calculation.
        pooled = {}
        for component, key, p in located:
            pooled.setdefault((component, self.canonical(key)), p)
        for aid, view in views.items():
            component, origin, orientation = poses[aid]
            view['shared_pose'] = poses[aid]
            own = {self.canonical(f['key']) for f in view['fruits']}
            for (fruit_component, key), p in pooled.items():
                if fruit_component != component or key in own:
                    continue
                local = rotate((p[0]-origin[0], p[1]-origin[1]), -orientation)
                distance = math.hypot(*local)
                if distance <= 6.:
                    continue
                view['fruits'].append(dict(key=key,p=local,shared=True,
                                          obs=dict(type='Fruit',distance=distance,angle=math.atan2(local[1],local[0]))))
                self.metrics['shared_fruit_observations'] += 1

    def allocate(self, views):
        if self.allocated:
            self.shared_frames(views)
        for aid, view in views.items():
            if 'max_fruit_distance' in view:
                view['fruits'] = [f for f in view['fruits'] if f['obs']['distance'] <= view['max_fruit_distance']]
            for fruit in view['fruits']:
                fruit['id'] = self.canonical(fruit['key']) if self.allocated else fruit['key']
            mem = view['mem']
            if mem.target_id is not None and self.allocated:
                mem.target_id = self.canonical(mem.target_id)
            visible = {f['id']: f for f in view['fruits']}
            if view['escaping'] or not view.get('eligible',True) or mem.target_id not in visible or not self.persistent:
                mem.target_id = None
            view['visible'] = visible

        if not self.allocated:
            for view in views.values():
                mem = view['mem']
                if not view['escaping'] and view.get('eligible',True) and mem.target_id is None and view['fruits']:
                    mem.target_id = min(view['fruits'], key=lambda f:f['obs']['distance'])['id']
            return
        # Reserve valid existing targets before distance-based matching.
        proposals = []
        for aid, view in views.items():
            key = view['mem'].target_id
            if key is not None:
                proposals.append((view['visible'][key]['obs']['distance'], aid, key))
        owners, assigned = {}, set()
        for distance, aid, key in sorted(proposals):
            if key not in owners:
                owners[key], assigned = aid, assigned | {aid}
                self.metrics['preserved_assignments'] += 1
            else:
                views[aid]['mem'].target_id = None
                self.metrics['newly_discovered_conflicts'] += 1
        candidates = sorted((fruit['obs']['distance'], aid, fruit['id'])
                            for aid, view in views.items() if not view['escaping'] and view.get('eligible',True) and aid not in assigned
                            for fruit in view['fruits'])
        for distance, aid, key in candidates:
            if aid not in assigned and key not in owners:
                views[aid]['mem'].target_id = key
                owners[key] = aid
                assigned.add(aid)
        assert len(owners) == len(assigned)

    def slide(self, desired, view, distance):
        original = unit(desired)
        result = original
        terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(view['state']['biome'], 1.)
        travel = distance * terrain
        used = False
        walls = sorted(((math.hypot(*closest_point(e)), e) for e in view['edges']), key=lambda item:item[0])
        for clearance, edge in walls:
            p = closest_point(edge)
            normal = unit((-p[0], -p[1]))
            inward = -(result[0]*normal[0] + result[1]*normal[1])
            if clearance > 7. + max(0., inward)*travel or inward <= 0.:
                continue
            tangent = unit((edge[1][0]-edge[0][0], edge[1][1]-edge[0][1]))
            along = result[0]*tangent[0] + result[1]*tangent[1]
            if abs(along) < .05:
                prior = rotate(view['mem'].last_move, -view['mem'].last_turn)
                along = prior[0]*tangent[0] + prior[1]*tangent[1]
                if abs(along) < .05:
                    along = 1. if view['state']['agent_id'] % 2 == 0 else -1.
            sign = 1. if along >= 0 else -1.
            outward = .2 if clearance < 7. else .04
            result = unit((sign*tangent[0] + outward*normal[0], sign*tangent[1] + outward*normal[1]))
            used = True
        return result, used

    def arc_escape(self, view, distance):
        predator = view['predators'][0]
        away = unit((-predator['p'][0], -predator['p'][1]))
        velocity = predator['velocity']
        heading = (math.atan2(velocity[1], velocity[0])
                   if predator['measured'] and math.hypot(*velocity) > .5 else predator['heading'])
        # An approach line points from predator toward prey. If the observed
        # heading points away, use the line of sight for escape construction.
        if math.cos(heading)*away[0] + math.sin(heading)*away[1] < .3:
            heading = math.atan2(away[1], away[0])
        terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(view['state']['biome'], 1.)
        candidates = []
        for side in (-1, 1):
            angle = heading + side*math.pi/3.  # 60-degree evasion arc
            candidate = (math.cos(angle), math.sin(angle))
            if candidate[0]*away[0] + candidate[1]*away[1] < .1:
                angle = math.atan2(away[1], away[0]) + side*math.pi/3.
                candidate = (math.cos(angle), math.sin(angle))
            candidate, slid = self.slide(candidate, view, distance)
            clearance = math.inf
            for enemy in view['predators']:
                # When newly observed, only heading is known; compare current
                # separation rather than inventing the enemy's actual speed.
                vx, vy = enemy['velocity'] if enemy['measured'] else (0., 0.)
                for horizon in (1., 2.):
                    ax, ay = candidate[0]*distance*terrain*horizon, candidate[1]*distance*terrain*horizon
                    px, py = enemy['p'][0]+vx*horizon, enemy['p'][1]+vy*horizon
                    clearance = min(clearance, math.hypot(ax-px, ay-py))
            score = clearance + (2. if side == view['mem'].escape_side else 0.)
            candidates.append((score, side, candidate))
        _, side, result = max(candidates, key=lambda c:(c[0], c[1]))
        view['mem'].escape_side = side
        return result

    def steer(self, view):
        state, mem = view['state'], view['mem']
        target = view['visible'].get(mem.target_id)
        fraction = state['energy'] / max(state['max_energy'], 1e-9)
        walk = max(0., min(state['speed'], state['sprint_speed']))
        distance = walk
        if view['escaping']:
            mode = 'ESCAPE'
            self.metrics['escape_ticks'] += 1
            if fraction > .4:
                distance = max(0., state['sprint_speed'])
                self.metrics['sprint_ticks'] += 1
            predator = view['predators'][0]
            desired = unit((-predator['p'][0], -predator['p'][1]))
            if self.tangent:
                desired = self.arc_escape(view, distance)
        elif target is not None:
            mode = 'EAT'
            self.metrics['eat_ticks'] += 1
            # Exactly one fruit contributes attraction; no predator field.
            strength = 40. / max(target['obs']['distance'], 8.)
            tx, ty = unit(target['p'])
            desired = (tx*strength, ty*strength)
            sx = sy = 0.
            for teammate in view['agents']:
                if teammate['distance'] < 25.:
                    weight = .2*(1.-teammate['distance']/25.)
                    sx -= weight*math.cos(teammate['angle'])
                    sy -= weight*math.sin(teammate['angle'])
            # Keep separation mild relative to attraction, even in a crowd.
            cap = min(1., .2*strength/max(math.hypot(sx, sy), 1e-9))
            desired = (desired[0]+cap*sx, desired[1]+cap*sy)
        else:
            mode = 'SEARCH'
            self.metrics['search_ticks'] += 1
            if self.allocated and view['fruits'] and view['agents']:
                nearest = view['agents'][0]
                mem.search_heading = wrap(mem.heading + nearest['angle'] + math.pi)
                self.metrics['displaced_search_ticks'] += 1
            mem.search_heading = wrap(mem.search_heading + mem.rng.uniform(-.025, .025))
            angle = wrap(mem.search_heading-mem.heading)
            desired = (math.cos(angle), math.sin(angle))

        if mode != 'ESCAPE' and state['age'] > 60. and (target is None or target['obs']['distance'] > state['hearing_radius']):
            distance *= max(.5, 60./state['age'])
        if self.sliding:
            desired, slid = self.slide(desired, view, distance)
            self.metrics['wall_slide_ticks'] += int(slid)
        else:
            # Earlier-stage control uses normal repulsion plus the same small
            # tangent used in the hierarchical experiment.
            fx, fy = desired
            radius = max(20., min(40., 2.*walk+5.))
            for edge in view['edges']:
                px, py = closest_point(edge)
                d = max(math.hypot(px, py), .1)
                if d >= radius:
                    continue
                strength = min(12., 4.*(1.-d/radius)**2*5./max(d-5., 1.))
                nx, ny = -px/d, -py/d
                tx, ty = -ny, nx
                if tx*fx + ty*fy < 0:
                    tx, ty = -tx, -ty
                fx += strength*(nx+.5*tx)
                fy += strength*(ny+.5*ty)
            desired = (fx, fy)
        direction = math.atan2(desired[1], desired[0]) if math.hypot(*desired) > 1e-9 else wrap(mem.search_heading-mem.heading)
        if mode == 'EAT' and abs(wrap(direction-target['obs']['angle'])) < .5:
            terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(state['biome'], 1.)
            distance = min(distance, max(0., target['obs']['distance']-6.)/terrain)
        threshold = max(.8*state['max_energy'], 100.+.2*state['max_energy'])
        spawn = state['energy'] > threshold and not view['predators']
        turn = max(-.4, min(.4, direction))
        terrain = {'swamp':.5, 'river':.3, 'desert':.8}.get(state['biome'], 1.)
        mem.last_move = (distance*terrain*math.cos(direction), distance*terrain*math.sin(direction))
        mem.last_turn = turn
        # Persist the heading actually chosen, including wall deflections.
        # Keeping the pre-wall search heading repeatedly drives into the wall.
        mem.search_heading = wrap(mem.heading+direction)
        return ActionRequest(agent_id=state['agent_id'], move_distance=distance,
                             move_direction=direction, turn_angle=turn, spawn_agent=spawn)

    def decide_all(self, states):
        # A new game can reuse IDs and ages. Clear all cross-game state.
        if any(s['agent_id'] in self.memory and s['age'] < self.memory[s['agent_id']].last_age for s in states):
            self.memory.clear()
            self.parents.clear()
        live = {s['agent_id'] for s in states}
        self.memory = {key: value for key, value in self.memory.items() if key in live}
        views = {s['agent_id']:self.observe(s) for s in sorted(states,key=lambda s:s['agent_id'])}
        self.allocate(views)
        return [self.steer(views[s['agent_id']]) for s in states]

class SurvivalPolicy(SpeciesFields):
    def __init__(self, preset='economy', **overrides):
        super().__init__('tangent')
        self.config = dict(search_speed=.4, scan=.2, birth_energy=220.,
                           population=12, population_floor=3, population_decay=900.,
                           retirement=105., ripen_seconds=0., patch_wait=0.,
                           escape='arc', escape_radius=100., sprint_radius=55.,
                           idle_energy=.87, young_age=65., reserve=80.)
        self.config.update(gaze_turn=1., prediction_horizon=4, prediction_angles=6)
        self.config.update(threat_memory=0.,threat_cooldown=0.,rest_radius=45.,face_predators=False,
                           selective_breeding=0.,weighted_allocation=False,boundary_bias=False,search_reorient=0.,emergency_fraction=.4,
                           fresh_ripen=0.,ripen_age_limit=65.,hard_idle_energy=1e9,birth_floor=135.,fertile_population=False,
                           quality_mode='basic',fitness_population=False)
        self.config.update(PRESETS.get(preset, {}))
        self.config.update(overrides)
        self.preset = preset
        self.clock = 0.
        self.first_seen = {}
        self.birth_times = {}
        self.spawn_ids = set()
        self.retired_ids = set()

    def observe(self, state):
        old_mem=self.memory.get(state['agent_id'])
        old_keys={key for key,p in old_mem.fruit_tracks} if old_mem is not None else set()
        had_previous=old_mem is not None and old_mem.last_age>=0.
        view = super().observe(state)
        mem=view['mem']
        if view['predators']:
            mem.enemy_cache=[dict(p) for p in view['predators']]
            mem.enemy_seen=self.clock
        elif self.config['threat_memory'] and hasattr(mem,'enemy_cache') and self.clock-mem.enemy_seen<self.config['threat_memory']:
            remembered=[]
            for enemy in mem.enemy_cache:
                q=rotate(enemy['p'],-mem.last_turn)
                v=rotate(enemy['velocity'],-mem.last_turn)
                q=(q[0]-view['translation'][0]+v[0]*.7,q[1]-view['translation'][1]+v[1]*.7)
                d=math.hypot(*q)
                remembered.append(dict(p=q,heading=wrap(enemy['heading']-mem.last_turn),velocity=v,measured=True,
                                       remembered=True,obs=dict(type='Predator',distance=d,angle=math.atan2(q[1],q[0]))))
            view['predators']=remembered
            mem.enemy_cache=remembered
        for fruit in view['fruits']:
            key = self.canonical(fruit['key'])
            self.first_seen.setdefault(key, self.clock)
            if had_previous and fruit['key'] not in old_keys and fruit['obs']['distance']+math.hypot(*view['translation'])+3.<state['hearing_radius']:
                # It was inside the previous hearing disk and absent then:
                # unlike a newly discovered distant fruit, this is a birth.
                self.birth_times.setdefault(key,self.clock)
        if self.config['escape'] != 'arc':
            threats = []
            for enemy in view['predators']:
                d = enemy['obs']['distance']
                v = enemy['velocity']
                closing = -(v[0]*enemy['p'][0]+v[1]*enemy['p'][1])/max(d,1.)
                radius = self.config['escape_radius']
                # Still predators may wake without advance notice.
                if enemy['measured'] and math.hypot(*v) < .5:
                    radius = min(radius, self.config['rest_radius'])
                if d < radius or (closing > 2 and d/closing < 7.):
                    threats.append(enemy)
            view['escaping'] = bool(threats)
            if threats:
                view['predators'].sort(key=lambda p: (p not in threats,p['obs']['distance']))
        mem = view['mem']
        if not hasattr(mem, 'patch_since'):
            mem.patch_since = None
        return view

    def merge(self, a, b):
        aa, bb = self.canonical(a), self.canonical(b)
        first = min(self.first_seen.get(aa,self.clock), self.first_seen.get(bb,self.clock))
        births=[self.birth_times[k] for k in (aa,bb) if k in self.birth_times]
        super().merge(a,b)
        self.first_seen[self.canonical(a)] = first
        if births:self.birth_times[self.canonical(a)]=min(births)

    def decide_all(self, states, sim_time=None):
        if any(s['agent_id'] in self.memory and s['age'] < self.memory[s['agent_id']].last_age for s in states):
            self.memory.clear()
            self.parents.clear()
            self.first_seen.clear()
            self.birth_times.clear()
            self.clock = 0.
        self.clock = float(sim_time) if sim_time is not None else self.clock + .1
        live = {s['agent_id'] for s in states}
        self.memory = {k:v for k,v in self.memory.items() if k in live}
        views = {s['agent_id']:self.observe(s) for s in sorted(states,key=lambda s:s['agent_id'])}
        c = self.config
        cap = max(c['population_floor'], round(c['population'] * .5**(self.clock/c['population_decay'])))
        young = sum(s['age'] < c['young_age'] and (not c['fertile_population'] or s['max_energy']>c['birth_floor']+5.) for s in states)
        def quality(s):
            if c['quality_mode']!='basic':
                walk=max(.1,min(s['speed'],s['sprint_speed']))/10.
                hearing=max(.1,s['hearing_radius'])/50.
                vision=max(.1,s['vision_range'])/200.
                cone=max(.01,s['vision_angle'])/(math.pi/3.)
                fertility=min(1.,max(.01,(s['max_energy']-100.)/100.))
                if c['quality_mode']=='endurance':return walk**1.4*hearing**.9*vision**.4*cone**.3*(max(100.,s['max_energy'])/500.)**.65*fertility
                if c['quality_mode']=='sensory':return walk**1.3*hearing**1.2*vision**.5*cone**.4*fertility
                return walk**1.7*hearing**.8*vision**.4*cone**.3*fertility
            return min(s['speed'],s['sprint_speed'])*math.sqrt(max(1.,s['hearing_radius']+.5*s['vision_range']))
        qualities=sorted(quality(s) for s in states)
        median_quality=qualities[len(qualities)//2] if qualities else 1.
        if c['fitness_population'] and qualities:
            young=round(sum(min(1.,quality(s)/max(qualities)) for s in states if s['age']<c['young_age']))
        elite_cutoff=c.get('elite_population',0.)
        if elite_cutoff and qualities:
            young=sum(s['age']<c['young_age'] and quality(s)>=elite_cutoff*max(qualities) for s in states)
        self.retired_ids = {s['agent_id'] for s in states if s['age']>c['retirement'] and young>=max(2,cap//2)}
        if elite_cutoff and qualities and sum(quality(s)>=elite_cutoff*max(qualities) for s in states)>=2:
            self.retired_ids.update(s['agent_id'] for s in states if quality(s)<.8*max(qualities) and s['age']>2.)
        candidates = []
        for aid, view in views.items():
            s = view['state']
            threshold = min(c['birth_energy'], .75*s['max_energy'])
            threshold = max(c['birth_floor'], threshold)
            if c['selective_breeding']:
                threshold=max(135.,threshold+c['selective_breeding']*(1.-quality(s)/median_quality))
            if s['age'] > 60 and young < max(2,cap//2):
                threshold = min(threshold,160.)
            safe = not view['predators'] or min(p['obs']['distance'] for p in view['predators']) > 130.
            safe = safe and self.clock-getattr(view['mem'],'enemy_seen',-10000.)>=c['threat_cooldown']
            if s['energy'] > threshold and safe and aid not in self.retired_ids:
                parent_quality = quality(s) if c['selective_breeding'] or c['quality_mode']!='basic' else min(s['speed'],s['sprint_speed']) + .015*s['hearing_radius'] + .003*s['vision_range']
                candidates.append((parent_quality, s['energy'], -aid, aid))
        self.spawn_ids = {x[-1] for x in sorted(candidates,reverse=True)[:max(0,cap-young)]}
        for aid,view in views.items():
            s=view['state']
            if aid in self.retired_ids or (s['energy']>min(c['hard_idle_energy'],c['idle_energy']*s['max_energy']) and aid not in self.spawn_ids):
                view['resting'] = True
            else:
                view['resting'] = False
            view['eligible'] = not view['resting']
        self.allocate(views)
        return [self.steer(views[s['agent_id']]) for s in states]

    def predictive_escape(self, view, walk, sprint):
        """Sample short trajectories against a bounded-turn pursuit model."""
        terrain = {'swamp':.5,'river':.3,'desert':.8}.get(view['state']['biome'],1.)
        nearest=view['predators'][0]
        away=math.atan2(-nearest['p'][1],-nearest['p'][0])
        previous=rotate(view['mem'].last_move,-view['mem'].last_turn)
        prev_angle=math.atan2(previous[1],previous[0])
        choices=[]
        speeds=[walk]
        if sprint>walk+.01 and view['state']['energy']>.21*view['state']['max_energy']+10:
            speeds.append(sprint)
        for speed in speeds:
            count=self.config['prediction_angles']
            offsets=[(i-count/2)*math.pi/count for i in range(count+1)]
            if count>=12:
                offsets.extend([-2*math.pi/3,2*math.pi/3])
            for offset in offsets:
                direction,slid=self.slide((math.cos(away+offset),math.sin(away+offset)),view,speed)
                vx,vy=direction[0]*speed*terrain,direction[1]*speed*terrain
                minimum=math.inf
                end=math.inf
                for enemy in view['predators'][:4]:
                    px,py=enemy['p']; heading=enemy['heading']
                    ex,ey=enemy['velocity']
                    moving=not enemy['measured'] or math.hypot(ex,ey)>.5
                    if moving:
                        # Observations precede the predator's last move.
                        px+=ex; py+=ey
                    for horizon in range(1,self.config['prediction_horizon']+1):
                        ax,ay=vx*horizon,vy*horizon
                        if moving or horizon>=3:
                            target_angle=math.atan2(ay-py,ax-px)
                            heading=wrap(heading+max(-.3,min(.3,wrap(target_angle-heading)*.5)))
                            pspeed=15.*terrain
                            px+=pspeed*math.cos(heading); py+=pspeed*math.sin(heading)
                        d=math.hypot(ax-px,ay-py)
                        minimum=min(minimum,d)
                    end=min(end,d)
                cost=.05*min(speed,walk)+.5*max(0,speed-walk)
                angle=math.atan2(direction[1],direction[0])
                # Collision avoidance dominates, then useful clearance and cost.
                value=(-1000.*max(0,22.-minimum) + min(minimum,65.)
                       +.15*min(end,150.)-4.*cost+1.5*math.cos(angle-prev_angle))
                choices.append((value,speed,direction))
        _,speed,direction=max(choices,key=lambda x:x[0])
        return direction,speed

    def steer(self, view):
        s,mem,c=view['state'],view['mem'],self.config
        target=view['visible'].get(mem.target_id)
        terrain={'swamp':.5,'river':.3,'desert':.8}.get(s['biome'],1.)
        walk=max(0.,min(s['speed'],s['sprint_speed']))
        speed=walk
        turn=None
        mode='SEARCH'
        if view['escaping']:
            mode='ESCAPE'
            if c['escape']=='predict':
                desired,speed=self.predictive_escape(view,walk,s['sprint_speed'])
            else:
                if s['energy']>max(c['emergency_fraction']*s['max_energy'],.2*s['max_energy']+5.) and view['predators'][0]['obs']['distance']<c['sprint_radius']:
                    speed=s['sprint_speed']
                desired=(unit((-view['predators'][0]['p'][0],-view['predators'][0]['p'][1]))
                         if c['escape']=='direct' else self.arc_escape(view,speed))
            if c['escape']!='arc':
                pred=view['predators'][0]
                turn=max(-c['gaze_turn'],min(c['gaze_turn'],pred['obs']['angle']))
            mem.patch_since=None
        elif view.get('resting'):
            mode='REST'
            desired=(1.,0.); speed=0.; turn=c['scan']
        elif target is not None:
            mode='EAT'
            desired=unit(target['p'])
            d=target['obs']['distance']
            seen=self.clock-self.first_seen.get(self.canonical(target['key']),self.clock)
            wait=c['ripen_seconds']
            born=self.birth_times.get(self.canonical(target['key']))
            if c['fresh_ripen'] and born is not None:
                wait=c['fresh_ripen'];seen=self.clock-born
            ripening=(seen<wait and s['energy']>c['reserve']+2*(wait-seen) and s['age']<c['ripen_age_limit'])
            stop=17. if ripening else 6.
            speed=min(walk,max(0.,d-stop)/terrain)
            if ripening and d<19.:
                mode='RIPEN'; turn=c['scan']
            mem.patch_since=None
        else:
            trees=[o for o in s['observations'] if o['type']=='Tree']
            nearby=min(trees,key=lambda o:o['distance']) if trees else None
            if c['patch_wait'] and nearby and nearby['distance']<55. and s['energy']>c['reserve'] and s['age']<65.:
                if mem.patch_since is None:
                    mem.patch_since=self.clock
                if self.clock-mem.patch_since<c['patch_wait']:
                    mode='PATCH'; desired=unit(point(nearby))
                    speed=min(walk,max(0.,nearby['distance']-35.)/terrain)
                    turn=c['scan']
                else:
                    nearby=None
            else:
                mem.patch_since=None
                nearby=None
            if mode=='SEARCH':
                if c['search_reorient'] and self.clock>=getattr(mem,'next_reorient',0.):
                    mem.search_heading=wrap(mem.search_heading+mem.rng.choice((-1,1))*mem.rng.uniform(.6,1.6))
                    mem.next_reorient=self.clock+c['search_reorient']
                if view['fruits'] and view['agents']:
                    a=view['agents'][0]
                    mem.search_heading=wrap(mem.heading+a['angle']+math.pi)
                mem.search_heading=wrap(mem.search_heading+mem.rng.uniform(-.015,.015))
                angle=wrap(mem.search_heading-mem.heading)
                desired=(math.cos(angle),math.sin(angle))
                if c['boundary_bias']:
                    dx,dy=desired
                    for edge in view['edges']:
                        length=math.hypot(edge[1][0]-edge[0][0],edge[1][1]-edge[0][1])
                        p=closest_point(edge);d=math.hypot(*p)
                        if length>800. and d<120.:
                            normal=unit((-p[0],-p[1]))
                            weight=3.*max(0.,1.-d/120.)
                            dx+=weight*normal[0];dy+=weight*normal[1]
                    desired=unit((dx,dy))
                speed=walk*c['search_speed']
                turn=c['scan']
        desired,slid=self.slide(desired,view,speed)
        direction=math.atan2(desired[1],desired[0])
        if turn is None:
            turn=max(-.6,min(.6,direction))
        if c['face_predators'] and view['predators'] and (target is None or target['obs']['distance']<s['hearing_radius']):
            enemy=view['predators'][0]
            if enemy['obs']['distance']<180.:
                turn=max(-c['gaze_turn'],min(c['gaze_turn'],enemy['obs']['angle']))
        self.metrics[mode.lower()+'_ticks']+=1
        mem.last_mode=mode
        self.metrics['sprint_ticks']+=int(speed>walk+.01)
        self.metrics['wall_slide_ticks']+=int(slid)
        mem.last_move=(speed*terrain*math.cos(direction),speed*terrain*math.sin(direction))
        mem.last_turn=turn
        if speed>0:
            mem.search_heading=wrap(mem.heading+direction)
        return ActionRequest(agent_id=s['agent_id'],move_distance=speed,move_direction=direction,
                             turn_angle=turn,spawn_agent=s['agent_id'] in self.spawn_ids)

class AdaptivePolicy(SurvivalPolicy):
    def __init__(self,preset='adaptive',**overrides):
        config=dict(escape='direct',gaze_turn=math.pi,population=6,population_floor=2,
                    emergency_birth=True,emergency_birth_distance=55.,renewal_age=75.,
                    crowd_escape=True,crowd_margin=45.,hunger_feed=True,search_speed=.4,sprint_ceiling=None)
        config.update(overrides)
        super().__init__(preset,**config)

    def decide_all(self,states,sim_time=None):
        actions=super().decide_all(states,sim_time)
        c=self.config
        if c['sprint_ceiling'] is not None:
            byid={s['agent_id']:s for s in states}
            for action in actions:
                s=byid[action.agent_id]
                cap=max(min(s['speed'],s['sprint_speed']),min(c['sprint_ceiling'],s['sprint_speed']))
                if action.move_distance>cap:
                    action.move_distance=cap
                    terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
                    self.memory[action.agent_id].last_move=(cap*terrain*math.cos(action.move_direction),cap*terrain*math.sin(action.move_direction))
        if c['emergency_birth']:
            young=sum(s['age']<c['renewal_age'] for s in states)
            byid={s['agent_id']:s for s in states}
            for action in actions:
                s=byid[action.agent_id]
                if action.spawn_agent:continue
                enemies=[o['distance'] for o in s['observations'] if o['type']=='Predator']
                safe=not enemies or min(enemies)>c['emergency_birth_distance']
                cost=.05*min(action.move_distance,s['speed'])+.5*max(0.,action.move_distance-s['speed'])+abs(action.turn_angle)/(2*math.pi)
                if safe and s['energy']>112.+cost and (len(states)<3 or (s['age']>c['renewal_age'] and young<max(2,self.config['population_floor']))):
                    action.spawn_agent=True;young+=1
                    self.metrics['emergency_births']+=1
        return actions

    def steer(self,view):
        s,mem,c=view['state'],view['mem'],self.config
        action=super().steer(view)
        if not view['escaping'] or not c['crowd_escape']:return action
        enemies=view['predators'][:5]
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        walk=min(s['speed'],s['sprint_speed'])
        sx=sy=0.
        for p in enemies:
            d=max(10.,p['obs']['distance'])
            sx-=p['p'][0]/d**3;sy-=p['p'][1]/d**3
        away=math.atan2(sy,sx)
        speeds=[walk]
        if s['energy']>.2*s['max_energy']+5. and s['sprint_speed']>walk:
            speeds.extend(((walk+s['sprint_speed'])/2.,s['sprint_speed']))
        angles=[away+i*math.pi/12 for i in range(-6,7)]
        angles.append(action.move_direction)
        food=min(view['fruits'],key=lambda f:f['obs']['distance']) if view['fruits'] else None
        if food and c['hunger_feed']:angles.append(food['obs']['angle'])
        options=[]
        for speed in speeds:
            for angle in angles:
                direction,_=self.slide((math.cos(angle),math.sin(angle)),view,speed)
                vx,vy=direction[0]*speed*terrain,direction[1]*speed*terrain
                minimum=math.inf;ending=math.inf
                for enemy in enemies:
                    ex,ey=enemy['velocity']
                    if not enemy['measured']:
                        ex,ey=15.*terrain*math.cos(enemy['heading']),15.*terrain*math.sin(enemy['heading'])
                    for t in (1.,2.,3.):
                        d=math.hypot(enemy['p'][0]+ex*(t+1)-vx*t,enemy['p'][1]+ey*(t+1)-vy*t)
                        minimum=min(minimum,d)
                    ending=min(ending,d)
                cost=.05*min(speed,s['speed'])+.5*max(0.,speed-s['speed'])
                progress=0.
                if food and c['hunger_feed']:
                    d=food['obs']['distance']
                    progress=(d-math.hypot(food['p'][0]-vx*3,food['p'][1]-vy*3))*min(1.,75./max(50.,s['energy']))
                score=-1000.*max(0.,25.-minimum)-1.5*max(0.,c['crowd_margin']-minimum)+.15*min(ending,150.)-cost*5.+progress*.5
                goal=view.get('escape_goal')
                if goal is not None:
                    score+=view.get('escape_goal_weight',.5)*(math.hypot(*goal)-math.hypot(goal[0]-vx*3,goal[1]-vy*3))
                options.append((score,speed,direction))
        _,speed,direction=max(options,key=lambda x:x[0])
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=enemies[0]['obs']['angle']
        mem.last_move=(speed*terrain*direction[0],speed*terrain*direction[1])
        mem.last_turn=action.turn_angle;mem.search_heading=wrap(mem.heading+action.move_direction)
        mem.last_mode='CROWD_ESCAPE';self.metrics['crowd_escape_ticks']+=1
        return action

class RefugePolicy(AdaptivePolicy):
    def __init__(self,preset='refuge',**overrides):
        config=dict(face_predators=True,blocked_threat_distance=65.,crowd_escape=True,
                    hard_idle_energy=250.,birth_energy=180.)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state)
        mem=view['mem']
        previous=[]
        for edge,seen in getattr(mem,'shelter_edges',[]):
            if self.clock-seen>2.:continue
            transformed=[]
            for p in edge:
                q=rotate(p,-mem.last_turn)
                transformed.append((q[0]-view['translation'][0],q[1]-view['translation'][1]))
            previous.append((tuple(transformed),seen))
        current=[(edge,self.clock) for edge in view['edges']]
        mem.shelter_edges=(previous+current)[-60:]
        threats=[]
        for enemy in view['predators']:
            blocked=[edge for edge,t in mem.shelter_edges if not segment_clear((0.,0.),enemy['p'],[edge],0.)]
            if blocked:
                length=max(min(math.hypot(*q)+math.hypot(q[0]-enemy['p'][0],q[1]-enemy['p'][1]) for q in edge) for edge in blocked)
                if length>self.config['blocked_threat_distance'] and enemy['obs']['distance']>22.:
                    self.metrics['sheltered_threat_ticks']+=1
                    continue
            d=enemy['obs']['distance'];v=enemy['velocity']
            closing=-(v[0]*enemy['p'][0]+v[1]*enemy['p'][1])/max(1.,d)
            radius=self.config['rest_radius'] if enemy['measured'] and math.hypot(*v)<.5 else self.config['escape_radius']
            if d<radius or (closing>2. and d/closing<7.):threats.append(enemy)
        view['escaping']=bool(threats)
        if threats:view['predators'].sort(key=lambda e:(e not in threats,e['obs']['distance']))
        return view

class DispersalPolicy(RefugePolicy):
    def __init__(self,preset='dispersal',**overrides):
        config=dict(dispersal_distance=200.,dispersal_time=6.,stale_correction=True)
        config.update(overrides)
        super().__init__(preset,**config)

    def observe(self,state):
        view=super().observe(state);mem=view['mem']
        if not hasattr(mem,'birth_origin'):
            mem.birth_origin=(0.,0.)
            mem.colonist=state['age']<.5 and state['energy']<100.
            mem.migration_heading=mem.rng.uniform(-math.pi,math.pi)
        q=rotate(mem.birth_origin,-mem.last_turn)
        mem.birth_origin=(q[0]-view['translation'][0],q[1]-view['translation'][1])
        if state['age']>self.config['dispersal_time'] or state['energy']<40. or math.hypot(*mem.birth_origin)>self.config['dispersal_distance']:
            mem.colonist=False
        return view

    def allocate(self,views):
        for view in views.values():
            if view['mem'].colonist:
                view['eligible']=False;view['resting']=False
        super().allocate(views)

    def steer(self,view):
        action=super().steer(view)
        s,mem=view['state'],view['mem']
        if not mem.colonist or view['escaping']:return action
        angle=wrap(mem.migration_heading-mem.heading)
        if view['predators']:
            enemy=view['predators'][0]
            if enemy['obs']['distance']<160. and math.cos(angle-enemy['obs']['angle'])>.2:
                mem.migration_heading=wrap(mem.heading+enemy['obs']['angle']+math.pi)
                angle=wrap(mem.migration_heading-mem.heading)
        speed=min(s['speed'],s['sprint_speed'])
        direction,_=self.slide((math.cos(angle),math.sin(angle)),view,speed)
        action.move_distance=speed;action.move_direction=math.atan2(direction[1],direction[0])
        action.turn_angle=max(-.6,min(.6,action.move_direction))
        terrain={'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
        mem.last_move=tuple(v*speed*terrain for v in direction);mem.last_turn=action.turn_angle
        mem.search_heading=wrap(mem.heading+action.move_direction);mem.last_mode='COLONIZE'
        self.metrics['colonization_ticks']+=1
        return action

class GenerationPolicy(DispersalPolicy):
    def __init__(self,preset='generation',**overrides):
        config=dict(dispersal_distance=100.,generation_mode='baseline',generation_fraction=.65,
                    generation_lifetime=90.,birth_spacing=0.,maximum_birth_gap=0.,
                    elder_birth_priority=False,young_energy_weight=0.)
        config.update(overrides);super().__init__(preset,**config)
        self.last_normal_birth=-1000.

    def decide_all(self,states,sim_time=None):
        if ((sim_time is not None and sim_time<self.clock) or
                any(s['agent_id'] in self.memory and s['age']<self.memory[s['agent_id']].last_age for s in states)):
            self.last_normal_birth=-1000.
        return super().decide_all(states,sim_time)

    def allocate(self,views):
        c=self.config
        if c['generation_mode']!='baseline' or c['birth_spacing'] or c['maximum_birth_gap'] or c['elder_birth_priority']:
            states=[v['state'] for v in views.values()]
            cap=max(c['population_floor'],round(c['population']*.5**(self.clock/c['population_decay'])))
            young=sum(s['age']<c['young_age'] for s in states)
            budget=max(0,cap-young)
            if c['generation_mode']=='linear':
                effective=sum(max(0.,1.-s['age']/c['generation_lifetime']) for s in states)
                budget=max(0,math.floor(cap*c['generation_fraction']-effective+.5))
            elif c['generation_mode']=='energy':
                effective=sum(min(1.,max(.25,s['energy']/120.)) for s in states if s['age']<c['young_age'])
                budget=max(0,math.floor(cap-effective+.5))
            if c['maximum_birth_gap'] and len(states)<2*cap:
                youngest=min((s['age'] for s in states if s['energy']>40.),default=1000.)
                if youngest>c['maximum_birth_gap']:budget=max(budget,1)
            if c['birth_spacing']:
                budget=min(budget,int(self.clock-self.last_normal_birth>=c['birth_spacing']))
            candidates=[]
            for aid,v in views.items():
                s=v['state']
                threshold=max(c['birth_floor'],min(c['birth_energy'],.75*s['max_energy']))
                if s['age']>60 and young<max(2,cap//2):threshold=min(threshold,160.)
                safe=not v['predators'] or min(p['obs']['distance'] for p in v['predators'])>130.
                if s['energy']<=threshold or not safe or aid in self.retired_ids:continue
                quality=min(s['speed'],s['sprint_speed'])+.015*s['hearing_radius']+.003*s['vision_range']
                elder=(s['age']>70.,s['age']) if c['elder_birth_priority'] else (False,0.)
                candidates.append((elder,quality,s['energy'],-aid,aid))
            self.spawn_ids={item[-1] for item in sorted(candidates,reverse=True)[:budget]}
            if self.spawn_ids:self.last_normal_birth=self.clock
            for aid,v in views.items():
                s=v['state']
                v['resting']=aid in self.retired_ids or (s['energy']>min(c['hard_idle_energy'],c['idle_energy']*s['max_energy']) and aid not in self.spawn_ids)
                v['eligible']=not v['resting']
        super().allocate(views)

class HarvestPolicy(GenerationPolicy):
    def __init__(self, preset='harvest', **overrides):
        config = dict(maximum_birth_gap=20., harvest_depth=2,
                      harvest_discount=.7, harvest_switch=7., harvest_start=0.,
                      harvest_range=180., harvest_food_value=42.)
        config.update(overrides)
        super().__init__(preset, **config)

    def allocate(self, views):
        super().allocate(views)
        c = self.config
        if self.clock < c['harvest_start']:
            return
        owners = {v['mem'].target_id: aid for aid,v in views.items() if v['mem'].target_id is not None}
        for aid,v in sorted(views.items(), key=lambda kv: kv[1]['state']['energy']):
            if v['escaping'] or not v.get('eligible', True):
                continue
            s,m = v['state'],v['mem']
            terrain = {'river':.3,'swamp':.5,'desert':.8}.get(s['biome'],1.)
            speed = max(.1,min(s['speed'],s['sprint_speed']))
            # Age is public; the exact random aging onset is deliberately
            # not read. Expected late metabolic cost rises gradually.
            aging = max(0.,min(1.,(s['age']-60.)/60.)) * .1*s['age']
            unit_cost = (.05 + (1.32+aging)*.1/speed)/terrain
            foods = [f for key,f in v['visible'].items()
                     if owners.get(key,aid)==aid and f['obs']['distance']>10.]
            foods = sorted(foods,key=lambda f:f['obs']['distance'])[:12]
            values = []
            for f in foods:
                d = max(0.,f['obs']['distance']-10.)
                if d*unit_cost+1. >= s['energy']:
                    continue
                if not segment_clear((0.,0.),f['p'],v['edges'],0.):
                    continue
                def value(item):
                    born = self.birth_times.get(self.canonical(item['key']))
                    return min(60.,20.+2.*(self.clock-born)) if born is not None else c['harvest_food_value']
                score = value(f)-d*unit_cost
                remaining = [g for g in foods if g['id']!=f['id']]
                previous = f
                for depth in range(1,c['harvest_depth']):
                    options = []
                    for g in remaining:
                        gap = math.hypot(g['p'][0]-previous['p'][0],g['p'][1]-previous['p'][1])
                        if gap < c['harvest_range'] and segment_clear(previous['p'],g['p'],v['edges'],0.):
                            options.append((value(g)-max(0.,gap-10.)*unit_cost,g))
                    if not options:
                        break
                    extra,next_food = max(options,key=lambda row:row[0])
                    score += c['harvest_discount']**depth * max(0.,extra)
                    remaining = [g for g in remaining if g['id']!=next_food['id']]
                    previous = next_food
                if f['id']==m.target_id:
                    score += c['harvest_switch']
                values.append((score,-d,f['id']))
            if not values:
                continue
            key = max(values)[-1]
            if key == m.target_id:
                continue
            if m.target_id is not None:
                owners.pop(m.target_id,None)
            m.target_id = key
            owners[key] = aid
            self.metrics['harvest_target_switches'] += 1

class AppetitePolicy(HarvestPolicy):
    def __init__(self, preset='appetite', **overrides):
        config = dict(birth_energy=135., birth_floor=112., maximum_birth_gap=20.,
                      appetite_level=250., appetite_release=0., appetite_near=0.,
                      appetite_age_slope=0., appetite_start=0.)
        config.update(overrides)
        super().__init__(preset, **config)

    def shared_frames(self, views):
        super().shared_frames(views)
        c = self.config
        if self.clock < c['appetite_start']:
            return
        for aid,v in views.items():
            s,m = v['state'],v['mem']
            if aid in self.retired_ids or m.colonist:
                continue
            level = c['appetite_level']+c['appetite_age_slope']*max(0.,s['age']-50.)
            level = min(max(130.,level),c['idle_energy']*s['max_energy'])
            near = c['appetite_near'] and any(10.<f['obs']['distance']<c['appetite_near'] for f in v['fruits'])
            if getattr(m,'appetite_resting',False) and not near:
                threshold = level-c['appetite_release']
            else:
                threshold = level
            resting = s['energy']>threshold and aid not in self.spawn_ids
            m.appetite_resting = resting
            v['resting'] = resting
            v['eligible'] = not resting

STRATEGY_NAME = 'appetite'

CONFIG = json.loads('{"appetite_release": 70.0, "appetite_near": 80.0}')

RL_SETTINGS = {'start_time': 600.0, 'option_seconds': 1.0, 'alpha': 0.1, 'gamma_per_second': 0.99, 'energy_reward_scale': 50.0, 'death_penalty': 3.0, 'training': True, 'epsilon': 0.3, 'random_seed': 249125782, 'minimum_visits': 5, 'advantage_margin': 0.1, 'kind': 'foraging', 'scan_cooldown': 6.0, 'meal_bonus': 0.5, 'first_meal_bonus': 1.0, 'young_survival_bonus': 0.5, 'time_penalty': 0.01, 'threat_penalty': 0.25, 'credit_timeout': 8.0, 'survival_reward_per_second': 0.05}
RL_MODEL = {'counts': {'0:0:0:0:0:0:0': [10, 26, 10, 0], '0:0:0:0:0:1:0': [9, 24, 16, 0], '0:0:0:0:1:0:0': [80, 109, 61, 0], '0:0:0:0:1:1:0': [97, 150, 140, 0], '0:0:0:1:0:0:0': [10, 4, 8, 0], '0:0:0:1:0:1:0': [14, 6, 27, 0], '0:0:0:1:1:0:0': [37, 50, 53, 0], '0:0:0:1:1:1:0': [153, 96, 90, 0], '0:0:1:0:0:0:0': [7, 21, 7, 0], '0:0:1:0:0:1:0': [3, 9, 4, 0], '0:0:1:0:1:0:0': [42, 27, 28, 0], '0:0:1:0:1:1:0': [19, 5, 12, 0], '0:0:1:1:0:0:0': [3, 3, 10, 0], '0:0:1:1:0:1:0': [3, 6, 3, 0], '0:0:1:1:1:0:0': [49, 44, 20, 0], '0:0:1:1:1:1:0': [13, 26, 36, 0], '0:1:0:0:0:0:0': [1, 1, 1, 0], '0:1:0:0:0:1:0': [9, 9, 2, 0], '0:1:0:0:1:0:0': [9, 4, 2, 0], '0:1:0:0:1:1:0': [42, 21, 19, 0], '0:1:0:1:0:1:0': [3, 3, 3, 0], '0:1:0:1:1:0:0': [7, 13, 5, 0], '0:1:0:1:1:1:0': [24, 32, 25, 0], '0:1:1:0:0:0:0': [1, 1, 1, 0], '0:1:1:0:0:1:0': [1, 0, 0, 0], '0:1:1:0:1:0:0': [8, 6, 5, 0], '0:1:1:0:1:1:0': [2, 7, 3, 0], '0:1:1:1:1:0:0': [2, 5, 1, 0], '0:1:1:1:1:1:0': [4, 2, 7, 0], '1:0:0:0:0:0:0': [6, 11, 9, 0], '1:0:0:0:0:1:0': [6, 7, 7, 0], '1:0:0:0:1:0:0': [78, 37, 37, 0], '1:0:0:0:1:1:0': [69, 108, 33, 0], '1:0:0:1:0:0:0': [4, 6, 3, 0], '1:0:0:1:0:1:0': [5, 3, 1, 0], '1:0:0:1:1:0:0': [19, 17, 16, 0], '1:0:0:1:1:1:0': [69, 62, 65, 0], '1:0:1:0:0:0:0': [2, 5, 1, 0], '1:0:1:0:0:0:1': [3, 3, 1, 2], '1:0:1:0:0:1:0': [1, 2, 1, 0], '1:0:1:0:1:0:0': [20, 25, 35, 0], '1:0:1:0:1:0:1': [16, 31, 46, 10], '1:0:1:0:1:1:0': [8, 4, 4, 0], '1:0:1:0:1:1:1': [7, 14, 3, 5], '1:0:1:1:0:0:0': [2, 1, 2, 0], '1:0:1:1:0:0:1': [4, 1, 1, 1], '1:0:1:1:0:1:0': [1, 0, 1, 0], '1:0:1:1:0:1:1': [1, 1, 1, 1], '1:0:1:1:1:0:0': [11, 31, 8, 0], '1:0:1:1:1:0:1': [1, 5, 3, 19], '1:0:1:1:1:1:0': [11, 8, 21, 0], '1:0:1:1:1:1:1': [1, 2, 2, 9], '1:1:0:0:0:0:0': [7, 2, 2, 0], '1:1:0:0:0:1:0': [10, 9, 6, 0], '1:1:0:0:1:0:0': [19, 23, 6, 0], '1:1:0:0:1:1:0': [55, 61, 29, 0], '1:1:0:1:1:0:0': [12, 18, 7, 0], '1:1:0:1:1:1:0': [32, 57, 19, 0], '1:1:1:0:0:0:0': [1, 0, 0, 0], '1:1:1:0:0:0:1': [1, 0, 0, 1], '1:1:1:0:1:0:0': [10, 4, 10, 0], '1:1:1:0:1:0:1': [16, 2, 2, 5], '1:1:1:0:1:1:0': [6, 8, 3, 0], '1:1:1:0:1:1:1': [3, 2, 2, 4], '1:1:1:1:1:0:0': [3, 3, 2, 0], '1:1:1:1:1:0:1': [6, 3, 1, 2], '1:1:1:1:1:1:0': [2, 7, 3, 0], '1:1:1:1:1:1:1': [1, 0, 0, 0], '2:0:0:0:0:0:0': [7, 1, 2, 0], '2:0:0:0:0:1:0': [2, 4, 2, 0], '2:0:0:0:1:0:0': [35, 95, 66, 0], '2:0:0:0:1:1:0': [95, 22, 31, 0], '2:0:0:1:0:0:0': [1, 4, 1, 0], '2:0:0:1:0:1:0': [1, 0, 1, 0], '2:0:0:1:1:0:0': [20, 37, 76, 0], '2:0:0:1:1:1:0': [17, 32, 52, 0], '2:0:1:0:0:0:0': [0, 0, 1, 0], '2:0:1:0:0:0:1': [1, 9, 1, 2], '2:0:1:0:0:1:0': [0, 0, 1, 0], '2:0:1:0:0:1:1': [1, 1, 1, 1], '2:0:1:0:1:0:0': [18, 8, 5, 0], '2:0:1:0:1:0:1': [77, 34, 37, 17], '2:0:1:0:1:1:0': [3, 5, 2, 0], '2:0:1:0:1:1:1': [10, 3, 1, 5], '2:0:1:1:0:0:0': [2, 2, 3, 0], '2:0:1:1:0:0:1': [1, 2, 3, 2], '2:0:1:1:0:1:0': [0, 0, 1, 0], '2:0:1:1:0:1:1': [0, 1, 0, 1], '2:0:1:1:1:0:0': [2, 4, 1, 0], '2:0:1:1:1:0:1': [4, 24, 9, 6], '2:0:1:1:1:1:0': [9, 5, 3, 0], '2:0:1:1:1:1:1': [2, 1, 5, 10], '2:1:0:0:0:0:0': [2, 2, 11, 0], '2:1:0:0:0:1:0': [0, 0, 1, 0], '2:1:0:0:1:0:0': [27, 71, 13, 0], '2:1:0:0:1:1:0': [16, 24, 36, 0], '2:1:0:1:0:0:0': [0, 1, 0, 0], '2:1:0:1:0:1:0': [1, 0, 1, 0], '2:1:0:1:1:0:0': [13, 15, 9, 0], '2:1:0:1:1:1:0': [8, 25, 8, 0], '2:1:1:0:0:0:1': [1, 1, 1, 2], '2:1:1:0:1:0:0': [22, 4, 9, 0], '2:1:1:0:1:0:1': [5, 18, 23, 29], '2:1:1:0:1:1:0': [1, 4, 8, 0], '2:1:1:0:1:1:1': [2, 2, 1, 8], '2:1:1:1:1:0:0': [2, 2, 5, 0], '2:1:1:1:1:0:1': [7, 2, 19, 6], '2:1:1:1:1:1:0': [0, 1, 1, 0], '2:1:1:1:1:1:1': [1, 1, 1, 1]}, 'q': {'0:0:0:0:0:0:0': [0.32285537947988885, 0.5097005802031099, 0.18575911757060085, 0.0], '0:0:0:0:0:1:0': [-0.29528286405569953, -0.05728849277247632, -0.25150027061872304, 0.0], '0:0:0:0:1:0:0': [0.33863315368222097, 0.3879995376730505, 0.10550607092640361, 0.0], '0:0:0:0:1:1:0': [-0.44636339228778504, -0.3065181694346942, -0.16624519937387092, 0.0], '0:0:0:1:0:0:0': [-0.35446637591418184, -0.49631992447082257, -0.36897011863789786, 0.0], '0:0:0:1:0:1:0': [-0.8986200638846102, -0.9068355863213626, -0.4217766522746536, 0.0], '0:0:0:1:1:0:0': [-0.14652786436877546, 0.14765922600924594, 0.03522987757234675, 0.0], '0:0:0:1:1:1:0': [-0.8126791102442092, -0.8672803828660047, -0.8758198869491257, 0.0], '0:0:1:0:0:0:0': [-0.019215857071067915, 0.17403950036467714, -0.009050955910720738, 0.0], '0:0:1:0:0:1:0': [0.24122718820736339, 0.0834072967530129, -0.20897028137650756, 0.0], '0:0:1:0:1:0:0': [0.728278840109284, 0.6652487931550652, 0.4159114444817074, 0.0], '0:0:1:0:1:1:0': [0.11188613199694163, -0.2500910427302381, 0.09588094727398255, 0.0], '0:0:1:1:0:0:0': [-0.20525276776151632, -0.0032195997097470667, 0.3030495093226723, 0.0], '0:0:1:1:0:1:0': [-0.38469115168879636, -0.4342643570099116, -1.1962176991453333, 0.0], '0:0:1:1:1:0:0': [0.28325609749279906, 0.2425507002870823, 0.004620476218508508, 0.0], '0:0:1:1:1:1:0': [-0.4822394527750729, -0.3687546068072133, -0.2636286181292627, 0.0], '0:1:0:0:0:0:0': [-0.5656783908966139, -0.20495659067270666, -0.14248753243653087, 0.0], '0:1:0:0:0:1:0': [-1.4208493909914324, -1.5757243804220131, -1.2971398233792515, 0.0], '0:1:0:0:1:0:0': [-0.11790630894906852, -0.7168658294617998, -0.35767902056479717, 0.0], '0:1:0:0:1:1:0': [-0.9381263354053033, -1.41852182008462, -1.2083846864876553, 0.0], '0:1:0:1:0:1:0': [-0.14380005528293044, -0.12258957299580846, -0.47074396402455754, 0.0], '0:1:0:1:1:0:0': [-0.9586493906120411, -0.7328050643391993, -1.092719059033175, 0.0], '0:1:0:1:1:1:0': [-1.264587174939382, -1.1937100519024657, -1.401914442794278, 0.0], '0:1:1:0:0:0:0': [-0.057274945925558755, -0.145911889981243, -0.5129037679525794, 0.0], '0:1:1:0:0:1:0': [-0.551974655747019, 0.0, 0.0, 0.0], '0:1:1:0:1:0:0': [-0.43226339173489176, -0.6767298913045809, -0.7451747431322363, 0.0], '0:1:1:0:1:1:0': [-1.6876916789836753, -1.0029535861856331, -1.6521505161329995, 0.0], '0:1:1:1:1:0:0': [-0.13539212188584387, 0.30868352137340077, -0.7115428783046612, 0.0], '0:1:1:1:1:1:0': [-0.18433143166912946, -0.49469715841085105, 0.11065924064459953, 0.0], '1:0:0:0:0:0:0': [-0.049411386703786864, -0.004213973975932031, -0.027600080019433832, 0.0], '1:0:0:0:0:1:0': [-0.2742646770293723, -0.24476984258307563, -0.23134634993399045, 0.0], '1:0:0:0:1:0:0': [0.5286324266112364, 0.38560727025689323, 0.19570628675671276, 0.0], '1:0:0:0:1:1:0': [-0.010501704658147717, 0.015618576087653172, -0.19529481682333144, 0.0], '1:0:0:1:0:0:0': [-0.0818237185501579, 0.10164074668710406, -0.1611570084641521, 0.0], '1:0:0:1:0:1:0': [-0.13014720650609396, -0.05785054146616559, -0.08126426657254542, 0.0], '1:0:0:1:1:0:0': [0.04636560987262336, 0.06415548793789216, 0.23516183422326611, 0.0], '1:0:0:1:1:1:0': [-0.1468419550349883, -0.13598588693445687, -0.06929786882994635, 0.0], '1:0:1:0:0:0:0': [-0.056072645108051176, -0.03989564047769617, -0.15847051339765705, 0.0], '1:0:1:0:0:0:1': [0.292510125487207, 0.2600331222235609, -0.07071799201510962, 0.08691965231340705], '1:0:1:0:0:1:0': [-0.13260565250759407, 0.036816988450340336, 0.7988356119745947, 0.0], '1:0:1:0:1:0:0': [0.2784058561812733, 0.28432251161084865, 0.3376038935550699, 0.0], '1:0:1:0:1:0:1': [0.13400249950928783, 0.4830688018334062, 0.34422970005057113, 0.2425067463874378], '1:0:1:0:1:1:0': [0.18378971713938858, 0.24252357586298315, -0.30019690633330814, 0.0], '1:0:1:0:1:1:1': [0.1637088997986988, 0.4156695085565255, 0.11272922337902604, 0.1986151488236514], '1:0:1:1:0:0:0': [-0.04079513751104961, -0.13134179553262396, -0.3457437291834433, 0.0], '1:0:1:1:0:0:1': [0.4053574458226641, -0.13949459774229428, 0.08909553768708749, -0.13015802373480984], '1:0:1:1:0:1:0': [-0.0657104345780993, 0.0, 0.6993040454375536, 0.0], '1:0:1:1:0:1:1': [-0.44760606811338155, -0.0016620315964672554, 0.15635419687376273, -0.3980626282467508], '1:0:1:1:1:0:0': [-0.08629696308898913, 0.18846963128147817, -0.06529359239065095, 0.0], '1:0:1:1:1:0:1': [0.09416520493871672, 0.36694598269661227, 0.25669582825345294, 0.2380501720769654], '1:0:1:1:1:1:0': [-0.06800829262724256, 0.05463687265219645, 0.22356841039337133, 0.0], '1:0:1:1:1:1:1': [-0.009102246747859331, 0.015394669982117354, -0.13116249523483836, 0.1019160389946133], '1:1:0:0:0:0:0': [0.13649269494925328, -0.11766010681378125, -0.17115810568797135, 0.0], '1:1:0:0:0:1:0': [-0.23598302644249336, -0.5888523537030266, -0.5864928092262855, 0.0], '1:1:0:0:1:0:0': [-0.20444747405527353, -0.16676468937411126, -0.501826675200016, 0.0], '1:1:0:0:1:1:0': [-0.4725281811851825, -0.4619227704268428, -0.5713979085090247, 0.0], '1:1:0:1:1:0:0': [-0.22384079059042303, 0.15423596087459937, -0.5527178343885555, 0.0], '1:1:0:1:1:1:0': [-0.7282409604619702, -0.6289978929726296, -0.8782573332503576, 0.0], '1:1:1:0:0:0:0': [-0.13662802920038047, 0.0, 0.0, 0.0], '1:1:1:0:0:0:1': [0.4802594104744417, 0.0, 0.0, -0.1336308716502075], '1:1:1:0:1:0:0': [0.030440477788245282, -0.14610420235203764, 0.013352733304665354, 0.0], '1:1:1:0:1:0:1': [0.044243050047840175, -0.18989020250394906, -0.22750556532273625, -0.1548025155117918], '1:1:1:0:1:1:0': [-0.30122578899819885, -0.03999210932412337, -0.4219423140828417, 0.0], '1:1:1:0:1:1:1': [-0.16729831815771504, -0.35372053148565025, -0.41279912996757356, 0.06701745919813619], '1:1:1:1:1:0:0': [0.03844840907879273, -0.21814468485674296, -0.08631898295280285, 0.0], '1:1:1:1:1:0:1': [-0.019477524975361114, -0.17609805396490164, -0.009407255196759206, -0.17937919197381905], '1:1:1:1:1:1:0': [-0.44773561600287565, -0.19809339782757965, -0.4612032893269852, 0.0], '1:1:1:1:1:1:1': [0.6269039230406906, 0.0, 0.0, 0.0], '2:0:0:0:0:0:0': [0.336346697621681, -0.1371786208399044, -0.3686421645905532, 0.0], '2:0:0:0:0:1:0': [-0.19426957930625585, -0.12291414010120458, -0.16301252353184584, 0.0], '2:0:0:0:1:0:0': [0.22998986207599353, 0.20569934230330678, 0.33974719164299977, 0.0], '2:0:0:0:1:1:0': [0.17524651903865182, 0.10587261951392084, 0.027041728363531456, 0.0], '2:0:0:1:0:0:0': [-0.04216492343242616, 0.02521393852596152, -0.05211234524603637, 0.0], '2:0:0:1:0:1:0': [-0.21452869482089967, 0.0, -0.03221993410317557, 0.0], '2:0:0:1:1:0:0': [-0.14190946618714645, -0.07316046384731914, 0.01898113469376328, 0.0], '2:0:0:1:1:1:0': [-0.024026624208053068, 0.09815702895680983, 0.11512393003840962, 0.0], '2:0:1:0:0:0:0': [0.0, 0.0, -0.0830639099396703, 0.0], '2:0:1:0:0:0:1': [-0.15707860567097476, 0.4927244036890982, -0.2891947884828208, 0.23649587874788147], '2:0:1:0:0:1:0': [0.0, 0.0, -0.25960439011435865, 0.0], '2:0:1:0:0:1:1': [-0.047859464501766646, -0.06786488408736534, -0.09702963288794823, -0.01859622324312607], '2:0:1:0:1:0:0': [0.41617512423095343, 0.4810126401990703, 0.12909156427841978, 0.0], '2:0:1:0:1:0:1': [0.4507364660509607, 0.33821530339485306, 0.4083050206151939, 0.3142948050763984], '2:0:1:0:1:1:0': [0.12357910395132506, 0.3028070723266378, 0.5064542986741, 0.0], '2:0:1:0:1:1:1': [0.30593185223729347, 0.16511446457206713, 0.030679485275643674, 0.36248921725261685], '2:0:1:1:0:0:0': [-0.21526621753712102, -0.08224727718232734, -0.13016735728340909, 0.0], '2:0:1:1:0:0:1': [-0.13662802920038047, 0.1147713264060307, 0.5792959165548974, -0.06534747734729351], '2:0:1:1:0:1:0': [0.0, 0.0, -0.2480712300363052, 0.0], '2:0:1:1:0:1:1': [0.0, -0.030380573337769, 0.0, -0.018596223243120352], '2:0:1:1:1:0:0': [-0.11369856650481139, 0.4490022013327347, -0.10193273916152484, 0.0], '2:0:1:1:1:0:1': [0.04277555305611319, 0.3634934250163289, 0.11159952226847708, 0.3197266098714252], '2:0:1:1:1:1:0': [0.15320011753158208, 0.22526599871641, -0.10551902237531795, 0.0], '2:0:1:1:1:1:1': [0.11175768435086317, 0.022390049914126957, 0.23222838543195332, 0.34702735789627065], '2:1:0:0:0:0:0': [-0.1408424787510277, 0.011722535228548608, 0.20865739278608333, 0.0], '2:1:0:0:0:1:0': [0.0, 0.0, -0.1778152784836269, 0.0], '2:1:0:0:1:0:0': [0.14965637007993735, 0.3650582134958117, -0.04922322828067418, 0.0], '2:1:0:0:1:1:0': [0.007529107617805782, 0.0035315520373852475, 0.01509250653590051, 0.0], '2:1:0:1:0:0:0': [0.0, -0.16030725590125228, 0.0, 0.0], '2:1:0:1:0:1:0': [-0.14957990182515402, 0.0, -0.06763176374190259, 0.0], '2:1:0:1:1:0:0': [-0.12292117437921166, -0.09028444662635778, -0.1509839122780773, 0.0], '2:1:0:1:1:1:0': [-0.4742195729478702, -0.05688085024309543, -0.4315671117333986, 0.0], '2:1:1:0:0:0:1': [0.01793565061531268, -0.13134179553262362, 0.3967635241206661, 0.4832252059403725], '2:1:1:0:1:0:0': [0.01795119313357037, -0.013204901629862488, 0.21061452987713694, 0.0], '2:1:1:0:1:0:1': [-0.014365116248803121, 0.15075773746985222, 0.2232412387694669, 0.2704200197078702], '2:1:1:0:1:1:0': [-0.1459467138503789, -0.1522529162627897, -0.1717183752502166, 0.0], '2:1:1:0:1:1:1': [-0.030566947135372564, 0.1415704903882223, -0.07310305608176906, 0.1691239810074954], '2:1:1:1:1:0:0': [-0.24200787011191746, -0.2895744783251262, -0.004308086300222116, 0.0], '2:1:1:1:1:0:1': [-0.09525695471520106, -0.2665837039483608, 0.1332923730920898, -0.1663185217059062], '2:1:1:1:1:1:0': [0.0, -0.1309470836476107, -0.20239728249861455, 0.0], '2:1:1:1:1:1:1': [-0.06373381493533058, -0.2406059254209738, -0.08695656594717507, 0.6256513336687975]}}

"""Small tabular semi-Markov residual controller; public observations only.

The stock controller computes every action first. Only safe, fruitless SEARCH
movement after 900s is adjustable. Its birth flag and all protected modes survive.
"""

RL_ACTION_NAMES = ('baseline', 'slow_search', 'fast_search', 'scan_in_place')
RL_SPEED_FRACTIONS = (.4, .2, .7, 0.)


class HybridRLPolicy(AppetitePolicy):
    def __init__(self, preset='appetite', **kwargs):
        super().__init__(preset, **kwargs)
        self.rl_q = {k: list(v) for k, v in RL_MODEL.get('q', {}).items()}
        self.rl_counts = {k: list(v) for k, v in RL_MODEL.get('counts', {}).items()}
        self.rl_rng = random.Random(RL_SETTINGS['random_seed'])
        self.rl_pending = {}
        self.rl_previous = {}
        self.rl_views = {}
        self.rl_transitions = []
        self.rl_stats = Counter()
        self.rl_last_time = None

    def allocate(self, views):
        super().allocate(views)
        self.rl_views = views

    def rl_state(self, view):
        s = view['state']
        energy_bin = 0 if s['energy'] < 75. else 1 if s['energy'] < 150. else 2
        near_tree = any(o['type'] == 'Tree' and o['distance'] < 100.
                        for o in s['observations'])
        slow_terrain = s['biome'] in ('swamp', 'river')
        walk = min(s['speed'], s['sprint_speed'])
        return ':'.join(str(int(x)) for x in
                        (energy_bin, s['age'] >= 60., near_tree, slow_terrain, walk >= 12.))

    def rl_eligible(self, view, action):
        s, mem = view['state'], view['mem']
        return (self.clock >= RL_SETTINGS['start_time']
                and mem.last_mode == 'SEARCH'
                and not view['predators'] and not view['fruits']
                and not any(o['type'] == 'Fruit' for o in s['observations'])
                and not view.get('resting') and not view['escaping']
                and not mem.colonist and s['agent_id'] not in self.retired_ids
                and not action.spawn_agent)

    def rl_row(self, key):
        self.rl_q.setdefault(key, [0.] * 4)
        self.rl_counts.setdefault(key, [0] * 4)
        return self.rl_q[key], self.rl_counts[key]

    def rl_choose(self, key):
        q, counts = self.rl_row(key)
        if RL_SETTINGS['training']:
            untried = [i for i, n in enumerate(counts) if n == 0]
            if untried:
                return self.rl_rng.choice(untried)
            if self.rl_rng.random() < RL_SETTINGS['epsilon']:
                return self.rl_rng.randrange(4)
            return max(range(4), key=lambda i: (q[i], -i))
        minimum = RL_SETTINGS['minimum_visits']
        if counts[0] < minimum:
            self.rl_stats['fallback_unseen_baseline'] += 1
            return 0
        supported = [i for i in range(4) if counts[i] >= minimum]
        best = max(supported, key=lambda i: (q[i], -i))
        if q[best] < q[0] + RL_SETTINGS['advantage_margin']:
            return 0
        return best

    def rl_close(self, aid, next_key=None, death=False):
        pending = self.rl_pending.pop(aid, None)
        if pending is None:
            return
        if death:
            pending['reward'] -= pending['discount'] * RL_SETTINGS['death_penalty']
            self.rl_stats['credited_deaths'] += 1
        key, choice = pending['state'], pending['choice']
        discount = 0. if next_key is None else pending['discount']
        reward = pending['reward']
        self.rl_stats['closed_options'] += 1
        self.rl_stats['return_sum_' + RL_ACTION_NAMES[choice]] += reward
        self.rl_stats['return_count_' + RL_ACTION_NAMES[choice]] += 1
        if RL_SETTINGS['training']:
            q, counts = self.rl_row(key)
            future = max(self.rl_row(next_key)[0]) if next_key is not None else 0.
            q[choice] += RL_SETTINGS['alpha'] * (reward + discount * future - q[choice])
            counts[choice] += 1
            self.rl_transitions.append([key, choice, reward, discount, next_key])
            self.rl_stats['q_updates'] += 1

    def rl_observe_rewards(self, states):
        now = self.clock
        current = {s['agent_id']: s for s in states}
        dt = 0. if self.rl_last_time is None else max(0., now - self.rl_last_time)
        for aid, pending in list(self.rl_pending.items()):
            old = self.rl_previous.get(aid)
            if old is None:
                continue
            s = current.get(aid)
            if s is None:
                self.rl_close(aid, death=True)
                continue
            # Birth flags come from the unchanged baseline. Do not punish its
            # reproduction by charging the learner the parent's 100-energy cost.
            corrected_delta = s['energy'] - old['energy'] + old['birth_cost']
            reward = RL_SETTINGS['survival_reward_per_second'] * dt
            reward += corrected_delta / RL_SETTINGS['energy_reward_scale']
            pending['reward'] += pending['discount'] * reward
            pending['discount'] *= RL_SETTINGS['gamma_per_second'] ** dt
            self.rl_stats['reward_observation_steps'] += 1
        self.rl_last_time = now

    def decide_all(self, states, sim_time=None):
        # Running this first preserves all core allocation, escape, rest and
        # reproduction decisions, including emergency-birth action-cost checks.
        actions = super().decide_all(states, sim_time)
        self.rl_observe_rewards(states)
        byid = {s['agent_id']: s for s in states}
        for action in actions:
            aid = action.agent_id
            view = self.rl_views[aid]
            s, mem = view['state'], view['mem']
            pending = self.rl_pending.get(aid)
            if not self.rl_eligible(view, action):
                if pending is not None:
                    pending['interrupted'] = True
                self.rl_stats['protected_ticks'] += 1
                continue
            self.rl_stats['eligible_ticks'] += 1
            if (pending is None or pending['interrupted'] or
                    self.clock - pending['started'] >= RL_SETTINGS['option_seconds'] - 1e-7):
                key = self.rl_state(view)
                if pending is not None:
                    self.rl_close(aid, next_key=key)
                choice = self.rl_choose(key)
                pending = dict(state=key, choice=choice, started=self.clock,
                               reward=0., discount=1., interrupted=False)
                self.rl_pending[aid] = pending
                self.rl_stats['decisions_' + RL_ACTION_NAMES[choice]] += 1
            choice = pending['choice']
            self.rl_stats['ticks_' + RL_ACTION_NAMES[choice]] += 1
            if choice == 0:
                continue
            speed = min(s['speed'], s['sprint_speed']) * RL_SPEED_FRACTIONS[choice]
            desired = (math.cos(action.move_direction), math.sin(action.move_direction))
            desired, _ = self.slide(desired, view, speed)
            action.move_distance = speed
            action.move_direction = math.atan2(desired[1], desired[0])
            # Keep baseline scanning/turn and the baseline spawn flag exactly.
            terrain = {'river': .3, 'swamp': .5, 'desert': .8}.get(s['biome'], 1.)
            mem.last_move = (speed * terrain * desired[0], speed * terrain * desired[1])
            mem.last_turn = action.turn_angle
            if speed > 0.:
                mem.search_heading = wrap(mem.heading + action.move_direction)
            mem.last_mode = 'RL_' + RL_ACTION_NAMES[choice].upper()
            self.rl_stats['modified_ticks'] += 1
        self.rl_previous = {}
        for action in actions:
            s = byid[action.agent_id]
            move = action.move_distance
            move_cost = .05 * min(move, s['speed']) + .5 * max(0., move - s['speed'])
            turn_cost = min(math.pi, abs(action.turn_angle)) / (2. * math.pi)
            birth_cost = (100. if action.spawn_agent and
                          s['energy'] - move_cost - turn_cost > 100. else 0.)
            self.rl_previous[action.agent_id] = dict(energy=s['energy'], birth_cost=birth_cost)
        return actions

    def rl_finish(self, extinct):
        for aid in list(self.rl_pending):
            self.rl_close(aid, death=extinct)

    def rl_export(self):
        return dict(q=self.rl_q, counts=self.rl_counts, stats=dict(self.rl_stats))


class ForagingRLPolicy(HybridRLPolicy):
    def __init__(self,preset='appetite',**kwargs):
        super().__init__(preset,**kwargs)
        self.rl_last_scan={}
        self.rl_meals=Counter()
        self.rl_foodless_since={}
        self.rl_events=[]
        self.rl_current_key=None

    def rl_state(self,view):
        key=super().rl_state(view)
        if RL_SETTINGS['kind']=='movement_only':
            return key
        aid=view['state']['agent_id']
        long_search=self.clock-self.rl_foodless_since.get(aid,self.clock)>=3.
        scan_ok=self.rl_scan_allowed(view)
        return key+':'+str(int(long_search))+':'+str(int(scan_ok))

    def rl_scan_allowed(self,view):
        s=view['state']
        return (s['energy']>=100. and any(o['type']=='Tree' and o['distance']<100.
                 for o in s['observations']) and
                self.clock-self.rl_last_scan.get(s['agent_id'],-1e9)>=RL_SETTINGS['scan_cooldown'])

    def rl_allowed(self,key):
        if RL_SETTINGS['kind']=='movement_only':return [0,1,2]
        return [0,1,2,3] if key.endswith(':1') else [0,1,2]

    def rl_choose(self,key):
        q,counts=self.rl_row(key);allowed=self.rl_allowed(key)
        if RL_SETTINGS['training']:
            untried=[i for i in allowed if counts[i]==0]
            if untried:return self.rl_rng.choice(untried)
            if self.rl_rng.random()<RL_SETTINGS['epsilon']:return self.rl_rng.choice(allowed)
            return max(allowed,key=lambda i:(q[i],-i))
        minimum=RL_SETTINGS['minimum_visits']
        if counts[0]<minimum:
            self.rl_stats['fallback_unseen_baseline']+=1;return 0
        supported=[i for i in allowed if counts[i]>=minimum]
        best=max(supported,key=lambda i:(q[i],-i))
        return best if q[best]>=q[0]+RL_SETTINGS['advantage_margin'] else 0

    def rl_close(self,aid,next_key=None,death=False):
        if RL_SETTINGS['kind']=='movement_only':
            return super().rl_close(aid,next_key,death)
        p=self.rl_pending.pop(aid,None)
        if p is None:return
        if death:
            p['reward']-=p['discount']*RL_SETTINGS['death_penalty']
            self.rl_stats['credited_deaths']+=1
        key,choice=p['state'],p['choice'];discount=p['discount'] if next_key is not None else 0.
        self.rl_stats['closed_options']+=1
        self.rl_stats['return_sum_'+RL_ACTION_NAMES[choice]]+=p['reward']
        self.rl_stats['return_count_'+RL_ACTION_NAMES[choice]]+=1
        if RL_SETTINGS['training']:
            q,n=self.rl_row(key)
            future=max(self.rl_row(next_key)[0][i] for i in self.rl_allowed(next_key)) if next_key is not None else 0.
            q[choice]+=RL_SETTINGS['alpha']*(p['reward']+discount*future-q[choice]);n[choice]+=1
            self.rl_transitions.append([key,choice,p['reward'],discount,next_key])
            self.rl_stats['q_updates']+=1

    def rl_observe_rewards(self,states):
        if RL_SETTINGS['kind']=='movement_only':
            # Evaluation only. Preserve the old telemetry reward definition.
            return super().rl_observe_rewards(states)
        current={s['agent_id']:s for s in states}
        dt=0. if self.rl_last_time is None else max(0.,self.clock-self.rl_last_time)
        for aid in list(self.rl_pending):
            if aid not in current:self.rl_close(aid,death=True)
        for aid,s in current.items():
            old=self.rl_previous.get(aid);view=self.rl_views[aid]
            self.rl_foodless_since.setdefault(aid,self.clock)
            if view['fruits']:self.rl_foodless_since[aid]=self.clock
            if old is None:continue
            p=self.rl_pending.get(aid)
            corrected=s['energy']-old['energy']+old['birth_cost']
            # Food is inferred from public energy and known action costs. Any
            # hidden aging loss only makes this lower-bound detector conservative.
            meal=corrected+old['action_cost']+max(0.,s['age']-old['age'])>.5
            first_meal=meal and self.rl_meals[aid]==0
            if meal:
                self.rl_meals[aid]+=1;self.rl_foodless_since[aid]=self.clock
            if p is None:continue
            reward=corrected/RL_SETTINGS['energy_reward_scale']
            reward-=.25*old['birth_cost']/RL_SETTINGS['energy_reward_scale']
            reward-=RL_SETTINGS['time_penalty']*dt
            if meal:
                reward+=RL_SETTINGS['meal_bonus'];self.rl_stats['credited_meals']+=1
                if first_meal and s['age']<30.:
                    reward+=RL_SETTINGS['first_meal_bonus'];self.rl_stats['credited_first_meals']+=1
            if old['age']<30.<=s['age']:
                reward+=RL_SETTINGS['young_survival_bonus'];self.rl_stats['credited_age30']+=1
            p['reward']+=p['discount']*reward
            p['discount']*=RL_SETTINGS['gamma_per_second']**dt
            self.rl_stats['reward_observation_steps']+=1
            # End credit at an actual feeding success, observed threat, or long
            # baseline takeover. Do not attribute a later retirement death to a
            # search decision that found food a minute earlier.
            if meal:
                self.rl_close(aid);self.rl_stats['food_terminal_options']+=1
            elif view['predators']:
                p['reward']-=p['discount']*RL_SETTINGS['threat_penalty']
                self.rl_close(aid);self.rl_stats['threat_terminal_options']+=1
            elif view.get('resting') or aid in self.retired_ids:
                self.rl_close(aid);self.rl_stats['baseline_rest_terminal_options']+=1
            elif self.clock-p['started']>=RL_SETTINGS['credit_timeout']:
                self.rl_close(aid);self.rl_stats['credit_timeout_options']+=1
        self.rl_last_time=self.clock

    def decide_all(self,states,sim_time=None):
        old_pending={aid:(p['started'],p['choice']) for aid,p in self.rl_pending.items()}
        actions=super().decide_all(states,sim_time)
        byid={s['agent_id']:s for s in states}
        for aid,p in self.rl_pending.items():
            if p['choice']==3 and old_pending.get(aid)!=(p['started'],p['choice']):
                self.rl_last_scan[aid]=self.clock
        for a in actions:
            s=byid[a.agent_id]
            move=.05*min(a.move_distance,s['speed'])+.5*max(0.,a.move_distance-s['speed'])
            turn=min(math.pi,abs(a.turn_angle))/(2*math.pi)
            self.rl_previous[a.agent_id].update(age=s['age'],action_cost=move+turn)
        return actions


def make_policy():
    return ForagingRLPolicy('appetite', **CONFIG)


from threading import RLock
from fastapi import Body, FastAPI

app = FastAPI(title="Survival Agent")
_lock = RLock()
_policy = make_policy()
_last_time = None
_last_signature = None
_last_response = None
_largest_id = -1

@app.post("/predict")
def predict(step: StepResponse = Body(...)):
    global _policy, _last_time, _last_signature, _last_response, _largest_id
    with _lock:
        signature = json.dumps(step.model_dump(), sort_keys=True, separators=(",", ":"))
        if signature == _last_signature:
            return _last_response
        supplied_time = step.sim_time if "sim_time" in step.model_fields_set else None
        # Some clients serialize the DTO's default zero on every step.
        if supplied_time == 0.0 and any(a.age > 0.0 for a in step.agent_status):
            supplied_time = None
        current_ids = {a.agent_id for a in step.agent_status}
        live_before = set(getattr(_policy, "memory", {}))
        ids_restarted = bool(current_ids and live_before and not current_ids & live_before
                             and min(current_ids) < _largest_id)
        if ids_restarted or (_last_time is not None and supplied_time is not None and supplied_time < _last_time):
            _policy = make_policy()
            _largest_id = -1
        if step.game_status != "ok" or not step.agent_status:
            _policy = make_policy()
            _largest_id = -1
            response = {"actions": []}
        else:
            states = [agent.model_dump() for agent in step.agent_status]
            response = {"actions": [a.model_dump() for a in _policy.decide_all(states, supplied_time)]}
            _largest_id = max(_largest_id, max(current_ids))
        _last_time = supplied_time
        _last_signature = signature
        _last_response = response
        return response

@app.get("/")
def index():
    return {"status": "ok", "strategy": STRATEGY_NAME}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9052)

